return {
    version     = "1.1.11",
    fullname    = "Dames",
    description = "Jeu de dames 8x8",
}
