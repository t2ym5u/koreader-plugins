local _ = require("gettext")

return {
    fullname    = _("Calendar"),
    description = _("Month calendar with week numbers, public holidays, moon phases and a date calculator."),
    version     = "1.0.2",
}
