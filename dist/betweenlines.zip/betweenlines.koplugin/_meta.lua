local _ = require("gettext")
return {
    fullname    = _("Between Lines Sudoku"),
    description = _("Sudoku with between-lines constraints"),
    version     = "1.7.1",
}
