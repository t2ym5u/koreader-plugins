local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"
package.path = _dir .. "?.lua;" .. _dir .. "common/?.lua;" .. package.path

local function lrequire(name)
    local key = _dir .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. name .. ".lua"))()
    end
    return package.loaded[key]
end

local DataStorage     = require("datastorage")
local LuaSettings     = require("luasettings")
local UIManager       = require("ui/uimanager")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local _               = require("i18n")

-- Play-session stats, shared with every other game through
-- game_stats.lua (Dashboard reads it). pcall'd: an install whose
-- common/ predates sudoku-common 1.4.0 has no stats_exporter.lua,
-- and a bare require would take the whole plugin down with it.
local ok_stats, StatsExporter = pcall(require, "stats_exporter")

require("i18n").extend(lrequire("i18n_fr"))

local board_module       = lrequire("board")
local ArrowSudokuBoard   = board_module.ArrowSudokuBoard
local DEFAULT_DIFFICULTY = board_module.DEFAULT_DIFFICULTY
local generateWithProgress = lrequire("common/base_screen").generateWithProgress

local ArrowSudokuScreen = lrequire("screen")

-- Spelled out rather than read off self.name: ReaderUI/FileManager
-- rewrite an instance's name to "reader<id>"/"filemanager<id>" right
-- after it is built, so self.name is not the plugin id after :init().
local PLUGIN_ID = "arrowsudoku"

local ArrowSudoku = WidgetContainer:extend{
    name        = "arrowsudoku",
    is_doc_only = false,
}

function ArrowSudoku:ensureSettings()
    if not self.settings_file then
        self.settings_file = DataStorage:getSettingsDir() .. "/arrowsudoku.lua"
    end
    if not self.settings then
        self.settings = LuaSettings:open(self.settings_file)
    end
end

function ArrowSudoku:init()
    self:ensureSettings()
    self.ui.menu:registerToMainMenu(self)
end

-- Listed under Tools → Games with the rest of the fleet. games_menu comes
-- from game-common, which this plugin does not ship: any other game's
-- common/ provides it. Installed on its own, the game keeps its own entry.
function ArrowSudoku:addToMainMenu(menu_items)
    local ok, GamesMenu = pcall(require, "games_menu")
    if ok and type(GamesMenu) == "table" and GamesMenu.add then
        GamesMenu.add(menu_items, {
            id     = "arrowsudoku",
            label  = _("Arrow Sudoku"),
            launch = function() self:showGame() end,
        })
        return
    end
    menu_items.arrowsudoku = {
        text         = _("Arrow Sudoku"),
        sorting_hint = "tools",
        callback     = function() self:showGame() end,
    }
end

function ArrowSudoku:getBoard()
    if not self.board then
        self:ensureSettings()
        self.board = ArrowSudokuBoard:new()
        local state = self.settings:readSetting("state")
        if not self.board:load(state) then
            generateWithProgress(self.board, DEFAULT_DIFFICULTY)
        end
    end
    return self.board
end

function ArrowSudoku:saveState()
    if not self.board then return end
    self:ensureSettings()
    self.settings:saveSetting("state", self.board:serialize())
    self.settings:flush()
end

function ArrowSudoku:showGame()
    if self.screen then return end
    self._session_start = os.time()
    self.screen = ArrowSudokuScreen:new{
        board  = self:getBoard(),
        plugin = self,
    }
    UIManager:show(self.screen)
end

function ArrowSudoku:onScreenClosed()
    local elapsed = self._session_start and (os.time() - self._session_start) or 0
    self._session_start = nil
    if ok_stats then
        local cur = StatsExporter:get(PLUGIN_ID) or {}
        StatsExporter:record(PLUGIN_ID, {
            sessions    = (cur.sessions or 0) + 1,
            last_played = os.time(),
            time_played = (cur.time_played or 0) + elapsed,
        })
    end
    self.screen = nil
end

-- KOReader >= 2026.07 plugin management (PluginLoader, PR #15240).
-- PluginLoader removes self.settings_file itself; what is left is the
-- open game screen and this game's row in the shared game_stats.lua.
function ArrowSudoku:stopPlugin()
    if self.screen then
        UIManager:close(self.screen)
        self.screen = nil
    end
end

function ArrowSudoku:deletePluginSettings()
    if ok_stats then StatsExporter:remove(PLUGIN_ID) end
end

return ArrowSudoku
