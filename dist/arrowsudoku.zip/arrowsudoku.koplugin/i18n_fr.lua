return {
    ["Arrow Sudoku"] = { fr = "Sudoku Flèches", es = "Sudoku de Flechas", de = "Pfeil-Sudoku" },
    ["Sudoku with arrow sum constraints"] = { fr = "Sudoku avec contraintes de somme en flèche", es = "Sudoku con restricciones de suma en flecha", de = "Sudoku mit Pfeilsummen-Beschränkungen" },
}
