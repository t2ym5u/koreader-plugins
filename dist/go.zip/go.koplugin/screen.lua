local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"
local function lrequire(name)
    local key = _dir .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. name .. ".lua"))()
    end
    return package.loaded[key]
end

local FrameContainer  = require("ui/widget/container/framecontainer")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local Size            = require("ui/size")
local UIManager       = require("ui/uimanager")
local VerticalGroup   = require("ui/widget/verticalgroup")
local VerticalSpan    = require("ui/widget/verticalspan")
local _               = require("i18n")
local T               = require("ffi/util").template

local MenuHelper = require("menu_helper")
local ScreenBase = require("screen_base")

local GoBoard       = lrequire("board")
local GoBoardWidget = lrequire("board_widget")

local GAME_RULES_EN = _([[
Go — Rules

Two players (Black and White) alternate placing stones on the intersections of the grid. Black plays first.

A group of connected same-color stones is captured and removed when it has no empty adjacent intersection (liberty) left. You may not play a move that would leave your own stone(s) with no liberties, unless it captures an opponent group first.

Ko rule: you may not immediately recapture in a way that recreates the board position from just before your opponent's last move.

The game ends when both players pass in a row. Territory (surrounded empty points) plus stones on the board are scored per color; White receives a 6.5 point komi to offset Black's first-move advantage.

Note: there is no dead-stone marking step -- capture any dead groups yourself before passing twice, or the score won't reflect them.
]])

local GAME_RULES_FR = [[
Go — Règles

Deux joueurs (Noir et Blanc) posent alternativement des pierres sur les intersections de la grille. Noir joue en premier.

Un groupe de pierres connectées de même couleur est capturé et retiré quand il n'a plus aucune intersection adjacente vide (liberté). Vous ne pouvez pas jouer un coup qui laisserait votre propre groupe sans liberté, sauf s'il capture d'abord un groupe adverse.

Règle du Ko : vous ne pouvez pas reprendre immédiatement d'une façon qui recréerait la position du plateau juste avant le dernier coup de l'adversaire.

La partie se termine quand les deux joueurs passent d'affilée. Le territoire (points vides entourés) plus les pierres sur le plateau sont comptés par couleur ; Blanc reçoit un komi de 6.5 points pour compenser l'avantage du premier coup de Noir.

Remarque : il n'y a pas d'étape de marquage des pierres mortes -- capturez vous-même les groupes morts avant de passer deux fois, sinon le score n'en tiendra pas compte.
]]

local GoScreen = ScreenBase:extend{}

function GoScreen:init()
    local state   = self.plugin:loadState()
    local size_id = self.plugin:getSetting("size_id", GoBoard.DEFAULT_SIZE)
    self.board = GoBoard:new{ size_id = size_id }
    if not self.board:load(state) then
        self.board:reset(size_id)
    end
    ScreenBase.init(self)
end

-- ---------------------------------------------------------------------------
-- Opponent
--
-- The computer plays White, so a solo player keeps the first move. It is a
-- beginner and says so: no search, just the things beginners actually lose
-- games to -- captures on offer, its own groups in atari, and never filling
-- its own eyes. See board:getAIMove().
-- ---------------------------------------------------------------------------

local AI_COLOR = "white"
local AI_DELAY = 0.35

function GoScreen:isSolo()
    return self.plugin:getSetting("opponent", "human") == "ai"
end

function GoScreen:getOpponentButtonText()
    return self:isSolo() and _("Opponent: Computer") or _("Opponent: Human")
end

function GoScreen:toggleOpponent()
    self.plugin:saveSetting("opponent", self:isSolo() and "human" or "ai")
    self:updateStatus(self:isSolo()
        and _("The computer now plays White.")
        or  _("Two players on one device."))
    self:maybeRunAI()
end

function GoScreen:maybeRunAI()
    local board = self.board
    if not self:isSolo() then return end
    if board.status ~= "playing" or board.turn ~= AI_COLOR then return end
    if self.ai_thinking then return end
    self.ai_thinking = true

    UIManager:scheduleIn(AI_DELAY, function()
        self.ai_thinking = false
        if board.status ~= "playing" or board.turn ~= AI_COLOR then return end
        local mv = board:getAIMove()
        if mv and board:placeStone(mv.r, mv.c) == "ok" then
            self.board_widget:refresh()
            self:updateStatus()
        else
            board:pass()
            self.board_widget:refresh()
            self:updateStatus(_("The computer passed."))
        end
        self.plugin:saveState(self:serializeState())
    end)
end

-- Two passes in a row end the game.
function GoScreen:isRoundOver()
    return self.board.status ~= "playing"
end

function GoScreen:serializeState()
    return self.board:serialize()
end

function GoScreen:buildLayout()
    local is_landscape = self:isLandscape()

    local title_bar = self:buildTitleBar(_("Go"), function()
        return {
            { text = _("New game"),     callback = function() self:onNewGame() end },
            { text = T(_("Size: %1"), self:_sizeLabel()), callback = function() self:openSizeMenu() end },
            { text = self:getOpponentButtonText(), callback = function() self:toggleOpponent() end },
            { text = _("Pass"),         callback = function() self:onPass() end },
            self:makeRulesButtonConfig(GAME_RULES_EN, GAME_RULES_FR),
        }
    end)

    local controls_w = self:getControlsWidth()
    self.status_text:setMaxWidth(controls_w)
    local controls = VerticalGroup:new{
        align = "center",
        self.status_text,
        VerticalSpan:new{ width = Size.span.vertical_large },
        self:buildActionBar({
            { text = _("Pass"), callback = function() self:onPass() end },
        }),
    }

    local frame_pad = Size.padding.default
    local frame_extra = 2 * (frame_pad + Size.border.window)
    local budget_w, budget_h = self:getBoardBudget(title_bar, controls)
    self.board_widget = GoBoardWidget:new{
        board        = self.board,
        size         = math.min(budget_w, budget_h) - frame_extra,
        onCellAction = function(r, c) self:onCellAction(r, c) end,
    }

    local board_frame = FrameContainer:new{
        padding = frame_pad,
        margin  = 0,
        self.board_widget,
    }

    if is_landscape then
        local content = HorizontalGroup:new{
            align  = "center",
            board_frame,
            HorizontalSpan:new{ width = self:getGutter() },
            controls,
        }
        self:buildLandscapeLayout(title_bar, content)
    else
        self:buildPortraitLayout(title_bar, board_frame,
            VerticalGroup:new{ align = "center", controls, VerticalSpan:new{ width = self:getGutter() } })
    end
    self:updateStatus()
end

function GoScreen:onCellAction(r, c)
    local board = self.board
    if board.status ~= "playing" then return end

    local result = board:placeStone(r, c)
    if result == "invalid" then
        self:updateStatus(_("Invalid move."))
        return
    end

    self.board_widget:refresh()
    self.plugin:saveState(self:serializeState())
    self:updateStatus()
    self:maybeRunAI()
end

function GoScreen:onPass()
    local board = self.board
    if board.status ~= "playing" then return end

    local result = board:pass()
    self.board_widget:refresh()
    self.plugin:saveState(self:serializeState())

    if result == "ended" then
        self:updateStatus()
        local fs = board.final_score
        local winner_label = board.winner == "black" and _("Black side") or _("White side")
        self:showMessage(T(_("%1 wins! Black: %2  White: %3"), winner_label, fs.black, fs.white), 5)
    else
        self:updateStatus()
        self:maybeRunAI()
    end
end

function GoScreen:onNewGame()
    self.board:reset(self.plugin:getSetting("size_id", GoBoard.DEFAULT_SIZE))
    self.plugin:saveState(self.board:serialize())
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
    self:maybeRunAI()
end

function GoScreen:openSizeMenu()
    local items = {}
    for _, cfg in ipairs(GoBoard.SIZES) do
        items[#items + 1] = { id = cfg.id, text = cfg.label }
    end
    MenuHelper.openPickerMenu{
        title      = _("Size"),
        items      = items,
        current_id = self.board.size_id,
        parent     = self,
        on_select  = function(id)
            self.plugin:saveSetting("size_id", id)
            self.board:reset(id)
            self.plugin:saveState(self.board:serialize())
            self:buildLayout()
            UIManager:setDirty(self, function() return "ui", self.dimen end)
        end,
    }
end

function GoScreen:_sizeLabel()
    for _, cfg in ipairs(GoBoard.SIZES) do
        if cfg.id == self.board.size_id then return cfg.label end
    end
    return self.board.size_id
end

function GoScreen:updateStatus(msg)
    local status
    if msg then
        status = msg
    elseif self.board.status == "ended" then
        local fs = self.board.final_score
        local winner_label = self.board.winner == "black" and _("Black side") or _("White side")
        status = T(_("%1 wins! Black: %2  White: %3"), winner_label, fs.black, fs.white)
    else
        status = self:joinStatus(
            T("%1×%1", self.board.n),
            self.board.turn == "black" and _("Black to play") or _("White to play"),
            T(_("Captures: B%1 W%2"), self.board.captures.black, self.board.captures.white))
    end
    ScreenBase.updateStatus(self, status)
    -- Every move and pass (player's or computer's) ends here.
    self:refreshActionBar()
end

return GoScreen
