return {
    ["%1\xC3\x97%2 (1\xE2\x80\x93%3) \xC2\xB7 %4 \xC2\xB7 Empty: %5"] = { fr = "%1\xC3\x97%2 (1\xE2\x80\x93%3) \xC2\xB7 %4 \xC2\xB7 Vides : %5", es = "%1\xC3\x97%2 (1\xE2\x80\x93%3) \xC2\xB7 %4 \xC2\xB7 Vacías: %5", de = "%1\xC3\x97%2 (1\xE2\x80\x93%3) \xC2\xB7 %4 \xC2\xB7 Leer: %5" },
    ["Connect numbers 1-N on a grid"] = { fr = "Reliez les nombres 1 à N sur une grille", es = "Conecta los números 1-N en una cuadrícula", de = "Verbinde die Zahlen 1-N auf einem Raster" },
    ["Hidato"] = { fr = "Hidato", es = "Hidato", de = "Hidato" },
}
