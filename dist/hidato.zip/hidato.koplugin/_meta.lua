local _ = require("gettext")
return {
    fullname    = _("Hidato"),
    description = _("Connect numbers 1-N on a grid"),
    version     = "1.1.14",
}
