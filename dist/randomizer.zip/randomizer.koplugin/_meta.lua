local _ = require("gettext")
return {
    fullname    = _("Random draw"),
    description = _("Coin flip, random number, pick a name, turn order, teams and raffle draws for games around the table."),
    version     = "1.0.4",
}
