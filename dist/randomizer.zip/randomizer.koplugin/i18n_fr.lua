return {
    -- Plugin
    ["Random draw"] = { fr = "Tirage au sort", es = "Sorteo", de = "Zufallsauswahl" },
    ["Coin flip, random number, pick a name, turn order, teams and raffle draws for games around the table."] = { fr = "Pile ou face, nombre au hasard, tirage d'un nom, ordre de jeu, équipes et tombola pour les jeux autour de la table.", es = "Cara o cruz, número al azar, elegir un nombre, orden de juego, equipos y rifa para los juegos de mesa.", de = "Münzwurf, Zufallszahl, Namen ziehen, Spielreihenfolge, Teams und Tombola für Spiele am Tisch." },

    -- Tabs
    ["Coin"] = { fr = "Pièce", es = "Moneda", de = "Münze" },
    ["Number"] = { fr = "Nombre", es = "Número", de = "Zahl" },
    ["Name"] = { fr = "Nom", es = "Nombre", de = "Name" },
    ["Order"] = { fr = "Ordre", es = "Orden", de = "Reihenfolge" },
    ["Teams"] = { fr = "Équipes", es = "Equipos", de = "Teams" },
    ["Raffle"] = { fr = "Tombola", es = "Rifa", de = "Tombola" },

    -- Buttons
    ["Flip the coin"] = { fr = "Lancer la pièce", es = "Lanzar la moneda", de = "Münze werfen" },
    ["Draw a number"] = { fr = "Tirer un nombre", es = "Sacar un número", de = "Zahl ziehen" },
    ["Pick"] = { fr = "Choisir", es = "Elegir", de = "Auswählen" },
    ["Shuffle the order"] = { fr = "Mélanger l'ordre", es = "Mezclar el orden", de = "Reihenfolge mischen" },
    ["Split"] = { fr = "Répartir", es = "Repartir", de = "Aufteilen" },
    ["Draw a name"] = { fr = "Tirer un nom", es = "Sacar un nombre", de = "Namen ziehen" },
    ["Start over"] = { fr = "Recommencer", es = "Empezar de nuevo", de = "Neu beginnen" },
    ["Cancel"] = { fr = "Annuler", es = "Cancelar", de = "Abbrechen" },
    ["OK"] = { fr = "OK", es = "OK", de = "OK" },
    ["Save"] = { fr = "Enregistrer", es = "Guardar", de = "Speichern" },
    ["Delete"] = { fr = "Supprimer", es = "Eliminar", de = "Löschen" },

    -- Coin
    ["HEADS"] = { fr = "FACE", es = "CARA", de = "KOPF" },
    ["TAILS"] = { fr = "PILE", es = "CRUZ", de = "ZAHL" },
    ["Heads %1 · Tails %2"] = { fr = "Face %1 · Pile %2", es = "Cara %1 · Cruz %2", de = "Kopf %1 · Zahl %2" },
    ["Last flips: %1"] = { fr = "Derniers lancers : %1", es = "Últimos lanzamientos: %1", de = "Letzte Würfe: %1" },
    ["Tap Flip the coin."] = { fr = "Touchez Lancer la pièce.", es = "Toca Lanzar la moneda.", de = "Tippen Sie auf Münze werfen." },

    -- Number
    ["Min %1"] = { fr = "De %1", es = "De %1", de = "Von %1" },
    ["Max %1"] = { fr = "À %1", es = "A %1", de = "Bis %1" },
    ["Before: %1"] = { fr = "Avant : %1", es = "Antes: %1", de = "Vorher: %1" },
    ["A whole number from %1 to %2"] = { fr = "Un nombre entier de %1 à %2", es = "Un número entero de %1 a %2", de = "Eine ganze Zahl von %1 bis %2" },
    ["Lowest number"] = { fr = "Plus petit nombre", es = "Número más bajo", de = "Kleinste Zahl" },
    ["Highest number"] = { fr = "Plus grand nombre", es = "Número más alto", de = "Größte Zahl" },
    ["Type the bound on the keypad."] = { fr = "Tapez la borne au pavé numérique.", es = "Escribe el límite en el teclado.", de = "Grenze auf dem Ziffernblock eingeben." },

    -- Names, order, teams, raffle
    ["First: %1"] = { fr = "Commence : %1", es = "Empieza: %1", de = "Beginnt: %1" },
    ["Tap Shuffle the order for a random turn order."] = { fr = "Touchez Mélanger l'ordre pour un ordre de jeu au hasard.", es = "Toca Mezclar el orden para un orden de juego al azar.", de = "Tippen Sie auf Reihenfolge mischen für eine zufällige Reihenfolge." },
    ["Teams:"] = { fr = "Équipes :", es = "Equipos:", de = "Teams:" },
    ["Tap Split to make the teams."] = { fr = "Touchez Répartir pour former les équipes.", es = "Toca Repartir para formar los equipos.", de = "Tippen Sie auf Aufteilen, um die Teams zu bilden." },
    ["%1 teams of %2"] = { fr = "%1 équipes de %2", es = "%1 equipos de %2", de = "%1 Teams zu %2" },
    ["%1 teams of %2 or %3"] = { fr = "%1 équipes de %2 ou %3", es = "%1 equipos de %2 o %3", de = "%1 Teams zu %2 oder %3" },
    ["Left: %1 of %2"] = { fr = "Restent : %1 sur %2", es = "Quedan: %1 de %2", de = "Übrig: %1 von %2" },
    ["The list is empty."] = { fr = "La liste est vide.", es = "La lista está vacía.", de = "Die Liste ist leer." },
    ["Everyone has been drawn. Start over to put the names back."] = { fr = "Tout le monde a été tiré. Recommencez pour remettre les noms.", es = "Ya han salido todos. Empieza de nuevo para devolver los nombres.", de = "Alle wurden gezogen. Neu beginnen legt die Namen zurück." },
    ["Put every name back and start the raffle over?"] = { fr = "Remettre tous les noms et recommencer la tombola ?", es = "¿Devolver todos los nombres y empezar la rifa de nuevo?", de = "Alle Namen zurücklegen und die Tombola neu beginnen?" },
    ["Start the raffle over"] = { fr = "Recommencer la tombola", es = "Empezar la rifa de nuevo", de = "Tombola neu beginnen" },
    ["The list needs at least %1 names: ☰ → Lists."] = { fr = "Il faut au moins %1 noms dans la liste : ☰ → Listes.", es = "La lista necesita al menos %1 nombres: ☰ → Listas.", de = "Die Liste braucht mindestens %1 Namen: ☰ → Listen." },

    ["The list is empty: add names in ☰ → Lists."] = { fr = "La liste est vide : ajoutez des noms dans ☰ → Listes.", es = "La lista está vacía: añade nombres en ☰ → Listas.", de = "Die Liste ist leer: Namen unter ☰ → Listen hinzufügen." },

    -- Lists
    ["Lists"] = { fr = "Listes", es = "Listas", de = "Listen" },
    ["Players"] = { fr = "Joueurs", es = "Jugadores", de = "Spieler" },
    ["List: %1 (%2) ▾"] = { fr = "Liste : %1 (%2) ▾", es = "Lista: %1 (%2) ▾", de = "Liste: %1 (%2) ▾" },
    ["%1 (%2 names)"] = { fr = "%1 (%2 noms)", es = "%1 (%2 nombres)", de = "%1 (%2 Namen)" },
    ["New list"] = { fr = "Nouvelle liste", es = "Lista nueva", de = "Neue Liste" },
    ["Name of the new list"] = { fr = "Nom de la nouvelle liste", es = "Nombre de la lista nueva", de = "Name der neuen Liste" },
    ["Names in %1 (one per line)"] = { fr = "Noms de %1 (un par ligne)", es = "Nombres de %1 (uno por línea)", de = "Namen in %1 (einer pro Zeile)" },
    ["Use this list"] = { fr = "Utiliser cette liste", es = "Usar esta lista", de = "Diese Liste verwenden" },
    ["Use the list"] = { fr = "Utiliser la liste", es = "Usar la lista", de = "Liste verwenden" },
    ["Edit the names"] = { fr = "Modifier les noms", es = "Editar los nombres", de = "Namen bearbeiten" },
    ["Rename the list"] = { fr = "Renommer la liste", es = "Renombrar la lista", de = "Liste umbenennen" },
    ["Delete the list"] = { fr = "Supprimer la liste", es = "Eliminar la lista", de = "Liste löschen" },
    ['Delete the list "%1"?'] = { fr = "Supprimer la liste « %1 » ?", es = "¿Eliminar la lista «%1»?", de = "Liste „%1“ löschen?" },
    ["Manage the lists…"] = { fr = "Gérer les listes…", es = "Gestionar las listas…", de = "Listen verwalten…" },
    ["Import the Score sheets players"] = { fr = "Importer les joueurs des Feuilles de score", es = "Importar los jugadores de Hojas de puntuación", de = "Spieler aus den Spielblöcken importieren" },
    ["Score sheet players"] = { fr = "Joueurs des feuilles de score", es = "Jugadores de las hojas", de = "Spieler der Spielblöcke" },
    ["No players saved in Score sheets yet."] = { fr = "Aucun joueur enregistré dans les Feuilles de score pour l'instant.", es = "Aún no hay jugadores guardados en Hojas de puntuación.", de = "In den Spielblöcken sind noch keine Spieler gespeichert." },
    ['List "%1" added: %2 names.'] = { fr = "Liste « %1 » ajoutée : %2 noms.", es = "Lista «%1» añadida: %2 nombres.", de = "Liste „%1“ hinzugefügt: %2 Namen." },
    ["Clear the history"] = { fr = "Effacer l'historique", es = "Borrar el historial", de = "Verlauf löschen" },
}
