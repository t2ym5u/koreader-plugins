local _ = require("gettext")
return {
    fullname    = _("Nonogram"),
    description = _("Fill cells by row and column clues to reveal the hidden picture."),
    version     = "1.6.3",
}
