local DataStorage     = require("datastorage")
local LuaSettings     = require("luasettings")
local UIManager       = require("ui/uimanager")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local _               = require("i18n")
local StatsExporter   = require("stats_exporter")
local GamesMenu       = require("games_menu")
local T               = require("ffi/util").template

-- ---------------------------------------------------------------------------
-- PluginBase — shared plugin lifecycle for all game plugins
--
-- Subclasses must set:
--   name        (string)  — unique plugin id, used as settings file name
--   menu_text   (string)  — label shown in Tools → Games
--   menu_hint   (string)  — unused since 1.9.0 (every game is listed under
--                           Tools → Games, see games_menu.lua); kept so the
--                           subclasses that still set it need no change
--
-- `name` must match the plugin's directory basename: since KOReader 2026.03
-- (PR #15096) PluginLoader overwrites plugin_module.name with the directory
-- name unconditionally, so anything else here is silently discarded.
--
-- Subclasses must implement:
--   :createScreen()       — return a new ScreenBase subclass instance
--
-- Subclasses may set:
--   party_mode  (boolean) — the game also has a mode for several players
--                           around one reader. It is then listed twice under
--                           Tools → Games: as itself in its own category, and
--                           as "<menu_text> · multiplayer" under Party & quiz.
--                           :createScreen() reads self.launch_mode ("solo" or
--                           "party") to know which one was picked; a screen
--                           that lets the player switch mode sets
--                           plugin.launch_mode too, so "Recently played"
--                           follows the mode last played.
--
-- Subclasses may override:
--   :addToMainMenu(menu_items)  — for extra menu entries
-- ---------------------------------------------------------------------------

local PluginBase = WidgetContainer:extend{
    name        = "game",
    menu_text   = _("Game"),
    menu_hint   = "tools",
    party_mode  = false,
    launch_mode = "solo",
    is_doc_only = false,
}

-- ---------------------------------------------------------------------------
-- Settings
-- ---------------------------------------------------------------------------

-- Stable plugin id.
--
-- self.name is NOT stable: ReaderUI/FileManager:registerModule() rewrites it
-- to "reader"..name / "filemanager"..name right after the instance is built,
-- so anything reading self.name after :init() sees a different string
-- depending on where the game was launched from. Capture it once, at init
-- time, and key settings and stats on that instead.
function PluginBase:getPluginId()
    if not self.plugin_id then
        self.plugin_id = self.name
    end
    return self.plugin_id
end

function PluginBase:ensureSettings()
    if not self.settings_file then
        self.settings_file = DataStorage:getSettingsDir() .. "/" .. self:getPluginId() .. ".lua"
    end
    if not self.settings then
        self.settings = LuaSettings:open(self.settings_file)
    end
end

function PluginBase:saveState(data, key)
    self:ensureSettings()
    self.settings:saveSetting(key or "state", data)
    self.settings:flush()
end

function PluginBase:loadState(key)
    self:ensureSettings()
    return self.settings:readSetting(key or "state")
end

function PluginBase:saveSetting(key, value)
    self:ensureSettings()
    self.settings:saveSetting(key, value)
    self.settings:flush()
end

function PluginBase:getSetting(key, default)
    self:ensureSettings()
    local v = self.settings:readSetting(key)
    if v == nil then return default end
    return v
end

-- ---------------------------------------------------------------------------
-- Menu registration
-- ---------------------------------------------------------------------------

-- Deliberately no Dispatcher:registerAction() here. Exposing each game as a
-- gesture action would put one entry per installed plugin into KOReader's
-- action picker -- around 60 of them on a full install -- which buries the
-- actions a reader actually reaches for. Games are launched from the Tools
-- menu instead — all of them from its one "Games" entry (games_menu.lua),
-- grouped by category, rather than one Tools entry each.

function PluginBase:init()
    self:ensureSettings()
    self.ui.menu:registerToMainMenu(self)
end

-- Timestamp field of the game_stats.lua row that each mode's menu entry
-- sorts "Recently played" by (last_played is kept for Dashboard).
local MODE_FIELD = { solo = "last_solo_played", party = "last_party_played" }

function PluginBase:addToMainMenu(menu_items)
    local id = self:getPluginId()
    if not self.party_mode then
        GamesMenu.add(menu_items, {
            id     = id,
            label  = self.menu_text,
            launch = function() self:showGame() end,
        })
        return
    end
    GamesMenu.add(menu_items, {
        id          = id,
        label       = self.menu_text,
        stats_field = MODE_FIELD.solo,
        launch      = function() self:showGame("solo") end,
    })
    GamesMenu.add(menu_items, {
        id          = id .. ":party",
        label       = T(_("%1 · multiplayer"), self.menu_text),
        category    = "party",
        stats_id    = id,
        stats_field = MODE_FIELD.party,
        launch      = function() self:showGame("party") end,
    })
end

-- ---------------------------------------------------------------------------
-- KOReader >= 2026.07 plugin management (PluginLoader, PR #15240)
--
-- :stopPlugin() is called before the plugin directory is deleted, and
-- :deletePluginSettings() when the user asks for the settings to go too.
-- PluginLoader removes self.settings_file itself, so all that is left here is
-- this plugin's row in the shared game_stats.lua -- otherwise a deleted game
-- keeps showing up in Dashboard's stats forever.
-- ---------------------------------------------------------------------------

function PluginBase:stopPlugin()
    if self.screen then
        UIManager:close(self.screen)
        self.screen = nil
    end
end

function PluginBase:deletePluginSettings()
    StatsExporter:remove(self:getPluginId())
end

-- ---------------------------------------------------------------------------
-- Screen lifecycle
-- ---------------------------------------------------------------------------

-- mode: "solo" or "party", only meaningful when self.party_mode is set.
function PluginBase:showGame(mode)
    if self.screen then return end
    if mode then self.launch_mode = mode end
    self._session_start = os.time()
    self.screen = self:createScreen()
    UIManager:show(self.screen)
end

function PluginBase:onScreenClosed()
    local elapsed = self._session_start and (os.time() - self._session_start) or 0
    self._session_start = nil
    local id  = self:getPluginId()
    local cur = StatsExporter:get(id) or {}
    local rec = {
        sessions    = (cur.sessions or 0) + 1,
        last_played = os.time(),
        time_played = (cur.time_played or 0) + elapsed,
    }
    if self.party_mode then
        rec[MODE_FIELD[self.launch_mode] or MODE_FIELD.solo] = rec.last_played
    end
    StatsExporter:record(id, rec)
    self.screen = nil
end

-- Stub — subclasses must implement this and return a Screen instance.
function PluginBase:createScreen()
    error(self:getPluginId() .. ": createScreen() not implemented")
end

return PluginBase
