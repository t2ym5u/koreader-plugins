return {
    ["Pairs: %1/%2 \xC2\xB7 Empty cells: %3"] = { fr = "Paires : %1/%2 · Cases vides : %3", es = "Parejas: %1/%2 \xC2\xB7 Casillas vacías: %3", de = "Paare: %1/%2 \xC2\xB7 Leere Felder: %3" },
    ["Congratulations! All paths connected!"] = { fr = "Félicitations ! Tous les chemins sont connectés !", es = "¡Felicidades! ¡Todos los caminos conectados!", de = "Glückwunsch! Alle Pfade verbunden!" },
    ["%1\xC3\x97%2 \xC2\xB7 %3 \xC2\xB7 Pairs: %4 \xC2\xB7 Empty: %5"] = { fr = "%1×%2 · %3 · Paires : %4 · Vides : %5", es = "%1\xC3\x97%2 \xC2\xB7 %3 \xC2\xB7 Parejas: %4 \xC2\xB7 Vacías: %5", de = "%1\xC3\x97%2 \xC2\xB7 %3 \xC2\xB7 Paare: %4 \xC2\xB7 Leer: %5" },
    ["Connect each pair of matching numbers with a path covering every cell."] = { fr = "Reliez chaque paire de nombres identiques par un chemin couvrant chaque case.", es = "Conecta cada pareja de números iguales con un camino que cubra cada casilla.", de = "Verbinde jedes Zahlenpaar mit einem Pfad, der jedes Feld abdeckt." },
    ["Numberlink"] = { fr = "Numberlink", es = "Numberlink", de = "Numberlink" },
}
