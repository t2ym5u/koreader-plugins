local _ = require("gettext")
return {
    fullname    = _("Numberlink"),
    description = _("Connect each pair of matching numbers with a path covering every cell."),
    version     = "1.5.3",
}
