local _ = require("gettext")

return {
    fullname    = _("Hangman"),
    description = _("Classic word-guessing game. Reveal the word before the hangman is drawn."),
    version     = "1.3.0",
}
