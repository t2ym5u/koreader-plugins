local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"
package.path = _dir .. "?.lua;" .. _dir .. "common/?.lua;" .. package.path

local function lrequire(name)
    local key = _dir .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. name .. ".lua"))()
    end
    return package.loaded[key]
end

local PluginBase    = require("plugin_base")
local _             = require("i18n")

require("i18n").extend(lrequire("i18n_fr"))
local HangmanScreen = lrequire("screen")

local Hangman = PluginBase:extend{
    name      = "hangman",
    menu_text = _("Hangman"),
    menu_hint = "tools",
    -- "Hangman · multiplayer": teams take turns on one word.
    party_mode = true,
}

function Hangman:createScreen()
    return HangmanScreen:new{ plugin = self }
end

return Hangman
