return {
    ["ssl.https not available"]  = { fr = "ssl.https non disponible" },
    ["ltn12 not available"]      = { fr = "ltn12 non disponible" },
    ["HTTP %s"]                  = { fr = "HTTP %s" },
    ["rapidjson not available"]  = { fr = "rapidjson non disponible" },
    ["JSON parse error"]         = { fr = "Erreur d'analyse JSON" },

    ["Plugin Manager: %d update(s) available."] = { fr = "Gestionnaire de plugins : %d mise(s) à jour disponible(s)." },
    ["Remove"]                   = { fr = "Supprimer" },
    ["Cancel"]                   = { fr = "Annuler" },
    ["Close"]                    = { fr = "Fermer" },

    ["Download failed: %s \u{2014} %s"] = { fr = "Échec du téléchargement : %s — %s" },
    ["Write failed: %s \u{2014} %s"]    = { fr = "Échec de l'écriture : %s — %s" },
    ["Installing %s\u{2026}"]    = { fr = "Installation de %s…" },
    ["Shared library error:"]    = { fr = "Erreur de bibliothèque partagée :" },
    ["%s v%s installed.\nPlease restart KOReader to apply the update."] = { fr = "%s v%s installé.\nRedémarrez KOReader pour appliquer la mise à jour." },
    ["%s v%s installed."]        = { fr = "%s v%s installé." },
    ["Install failed:"]          = { fr = "Échec de l'installation :" },
    ["%s removed."]              = { fr = "%s supprimé." },

    ["Update to v%s"]            = { fr = "Mettre à jour vers v%s" },
    ["Reinstall current"]        = { fr = "Réinstaller la version actuelle" },
    ["Reinstall"]                 = { fr = "Réinstaller" },
    ["Remove %s?\nAll plugin files will be deleted."] = { fr = "Supprimer %s ?\nTous les fichiers du plugin seront supprimés." },
    ["Install"]                  = { fr = "Installer" },
    ["No plugins installed.\nPress Update to fetch the list."] = { fr = "Aucun plugin installé.\nAppuyez sur Mettre à jour pour récupérer la liste." },
    ["Plugins"]                  = { fr = "Plugins" },

    ["invalid manifest"]         = { fr = "manifeste invalide" },
    ["Network error:"]           = { fr = "Erreur réseau :" },
    ["All plugins are up to date."] = { fr = "Tous les plugins sont à jour." },
    ["Removed superseded %s."]   = { fr = "%s obsolète supprimé." },
    ["%d/%d done. Failures:"]    = { fr = "%d/%d terminé(s). Échecs :" },
    ["%d plugin(s) updated/installed."] = { fr = "%d plugin(s) mis à jour/installé(s)." },
    ["Please restart KOReader to apply the Plugin Manager update."] = { fr = "Redémarrez KOReader pour appliquer la mise à jour du gestionnaire de plugins." },
    ["%d/%d  %s\u{2026}"]        = { fr = "%d/%d  %s…" },
    ["Updating %d plugin(s)\u{2026}"] = { fr = "Mise à jour de %d plugin(s)…" },

    ["Fetching plugin list\u{2026}"] = { fr = "Récupération de la liste des plugins…" },
    ["No plugins installed."]    = { fr = "Aucun plugin installé." },
    ["%d plugin(s) reinstalled."] = { fr = "%d plugin(s) réinstallé(s)." },
    ["Reinstalling %d plugin(s)\u{2026}"] = { fr = "Réinstallation de %d plugin(s)…" },

    ["Plugin Manager"]           = { fr = "Gestionnaire de plugins" },
    ["Update"]                   = { fr = "Mettre à jour" },
    ["Reinstall all\u{2026}"]    = { fr = "Tout réinstaller…" },
    ["Reinstall every installed plugin?\nThis re-downloads all their files, including shared libraries."] = { fr = "Réinstaller tous les plugins installés ?\nCela retélécharge tous leurs fichiers, y compris les bibliothèques partagées." },
    ["Reinstall all"]            = { fr = "Tout réinstaller" },
    ["Plugin list"]              = { fr = "Liste des plugins" },

    ["Remove all\u{2026}"]       = { fr = "Tout supprimer…" },
    ["Remove every plugin managed by Plugin Manager?\nAll their files will be deleted. Plugin Manager itself and any other plugin on your device (including KOReader's own) are left untouched."] = { fr = "Supprimer tous les plugins gérés par le Gestionnaire de plugins ?\nTous leurs fichiers seront supprimés. Le Gestionnaire de plugins lui-même et tout autre plugin de votre liseuse (y compris ceux de KOReader) ne seront pas touchés." },
    ["Remove all"]               = { fr = "Tout supprimer" },
    ["No plugins to remove."]    = { fr = "Aucun plugin à supprimer." },
    ["%d plugin(s) removed."]    = { fr = "%d plugin(s) supprimé(s)." },

    ["\u{2713} Wi-Fi on"]         = { fr = "✓ Wi-Fi activé" },
    ["\u{2717} Wi-Fi off"]        = { fr = "✗ Wi-Fi désactivé" },

    ["Enable"]                    = { fr = "Activer" },
    ["Disable"]                   = { fr = "Désactiver" },
    ["%s enabled.\nRestart KOReader to apply."]  = { fr = "%s activé.\nRedémarrez KOReader pour appliquer." },
    ["%s disabled.\nRestart KOReader to apply."] = { fr = "%s désactivé.\nRedémarrez KOReader pour appliquer." },
    ["[DISABLED]"]                = { fr = "[DÉSACTIVÉ]" },

    ["Ignore v%s"]                = { fr = "Ignorer v%s" },
    ["v%s will be hidden from updates until a newer version is released.\nSee \u{201c}Ignored updates\u{2026}\u{201d} in the main menu to undo."]
        = { fr = "v%s sera masqué des mises à jour jusqu'à la sortie d'une version plus récente.\nVoir « Mises à jour ignorées… » dans le menu principal pour annuler." },
    ["Ignored updates\u{2026}"]   = { fr = "Mises à jour ignorées…" },
    ["Ignored updates"]           = { fr = "Mises à jour ignorées" },
    ["No ignored updates."]       = { fr = "Aucune mise à jour ignorée." },
    ["Un-ignore"]                 = { fr = "Ne plus ignorer" },

    ["README\u{2026}"]            = { fr = "README…" },
    ["No README available for this source."] = { fr = "Aucun README disponible pour cette source." },
    ["Fetching README\u{2026}"]   = { fr = "Récupération du README…" },
    ["README download failed:"]  = { fr = "Échec du téléchargement du README :" },
    ["README: %s"]                = { fr = "README : %s" },

    ["Filter plugins"]            = { fr = "Filtrer les plugins" },
    ["Plugin name\u{2026}"]       = { fr = "Nom du plugin…" },
    ["Clear"]                     = { fr = "Effacer" },
    ["Filter"]                    = { fr = "Filtrer" },
    ["Filter: %s"]                = { fr = "Filtre : %s" },
    ["Sorted by status (updates first)."] = { fr = "Trié par statut (mises à jour en premier)." },
    ["Sorted by name."]           = { fr = "Trié par nom." },
    ["Refresh"]                   = { fr = "Actualiser" },

    ["Discover plugins\u{2026}"]  = { fr = "Découvrir des plugins…" },
    ["Discover plugins"]          = { fr = "Découvrir des plugins" },
    ["Search GitHub plugins"]     = { fr = "Rechercher des plugins sur GitHub" },
    ["Search text (optional)\u{2026}"] = { fr = "Texte de recherche (optionnel)…" },
    ["Search"]                    = { fr = "Rechercher" },
    ["Search: %s"]                 = { fr = "Recherche : %s" },
    ["Searching GitHub\u{2026}"]  = { fr = "Recherche sur GitHub…" },
    ["Search failed:"]            = { fr = "Échec de la recherche :" },
    ["No results."]               = { fr = "Aucun résultat." },
    ["Load more\u{2026}"]          = { fr = "Charger plus…" },
    ["Sorted by stars."]          = { fr = "Trié par étoiles." },
    ["Sorted by last updated."]   = { fr = "Trié par dernière mise à jour." },
    ["GitHub API rate limit reached. Try again later, or set a GitHub token in pluginmanager_configuration.lua."]
        = { fr = "Limite de l'API GitHub atteinte. Réessayez plus tard, ou configurez un jeton GitHub dans pluginmanager_configuration.lua." },

    ["Install %s from GitHub?\nThis downloads and runs third-party code \u{2014} only install plugins you trust."]
        = { fr = "Installer %s depuis GitHub ?\nCeci télécharge et exécute du code tiers — n'installez que des plugins auxquels vous faites confiance." },
    ["Download failed:"]          = { fr = "Échec du téléchargement :" },
    ["Archive support not available."] = { fr = "Support des archives non disponible." },
    ["Failed to open downloaded archive."] = { fr = "Échec de l'ouverture de l'archive téléchargée." },
    ["No _meta.lua found in this repository's archive."] = { fr = "Aucun _meta.lua trouvé dans l'archive de ce dépôt." },
    ["Could not detect a plugin inside this repository."] = { fr = "Impossible de détecter un plugin dans ce dépôt." },
    ["Failed to extract %s"]      = { fr = "Échec de l'extraction de %s" },
    ["Installation failed:"]      = { fr = "Échec de l'installation :" },
    ["%s installed.\nPlease restart KOReader to load it."] = { fr = "%s installé.\nRedémarrez KOReader pour le charger." },

    ["(GitHub)"]                   = { fr = "(GitHub)" },
    ["(local)"]                    = { fr = "(local)" },
    ["Check for update"]           = { fr = "Vérifier les mises à jour" },
    ["Checking for updates\u{2026}"] = { fr = "Vérification des mises à jour…" },
    ["Update check failed:"]       = { fr = "Échec de la vérification :" },
    ["Could not read the remote version."] = { fr = "Impossible de lire la version distante." },
    ["Already up to date."]        = { fr = "Déjà à jour." },

    ["Clear filter"]                = { fr = "Effacer le filtre" },
    ["No results for \u{201c}%s\u{201d} (%d repositories are candidates in total, before that filter).\nClear the filter and search again?"]
        = { fr = "Aucun résultat pour « %s » (%d dépôts sont candidats au total, avant ce filtre).\nEffacer le filtre et relancer la recherche ?" },

    ["Type user:NAME to browse every .koplugin repo from one GitHub account."]
        = { fr = "Tapez user:NOM pour parcourir tous les dépôts .koplugin d'un compte GitHub." },
    ["No .koplugin repositories found for \u{201c}%s\u{201d}."] = { fr = "Aucun dépôt .koplugin trouvé pour « %s »." },
    ["Downloading %s\u{2026}"]    = { fr = "Téléchargement de %s…" },
    ["Install all %d shown\u{2026}"] = { fr = "Tout installer (%d affichés)…" },
    ["Install all %d plugins shown?"] = { fr = "Installer les %d plugins affichés ?" },
    ["GitHub's unauthenticated rate limit is low (60 requests/hour) and this many installs may hit it partway through; see Configuration in the README to set a token first."]
        = { fr = "La limite anonyme de l'API GitHub est basse (60 requêtes/heure) et ce nombre d'installations risque de la dépasser en cours de route ; voir la section Configuration du README pour définir un jeton au préalable." },
    ["Install all"]                = { fr = "Tout installer" },
    ["%d/%d installed. Failures:"] = { fr = "%d/%d installé(s). Échecs :" },
    ["%d plugin(s) installed.\nPlease restart KOReader to load them."]
        = { fr = "%d plugin(s) installé(s).\nRedémarrez KOReader pour les charger." },

    ["Link to GitHub repo\u{2026}"] = { fr = "Lier à un dépôt GitHub…" },
    ["Link to GitHub repo"]        = { fr = "Lier à un dépôt GitHub" },
    ["Unlink"]                      = { fr = "Délier" },
    ["Link"]                        = { fr = "Lier" },
    ["Link anyway"]                 = { fr = "Lier quand même" },
    ["Enter the owner/repo this plugin came from, e.g. t2ym5u/%s."]
        = { fr = "Entrez le owner/repo dont vient ce plugin, ex. t2ym5u/%s." },
    ["Enter as owner/repo, e.g. t2ym5u/sudoku.koplugin."]
        = { fr = "Entrez au format owner/repo, ex. t2ym5u/sudoku.koplugin." },
    ["Verifying repository\u{2026}"] = { fr = "Vérification du dépôt…" },
    ["Could not verify %s (no _meta.lua found on its default branch). Link anyway?"]
        = { fr = "Impossible de vérifier %s (aucun _meta.lua trouvé sur sa branche par défaut). Lier quand même ?" },
    ["Linked %s to %s."]            = { fr = "%s lié à %s." },

    ["v%s is available but ignored.\nSee \u{201c}Ignored updates\u{2026}\u{201d} in the main menu to undo."]
        = { fr = "v%s est disponible mais ignorée.\nVoir « Mises à jour ignorées… » dans le menu principal pour annuler." },
    ["%s: v%s \u{2192} v%s"]         = { fr = "%s : v%s \u{2192} v%s" },
    ["Search GitHub\u{2026}"]       = { fr = "Rechercher sur GitHub…" },
    ["Select repo for %s"]          = { fr = "Choisir un dépôt pour %s" },
    ["Link %s to %s?"]              = { fr = "Lier %s à %s ?" },

    ["the koreader-plugins repository"] = { fr = "le dépôt koreader-plugins" },
    ["an untracked local install"]  = { fr = "une installation locale non tracée" },
    ["%s v%s (from %s)"]            = { fr = "%s v%s (depuis %s)" },
    ["%s\nis already installed at %s.\nInstalling %s here will overwrite it. Continue?"]
        = { fr = "%s\nest déjà installé à %s.\nInstaller %s ici l'écrasera. Continuer ?" },
    ["Overwrite"]                    = { fr = "Écraser" },
    ["Cancelled: a different plugin already occupies this folder."]
        = { fr = "Annulé : un autre plugin occupe déjà ce dossier." },
}
