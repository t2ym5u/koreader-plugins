local _ = require("gettext")

return {
    fullname    = _("Plugin Manager"),
    description = _("Check for updates and install game plugins from the koreader-plugins repository."),
    version     = "1.2.0",
}
