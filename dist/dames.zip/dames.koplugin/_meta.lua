return {
    name        = "dames",
    version     = "1.1.7",
    fullname    = "Dames",
    description = "Jeu de dames 8x8",
}
