return {
    version     = "1.1.10",
    fullname    = "Dames",
    description = "Jeu de dames 8x8",
}
