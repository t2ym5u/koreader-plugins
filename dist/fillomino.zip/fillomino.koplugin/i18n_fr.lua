return {
    ["Check done. Empty cells: %1"]          = { fr = "Vérification effectuée. Cases vides : %1", es = "Verificación realizada. Casillas vacías: %1", de = "Prüfung abgeschlossen. Leere Zellen: %1" },
    ["Fill regions with matching numbers"]   = { fr = "Remplissez les régions avec des nombres correspondants", es = "Rellena las regiones con números coincidentes", de = "Fülle die Bereiche mit passenden Zahlen" },
    ["Fillomino"]                            = { fr = "Fillomino", es = "Fillomino", de = "Fillomino" },
}
