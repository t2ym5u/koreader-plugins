local _ = require("gettext")
return {
    fullname    = _("Taboo Party"),
    description = _("Describe words without saying the forbidden ones — team buzzer party game."),
    version     = "1.5.9",
}
