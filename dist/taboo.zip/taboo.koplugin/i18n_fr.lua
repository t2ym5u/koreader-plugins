return {
    ["Describe words without saying the forbidden ones — team buzzer party game."] = { fr = "Décrivez des mots sans dire les mots interdits — jeu de groupe en équipes avec buzzer.", es = "Describe palabras sin decir las prohibidas — juego de fiesta por equipos con timbre.", de = "Beschreibe Wörter, ohne die verbotenen zu nennen — Team-Partyspiel mit Buzzer." },
    ["Taboo Party"] = { fr = "Taboo Party", es = "Taboo Party", de = "Taboo Party" },
}
