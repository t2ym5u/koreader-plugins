local _ = require("gettext")
return {
    fullname    = _("Suguru"),
    description = _("Fill regions with non-repeating numbers"),
    version     = "1.5.1",
}
