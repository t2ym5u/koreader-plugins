return {
    ["%1 to play  Dice: %2"] = { fr = "%1 à jouer  Dés : %2" },
    ["%1 to play  Off W:%2 B:%3"] = { fr = "%1 à jouer  Sortis B:%2 N:%3" },
    ["%1 wins!"] = { fr = "%1 gagne !" },
    ["Backgammon"] = { fr = "Backgammon" },
    ["Black"] = { fr = "Noir" },
    ["Classic 2-player dice and checker race game."] = { fr = "Jeu de dés et de pions classique à 2 joueurs." },
    ["Finish using your current dice first."] = { fr = "Terminez d'utiliser vos dés actuels d'abord." },
    ["No more legal moves -- turn passed."] = { fr = "Plus aucun coup légal -- tour passé." },
    ["Rolled %1-%2 -- no legal moves, turn passed."] = { fr = "%1-%2 obtenu -- aucun coup légal, tour passé." },
    ["Rolled %1-%2."] = { fr = "%1-%2 obtenu." },
    ["White"] = { fr = "Blanc" },
    ["You must enter from the bar first."] = { fr = "Vous devez d'abord entrer depuis la barre." },
}
