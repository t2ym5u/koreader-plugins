return {
    ["%1 to play  Dice: %2"] = { fr = "%1 à jouer  Dés : %2", es = "%1 para jugar  Dados: %2", de = "%1 am Zug  Würfel: %2" },
    ["%1 to play  Off W:%2 B:%3"] = { fr = "%1 à jouer  Sortis B:%2 N:%3", es = "%1 para jugar  Fuera B:%2 N:%3", de = "%1 am Zug  Draußen W:%2 S:%3" },
    ["%1 wins!"] = { fr = "%1 gagne !", es = "¡%1 gana!", de = "%1 gewinnt!" },
    ["Backgammon"] = { fr = "Backgammon", es = "Backgammon", de = "Backgammon" },
    ["Black"] = { fr = "Noir", es = "Negras", de = "Schwarz" },
    ["Classic 2-player dice and checker race game."] = { fr = "Jeu de dés et de pions classique à 2 joueurs.", es = "Juego clásico de dados y fichas de carrera para 2 jugadores.", de = "Klassisches Würfel- und Steine-Wettlaufspiel für 2 Spieler." },
    ["Finish using your current dice first."] = { fr = "Terminez d'utiliser vos dés actuels d'abord.", es = "Termina de usar tus dados actuales primero.", de = "Verwende zuerst deine aktuellen Würfel vollständig." },
    ["No more legal moves -- turn passed."] = { fr = "Plus aucun coup légal -- tour passé.", es = "No quedan movimientos legales -- turno pasado.", de = "Keine legalen Züge mehr -- Zug ausgesetzt." },
    ["Rolled %1-%2 -- no legal moves, turn passed."] = { fr = "%1-%2 obtenu -- aucun coup légal, tour passé.", es = "%1-%2 obtenido -- sin movimientos legales, turno pasado.", de = "%1-%2 gewürfelt -- keine legalen Züge, Zug ausgesetzt." },
    ["Rolled %1-%2."] = { fr = "%1-%2 obtenu.", es = "%1-%2 obtenido.", de = "%1-%2 gewürfelt." },
    ["White"] = { fr = "Blanc", es = "Blancas", de = "Weiß" },
    ["You must enter from the bar first."] = { fr = "Vous devez d'abord entrer depuis la barre.", es = "Debes entrar desde la barra primero.", de = "Du musst zuerst von der Bar einsetzen." },
}
