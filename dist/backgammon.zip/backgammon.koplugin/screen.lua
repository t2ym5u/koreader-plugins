local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"
local function lrequire(name)
    local key = _dir .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. name .. ".lua"))()
    end
    return package.loaded[key]
end

local ButtonDialog    = require("ui/widget/buttondialog")
local FrameContainer  = require("ui/widget/container/framecontainer")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local Size            = require("ui/size")
local UIManager       = require("ui/uimanager")
local VerticalGroup   = require("ui/widget/verticalgroup")
local VerticalSpan    = require("ui/widget/verticalspan")
local _               = require("i18n")
local T               = require("ffi/util").template

local ScreenBase = require("screen_base")

local BackgammonBoard       = lrequire("board")
local BackgammonBoardWidget = lrequire("board_widget")

-- Board height over width.
local BOARD_ASPECT = 0.62

local GAME_RULES_EN = _([[
Backgammon — Rules (2-player pass-and-play)

White moves from point 24 toward point 1; Black moves from point 1 toward point 24. Roll the dice, then tap a checker to select it and tap a destination to move it by that many points. Doubles give 4 moves instead of 2.

A point with a single opposing checker (a blot) can be hit, sending it to the bar. A checker on the bar must re-enter the board before any other move. Once all 15 of your checkers are in your home board, you may bear them off.

A computer opponent is available from the options menu (it plays Black); otherwise two players share the device. Each side rolls one die to open and the higher starts. A turn must use as many dice as it legally can, and when only one of the two can be played it must be the higher. The doubling cube is available before rolling: accepting doubles the stake and passes the cube, declining ends the game at the stake before it.
]])

local GAME_RULES_FR = [[
Backgammon — Règles

Les Blancs vont du point 24 vers le point 1 ; les Noirs vont du point 1 vers le point 24. Lancez les dés, puis touchez un pion pour le sélectionner et touchez une destination pour le déplacer. Un double donne 4 déplacements au lieu de 2.

Un point occupé par un seul pion adverse (isolé) peut être pris, l'envoyant sur la barre. Un pion sur la barre doit rentrer avant tout autre déplacement. Une fois vos 15 pions dans votre jan intérieur, vous pouvez les sortir.

Un adversaire informatique est disponible depuis le menu des options (il joue les Noirs) ; sinon deux joueurs partagent l'appareil. Chaque camp lance un dé pour l'ouverture, le plus fort commence. Un tour doit utiliser autant de dés qu'il le peut légalement, et quand un seul des deux est jouable, ce doit être le plus grand. Le videau est disponible avant de lancer : accepter double l'enjeu et transmet le videau, refuser met fin à la partie à l'enjeu d'avant.
]]

local BackgammonScreen = ScreenBase:extend{}

function BackgammonScreen:init()
    local state = self.plugin:loadState()
    self.board = BackgammonBoard:new()
    if not self.board:load(state) then
        self.board:reset()
        self.board:rollOpening()
    end
    ScreenBase.init(self)
    -- A saved game may reopen on the computer's turn, and a first opening
    -- roll may hand it the move: nothing else would start it.
    self:maybeRunAI()
end

-- ---------------------------------------------------------------------------
-- Opponent
--
-- The AI always plays Black, so a solo player keeps the opening roll's verdict
-- rather than being handed a colour. Its whole turn is computed at once (see
-- board:getAITurn) and then applied move by move, with a pause between each so
-- the checkers can be seen travelling instead of teleporting.
-- ---------------------------------------------------------------------------

local AI_COLOR       = "black"
local AI_MOVE_DELAY  = 0.45   -- seconds between the AI's individual moves

function BackgammonScreen:isSolo()
    return self.plugin:getSetting("opponent", "human") == "ai"
end

function BackgammonScreen:getOpponentButtonText()
    return self:isSolo() and _("Opponent: Computer") or _("Opponent: Human")
end

function BackgammonScreen:toggleOpponent()
    self.plugin:saveSetting("opponent", self:isSolo() and "human" or "ai")
    self:updateStatus(self:isSolo()
        and _("The computer now plays Black.")
        or  _("Two players on one device."))
    self:maybeRunAI()
end

-- What the AI planned for the rest of its turn, valid only while the board
-- is exactly where the plan left it (an undo, a load or a new game changes
-- that and the turn is simply planned again).
local function planKey(board)
    return board:_positionKey() .. "#" .. table.concat(board.remaining_dice, ",") .. board.turn
end

-- `rolled`: the "Computer rolled ..." line to keep on screen while it thinks.
function BackgammonScreen:maybeRunAI(rolled)
    local board = self.board
    if not self:isSolo() then return end
    if board.status ~= "playing" or board.turn ~= AI_COLOR then return end
    if self.ai_thinking then return end
    self.ai_thinking = true

    local plan = self.ai_plan
    if plan and plan.key ~= planKey(board) then plan, self.ai_plan = nil, nil end
    if #board.remaining_dice > 0 and not plan then
        -- The whole turn is searched before the first move (a fraction of
        -- a second on an e-reader, a little more with doubles).
        self:updateStatus(rolled and self:joinStatus(rolled, _("AI is thinking..."))
                          or _("AI is thinking..."))
    end

    self:schedule(AI_MOVE_DELAY, function()
        -- Re-checked: the opponent may have been switched to a human meanwhile.
        if not self:isSolo() or board.status ~= "playing" or board.turn ~= AI_COLOR then
            self.ai_thinking = false
            return
        end
        if #board.remaining_dice == 0 then
            self.ai_plan = nil
            local dice = board:rollDice()
            self.board_widget:refresh(self)
            self.ai_thinking = false
            if dice then
                local msg = T(_("Computer rolled %1-%2."), dice[1], dice[2])
                self:updateStatus(msg)
                self:maybeRunAI(msg)
            else
                self:maybeRunAI()
            end
            return
        end

        local moves = plan and plan.moves
        if not moves then moves = board:getAITurn() end
        self.ai_plan = nil
        if #moves == 0 then
            board:endTurn()
        else
            -- Apply only the first move here and come back for the rest, so
            -- each one gets its own refresh.
            local mv = moves[1]
            if board:applyMove(mv.from, mv.die) == "invalid" then
                board:endTurn()
            elseif #moves > 1 and board.turn == AI_COLOR then
                local rest = {}
                for i = 2, #moves do rest[#rest + 1] = moves[i] end
                self.ai_plan = { moves = rest, key = planKey(board) }
            end
        end
        self.board_widget:refresh(self)
        self.plugin:saveState(self.board:serialize())
        self:updateStatus()
        self.ai_thinking = false
        self:maybeRunAI()
    end)
end

-- Bearing off all fifteen checkers, or a declined double, ends the game.
function BackgammonScreen:isRoundOver()
    return self.board.status ~= "playing"
end

function BackgammonScreen:serializeState()
    return self.board:serialize()
end

function BackgammonScreen:buildLayout()
    local is_landscape = self:isLandscape()

    local title_bar = self:buildTitleBar(_("Backgammon"), function()
        return {
            { text = _("New game"), callback = function() self:onNewGame() end },
            { text = self:getOpponentButtonText(), callback = function() self:toggleOpponent() end },
            self:makeRulesButtonConfig(GAME_RULES_EN, GAME_RULES_FR),
        }
    end)

    local function buildControls(width)
        self.status_text:setMaxWidth(width)
        return VerticalGroup:new{
            align = "center",
            self.status_text,
            VerticalSpan:new{ width = Size.span.vertical_large },
            self:buildActionBar({
                { text = _("Roll dice"), callback = function() self:onRoll() end },
                { id = "double_btn", text = _("Double"), callback = function() self:onDouble() end },
            }, width),
        }
    end

    -- The board is wider than tall (BOARD_ASPECT): fit it inside both sides
    -- of the budget. The widget paints its own outer border, so the frame
    -- only pads.
    local frame_pad = Size.padding.default
    local frame_extra = 2 * frame_pad
    local function fitWidth(budget_w, budget_h)
        return math.min(budget_w - frame_extra,
                        math.floor((budget_h - frame_extra) / BOARD_ASPECT))
    end

    local controls = buildControls(self:getControlsWidth())
    local board_w = fitWidth(self:getBoardBudget(title_bar, controls))

    -- A side panel suits a square board; this one is so wide that, in
    -- landscape, the panel would cost it far more width than the controls
    -- cost it height underneath. Stack them whenever that gives more board.
    local stacked = not is_landscape
    if is_landscape then
        local g = self:getGutter()
        local full_w = self.dimen.w - 2 * g
        local below = buildControls(full_w)
        local stacked_w = fitWidth(full_w,
            self.dimen.h - title_bar:getSize().h - below:getSize().h - 3 * g)
        if stacked_w > board_w then
            stacked, controls, board_w = true, below, stacked_w
        else
            controls = buildControls(self:getControlsWidth())
        end
    end
    local board_h = math.floor(board_w * BOARD_ASPECT)

    self.board_widget = BackgammonBoardWidget:new{
        board        = self.board,
        width        = board_w,
        height       = board_h,
        onCellAction = function(zone) self:onCellAction(zone) end,
    }

    local board_frame = FrameContainer:new{
        padding    = frame_pad,
        margin     = 0,
        bordersize = 0,
        self.board_widget,
    }

    if not stacked then
        local content = HorizontalGroup:new{
            align = "center",
            board_frame,
            HorizontalSpan:new{ width = self:getGutter() },
            controls,
        }
        self:buildLandscapeLayout(title_bar, content)
    else
        self:buildPortraitLayout(title_bar, board_frame,
            VerticalGroup:new{ align = "center", controls, VerticalSpan:new{ width = self:getGutter() } })
    end
    self:updateStatus()
end

-- ---------------------------------------------------------------------------
-- Doubling cube
-- ---------------------------------------------------------------------------

function BackgammonScreen:onDouble()
    local board = self.board
    if board.status ~= "playing" then return end
    if not board:canDouble() then
        if #board.remaining_dice > 0 then
            self:updateStatus(_("Double before rolling, not after."))
        elseif board.cube_owner and board.cube_owner ~= board.turn then
            self:updateStatus(_("Your opponent owns the cube."))
        else
            self:updateStatus(_("The cube is already at its maximum."))
        end
        return
    end

    local offerer = board.turn
    board:offerDouble(offerer)
    local stake = board.cube_value * 2
    local label = (offerer == "white") and _("White side") or _("Black side")

    -- Against the computer there is nobody to hand the dialog to: it answers.
    -- The rule is the simplest sound one -- take unless clearly behind in the
    -- race -- which is roughly right and never absurd. A player more than a
    -- quarter behind on pips is losing badly enough to drop.
    if self:isSolo() and offerer ~= AI_COLOR then
        local mine  = board:pipCount(AI_COLOR)
        local yours = board:pipCount(offerer)
        if mine > yours * 1.25 then
            board:declineDouble()
            self.plugin:saveState(self:serializeState())
            self:updateStatus()
            self:showMessage(T(_("The computer declines. %1 wins %2 point(s)."),
                               label, board:stake()), 4)
        else
            board:acceptDouble()
            self.plugin:saveState(self:serializeState())
            self:updateStatus(T(_("The computer accepts. Stake is now %1."), board.cube_value))
        end
        return
    end

    -- The answer is the opponent's, so it is asked outright rather than left
    -- as another button on a shared board.
    local dlg
    dlg = ButtonDialog:new{
        title   = T(_("%1 offers to double the stake to %2."), label, stake),
        buttons = {{
            { text = _("Accept"), callback = function()
                UIManager:close(dlg)
                board:acceptDouble()
                self.plugin:saveState(self:serializeState())
                self:updateStatus(T(_("Double accepted. Stake is now %1."), board.cube_value))
                self:maybeRunAI()
            end },
            { text = _("Decline"), callback = function()
                UIManager:close(dlg)
                board:declineDouble()
                self.plugin:saveState(self:serializeState())
                self:updateStatus()
                self:showMessage(T(_("%1 wins %2 point(s)."), label, board:stake()), 4)
            end },
        }},
    }
    UIManager:show(dlg)
end

function BackgammonScreen:onRoll()
    local board = self.board
    if board.status ~= "playing" then return end
    if #board.remaining_dice > 0 then
        self:updateStatus(_("Finish using your current dice first."))
        return
    end

    local dice = board:rollDice()
    self.board_widget:refresh(self)
    self.plugin:saveState(self:serializeState())

    if not dice then
        return
    elseif #board.remaining_dice == 0 then
        self:updateStatus(T(_("Rolled %1-%2 -- no legal moves, turn passed."), dice[1], dice[2]))
        self:maybeRunAI()
    else
        self:updateStatus(T(_("Rolled %1-%2."), dice[1], dice[2]))
    end
end

function BackgammonScreen:onCellAction(zone)
    local board = self.board
    if board.status ~= "playing" then return end
    if #board.remaining_dice == 0 then
        self:updateStatus(_("Roll the dice first."))
        return
    end

    if not board.selected then
        if board.bar[board.turn] > 0 and zone ~= "bar" then
            self:updateStatus(_("You must enter from the bar first."))
            return
        end
        if zone == "bar" then
            if board.bar[board.turn] > 0 then
                board.selected = { from = "bar" }
                self.board_widget:refresh(self)
            end
        elseif type(zone) == "number" then
            local pt = board.points[zone]
            if pt.color == board.turn and pt.count > 0 then
                board.selected = { from = zone }
                self.board_widget:refresh(self)
            end
        end
        return
    end

    local sel_from = board.selected.from
    if zone == sel_from then
        board.selected = nil
        self.board_widget:refresh(self)
        return
    end

    local dest = (zone == "off_white" or zone == "off_black") and "off" or zone

    local applied_die = nil
    for _, d in ipairs(board.remaining_dice) do
        for _, m in ipairs(board:getLegalMoves(d)) do
            if m.from == sel_from and m.to == dest then
                applied_die = d
                break
            end
        end
        if applied_die then break end
    end

    board.selected = nil

    if not applied_die then
        self.board_widget:refresh(self)
        self:updateStatus(_("Invalid move."))
        return
    end

    local result = board:applyMove(sel_from, applied_die)
    self.board_widget:refresh(self)
    self.plugin:saveState(self:serializeState())

    if result == "won" then
        self:updateStatus()
        local winner_label = board.winner == "white" and _("White side") or _("Black side")
        self:showMessage(T(_("%1 wins!"), winner_label), 4)
    elseif result == "turn_ended" then
        self:updateStatus(_("No more legal moves -- turn passed."))
        self:maybeRunAI()
    else
        self:updateStatus()
    end
end

function BackgammonScreen:onNewGame()
    self:cancelScheduled()  -- an AI move still pending belongs to the old game
    self.ai_thinking = false
    self.ai_plan = nil
    self.board:reset()
    self.board:rollOpening()
    self.plugin:saveState(self.board:serialize())
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
    self:maybeRunAI()
end

function BackgammonScreen:updateStatus(msg)
    local status
    if msg then
        status = msg
    elseif self.board.status == "ended" then
        local winner_label = self.board.winner == "white" and _("White side") or _("Black side")
        status = T(_("%1 wins %2 point(s)!"), winner_label, self.board:stake())
    else
        local board = self.board
        local dice
        if #board.remaining_dice > 0 then
            dice = T(_("Dice: %1"), table.concat(board.remaining_dice, ","))
        else
            dice = T(_("Off: W%1 B%2"), board.off.white, board.off.black)
        end
        status = self:joinStatus(
            board.turn == "white" and _("White to play") or _("Black to play"),
            dice,
            T(_("Stake: %1"), board.cube_value or 1))
    end
    ScreenBase.updateStatus(self, status)
    -- Every move, roll and cube answer (player's or computer's) ends here.
    self:refreshActionBar()
end

return BackgammonScreen
