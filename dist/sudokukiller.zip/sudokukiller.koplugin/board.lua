local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"
local function lrequire_common(name)
    local key = _dir .. "common/" .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. "common/" .. name .. ".lua"))()
    end
    return package.loaded[key]
end

local grid_utils       = lrequire_common("sudoku_grid_utils")
local puzzle_generator = lrequire_common("puzzle_generator")
local BaseBoard        = lrequire_common("base_board")
local logic_solver     = lrequire_common("logic_solver")

local emptyGrid       = grid_utils.emptyGrid
local emptyNotes      = grid_utils.emptyNotes
local emptyMarkerGrid = grid_utils.emptyMarkerGrid
local copyGrid        = grid_utils.copyGrid
local copyNotes       = grid_utils.copyNotes

local generateSolvedBoard = puzzle_generator.generateSolvedBoard

local bit    = require("bit")
local band   = bit.band
local bor    = bit.bor
local bnot   = bit.bnot
local lshift = bit.lshift

-- ---------------------------------------------------------------------------
-- Difficulty configurations
-- ---------------------------------------------------------------------------

local DEFAULT_DIFFICULTY = "medium"

local CAGE_COUNT_RANGES = {
    easy   = { min = 28, max = 32 },
    medium = { min = 22, max = 27 },
    hard   = { min = 16, max = 21 },
    expert = { min = 12, max = 16 },
}

local CAGE_MAX_SIZE = {
    easy   = 3,
    medium = 5,
    hard   = 6,
    expert = 7,
}

-- A "true" Killer Sudoku (0 given digits, purely random cage growth) is only
-- solvable by deduction when the cage geometry happens to enable techniques
-- like the 45-rule -- random growth rarely produces that by luck (empirically
-- near 0% of the time). Easy and Medium therefore get a handful of deliberate
-- single-cell "given" cages to bootstrap deduction; Hard/Expert stay
-- genre-pure (0 givens, guessing expected) with unchanged behavior.
local GIVEN_COUNT_RANGES = {
    easy   = { min = 10, max = 14 },
    medium = { min = 12, max = 16 },
}

-- Generation of a cage layout is not guaranteed to yield a puzzle with a
-- unique solution (cage sums alone are a weak constraint). We retry a bounded
-- number of times and verify with a budgeted solver, preferring a proven-
-- unique layout, falling back to an unproven-but-not-disproven one, and
-- finally to whatever the last attempt produced.
local CAGE_GEN_MAX_ATTEMPTS = 5
local CAGE_SOLVER_NODE_BUDGET = 6000

-- Easy/Medium additionally require the layout to be fully solvable with
-- beginner/intermediate techniques (no backtracking) -- see isHumanSolvable.
-- Per-attempt hit rate for that is well under 100%, so these tiers get a
-- larger retry budget; Hard/Expert don't use this gate at all.
local HUMAN_SOLVABLE_DIFFICULTIES = { easy = true, medium = true }
local HUMAN_SOLVABLE_MAX_ATTEMPTS = 30

-- ---------------------------------------------------------------------------
-- Cage generator
-- ---------------------------------------------------------------------------

-- The no-duplicate-digit growth constraint (below) frequently strands cells
-- that end up as their own 1-cell cage (an incidental given digit). These
-- accidental givens are unpredictable in count and placement, so fold each
-- one into an adjacent cage when that doesn't introduce a duplicate digit or
-- exceed max_size -- deliberate givens placed by generateCages (cage.is_given)
-- are exempt: those are load-bearing for Easy/Medium human-solvability.
local function mergeStraySingletons(cages, solution, n, max_size)
    local cell_cage = {}
    for r = 1, n do
        cell_cage[r] = {}
        for c = 1, n do cell_cage[r][c] = 0 end
    end
    for _, cage in ipairs(cages) do
        for _, cell in ipairs(cage.cells) do
            cell_cage[cell.r][cell.c] = cage.id
        end
    end

    local dirs = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } }
    for _, cage in ipairs(cages) do
        if #cage.cells == 1 and not cage.merged_away and not cage.is_given then
            local cell = cage.cells[1]
            local candidates = {}
            for _, d in ipairs(dirs) do
                local nr, nc = cell.r + d[1], cell.c + d[2]
                if nr >= 1 and nr <= n and nc >= 1 and nc <= n then
                    local ncage = cages[cell_cage[nr][nc]]
                    if ncage and ncage ~= cage and not ncage.merged_away and not ncage.is_given
                        and #ncage.cells < max_size then
                        local v, dup = solution[cell.r][cell.c], false
                        for _, c2 in ipairs(ncage.cells) do
                            if solution[c2.r][c2.c] == v then dup = true; break end
                        end
                        if not dup then candidates[#candidates + 1] = ncage end
                    end
                end
            end
            if #candidates > 0 then
                local target = candidates[math.random(#candidates)]
                target.cells[#target.cells + 1] = cell
                target.sum = target.sum + solution[cell.r][cell.c]
                cage.merged_away = true
            end
        end
    end

    local final_cages = {}
    for _, cage in ipairs(cages) do
        if not cage.merged_away then
            cage.id = #final_cages + 1
            final_cages[cage.id] = cage
        end
    end
    for r = 1, n do
        for c = 1, n do cell_cage[r][c] = 0 end
    end
    for _, cage in ipairs(final_cages) do
        for _, cell in ipairs(cage.cells) do
            cell_cage[cell.r][cell.c] = cage.id
        end
    end
    return final_cages, cell_cage
end

local function generateCages(solution, difficulty, n)
    local range        = CAGE_COUNT_RANGES[difficulty] or CAGE_COUNT_RANGES.medium
    local target_count = math.random(range.min, range.max)
    local max_size     = CAGE_MAX_SIZE[difficulty] or CAGE_MAX_SIZE.medium

    local assigned = {}
    for r = 1, n do
        assigned[r] = {}
        for c = 1, n do assigned[r][c] = false end
    end
    local unassigned_count = n * n

    local dirs = { {-1, 0}, {1, 0}, {0, -1}, {0, 1} }
    local function unassignedNeighbors(r, c)
        local nb = {}
        for _, d in ipairs(dirs) do
            local nr, nc = r + d[1], c + d[2]
            if nr >= 1 and nr <= n and nc >= 1 and nc <= n and not assigned[nr][nc] then
                nb[#nb + 1] = { r = nr, c = nc }
            end
        end
        return nb
    end

    local cell_list = {}
    for r = 1, n do
        for c = 1, n do cell_list[#cell_list + 1] = { r = r, c = c } end
    end
    for i = #cell_list, 2, -1 do
        local j = math.random(i)
        cell_list[i], cell_list[j] = cell_list[j], cell_list[i]
    end

    local cages = {}

    -- Deliberate single-cell "given" cages, placed first (cell_list is already
    -- shuffled, so the first N cells are a random sample). Marked is_given so
    -- mergeStraySingletons never folds them away -- Easy/Medium need these as
    -- anchor points for human-solvable deduction (see GIVEN_COUNT_RANGES).
    -- given_target cages are ADDITIONAL to target_count: they're bumped onto
    -- target_count below so the growth loop still gets its full nominal cage
    -- budget for the remaining cells (otherwise, at max_size == 3, easy's
    -- growth cages couldn't cover the cells left over after ~12 givens, and
    -- cells would spill into unplanned forced singletons/oversized cages).
    local given_range  = GIVEN_COUNT_RANGES[difficulty]
    local given_target = given_range and math.random(given_range.min, given_range.max) or 0
    given_target = math.min(given_target, n * n - 1)
    target_count = target_count + given_target
    for i = 1, given_target do
        local cell = cell_list[i]
        if not assigned[cell.r][cell.c] then
            local cage_id = #cages + 1
            cages[cage_id] = {
                id       = cage_id,
                cells    = { { r = cell.r, c = cell.c } },
                sum      = solution[cell.r][cell.c],
                is_given = true,
            }
            assigned[cell.r][cell.c] = true
            unassigned_count = unassigned_count - 1
        end
    end

    for _, seed in ipairs(cell_list) do
        if #cages >= target_count then break end
        if not assigned[seed.r][seed.c] then
            local cage_id = #cages + 1
            local cage = {
                id    = cage_id,
                cells = { { r = seed.r, c = seed.c } },
                sum   = solution[seed.r][seed.c],
            }
            -- Killer-sudoku cages must not contain the same digit twice.
            local used_digits = { [solution[seed.r][seed.c]] = true }
            assigned[seed.r][seed.c] = true
            unassigned_count = unassigned_count - 1

            local remaining_cages = target_count - cage_id
            local safe_max
            if remaining_cages > 0 then
                safe_max = math.max(1, unassigned_count - remaining_cages)
            else
                safe_max = unassigned_count
            end
            local target_size = safe_max < 2 and 1 or math.random(2, math.min(max_size, safe_max))

            local frontier = unassignedNeighbors(seed.r, seed.c)
            while #cage.cells < target_size and #frontier > 0 do
                -- Only grow into a frontier cell whose digit isn't already in the cage.
                local valid_idxs = {}
                for fi, f in ipairs(frontier) do
                    if not used_digits[solution[f.r][f.c]] then valid_idxs[#valid_idxs + 1] = fi end
                end
                if #valid_idxs == 0 then break end
                local idx       = valid_idxs[math.random(#valid_idxs)]
                local candidate = frontier[idx]
                table.remove(frontier, idx)
                if not assigned[candidate.r][candidate.c] then
                    cage.cells[#cage.cells + 1] = candidate
                    cage.sum = cage.sum + solution[candidate.r][candidate.c]
                    used_digits[solution[candidate.r][candidate.c]] = true
                    assigned[candidate.r][candidate.c] = true
                    unassigned_count = unassigned_count - 1
                    for _, nb in ipairs(unassignedNeighbors(candidate.r, candidate.c)) do
                        local dup = false
                        for _, f in ipairs(frontier) do
                            if f.r == nb.r and f.c == nb.c then dup = true; break end
                        end
                        if not dup then frontier[#frontier + 1] = nb end
                    end
                end
            end
            cages[#cages + 1] = cage
        end
    end

    for r = 1, n do
        for c = 1, n do
            if not assigned[r][c] then
                local cage_id = #cages + 1
                cages[cage_id] = {
                    id    = cage_id,
                    cells = { { r = r, c = c } },
                    sum   = solution[r][c],
                }
                assigned[r][c] = true
            end
        end
    end

    return mergeStraySingletons(cages, solution, n, max_size)
end

-- ---------------------------------------------------------------------------
-- Cage-sum solver: counts solutions (up to `limit`) of the sudoku+cage-sum
-- instance, using MRV cell ordering and cage-sum feasibility pruning to keep
-- the search tractable. Returns (solutions_found, exhausted, nodes_visited);
-- exhausted = true means node_budget was hit before the search concluded, so
-- the solutions count is not a proof (fewer solutions may remain unexplored).
--
-- Everything is a bitmask here, and the cage-sum test is done once per cage
-- rather than once per cell and digit: which digits a cage can still take
-- depends only on the cage's own state (digits used, cells left, sum left),
-- so it is kept per cage and refreshed when one of its cells changes. A cell's
-- candidates are then that mask minus its row/column/box. The search visits
-- the same nodes in the same order as the per-cell version it replaced (same
-- MRV tie-break, digits tried in ascending order), so the node budget runs
-- out at the same place and a seed still gives the same cages -- it is only
-- some 30 times cheaper per node.
-- ---------------------------------------------------------------------------

local FULL_DIGIT_MASK = 0x3FE -- bits 1..9

-- MIN_SUM[m][k] / MAX_SUM[m][k]: the smallest / largest sum of k distinct
-- digits taken from the set m (bit v = digit v, as a 0..1023 index), or nil
-- when m has fewer than k digits. POPCOUNT[m]: number of digits in m.
-- Some 2000 small tables (~350 KB): built by the first countCageSolutions()
-- (about a millisecond) and dropped by release() when the game closes.
local MIN_SUM, MAX_SUM, POPCOUNT

local function buildSumTables()
    MIN_SUM, MAX_SUM, POPCOUNT = {}, {}, {}
    for m = 0, FULL_DIGIT_MASK do
        local digits = {}
        for v = 1, 9 do
            if band(m, lshift(1, v)) ~= 0 then digits[#digits + 1] = v end
        end
        local mins, maxs = { [0] = 0 }, { [0] = 0 }
        for k = 1, #digits do
            mins[k] = mins[k - 1] + digits[k]
            maxs[k] = maxs[k - 1] + digits[#digits - k + 1]
        end
        MIN_SUM[m], MAX_SUM[m], POPCOUNT[m] = mins, maxs, #digits
    end
end

-- Digits the next cell of a cage may take, given the digits already in the
-- cage (used), how many of its cells are still empty (empty, >= 1) and what
-- is left of its sum (target): v must fit, and the empty-1 cells left after
-- it must still be able to make up target - v from the other digits.
local function cageAllowedMask(used, empty, target)
    local allowed, after = 0, empty - 1
    for v = 1, 9 do
        local vbit = lshift(1, v)
        if band(used, vbit) == 0 then
            local rem_sum = target - v
            if rem_sum >= 0 then
                if after == 0 then
                    if rem_sum == 0 then allowed = bor(allowed, vbit) end
                else
                    local avail = band(bnot(bor(used, vbit)), FULL_DIGIT_MASK)
                    local mn = MIN_SUM[avail][after]
                    if mn and rem_sum >= mn and rem_sum <= MAX_SUM[avail][after] then
                        allowed = bor(allowed, vbit)
                    end
                end
            end
        end
    end
    return allowed
end

local function countCageSolutions(cell_cage, cages, n, box_rows, box_cols, limit, node_budget)
    if not POPCOUNT then buildSumTables() end
    local row_used, col_used, box_used = {}, {}, {}
    for i = 1, n do row_used[i] = 0; col_used[i] = 0 end
    local num_box_cols = n / box_cols
    for i = 1, (n / box_rows) * num_box_cols do box_used[i] = 0 end
    -- Per cage: digits used, cells still empty, sum still missing, and the
    -- resulting mask of digits its next cell may take.
    local cage_used, cage_empty, cage_target, cage_allowed = {}, {}, {}, {}
    for _, cage in ipairs(cages) do
        local id = cage.id
        cage_used[id], cage_empty[id], cage_target[id] = 0, #cage.cells, cage.sum
        cage_allowed[id] = cageAllowedMask(0, #cage.cells, cage.sum)
    end

    -- Cells in reading order (the MRV tie-break depends on it), as flat arrays.
    local cell_r, cell_c, cell_b, cell_k, filled = {}, {}, {}, {}, {}
    local num_empty = 0
    for r = 1, n do
        for c = 1, n do
            num_empty = num_empty + 1
            cell_r[num_empty] = r
            cell_c[num_empty] = c
            cell_b[num_empty] = math.floor((r - 1) / box_rows) * num_box_cols
                                + math.floor((c - 1) / box_cols) + 1
            cell_k[num_empty] = cell_cage[r][c]
            filled[num_empty] = false
        end
    end

    local solutions, nodes, exhausted = 0, 0, false

    local function search(depth)
        if solutions >= limit or exhausted then return end
        nodes = nodes + 1
        if nodes > node_budget then exhausted = true; return end
        if depth > num_empty then solutions = solutions + 1; return end
        local best_idx, best_mask, best_len = nil, 0, 1000
        for i = 1, num_empty do
            if not filled[i] then
                local r, c = cell_r[i], cell_c[i]
                local mask = band(cage_allowed[cell_k[i]],
                                  bnot(bor(bor(row_used[r], col_used[c]), box_used[cell_b[i]])))
                local len = POPCOUNT[mask]
                if len < best_len then
                    best_len  = len
                    best_mask = mask
                    best_idx  = i
                    if best_len <= 1 then break end
                end
            end
        end
        if best_idx == nil then solutions = solutions + 1; return end
        if best_len == 0 then return end
        local r, c, b, id = cell_r[best_idx], cell_c[best_idx], cell_b[best_idx], cell_k[best_idx]
        local used0, allowed0 = cage_used[id], cage_allowed[id]
        local empty0, target0 = cage_empty[id], cage_target[id]
        filled[best_idx] = true
        cage_empty[id] = empty0 - 1
        local mask = best_mask
        while mask ~= 0 do
            local vbit = band(mask, -mask) -- lowest digit first
            local v = 0
            while lshift(1, v) ~= vbit do v = v + 1 end
            row_used[r] = bor(row_used[r], vbit)
            col_used[c] = bor(col_used[c], vbit)
            box_used[b] = bor(box_used[b], vbit)
            local used = bor(used0, vbit)
            cage_used[id]   = used
            cage_target[id] = target0 - v
            cage_allowed[id] = empty0 > 1 and cageAllowedMask(used, empty0 - 1, target0 - v) or 0
            search(depth + 1)
            row_used[r] = band(row_used[r], bnot(vbit))
            col_used[c] = band(col_used[c], bnot(vbit))
            box_used[b] = band(box_used[b], bnot(vbit))
            if solutions >= limit or exhausted then break end
            mask = band(mask, mask - 1)
        end
        filled[best_idx] = false
        cage_used[id], cage_allowed[id] = used0, allowed0
        cage_empty[id], cage_target[id] = empty0, target0
    end
    search(1)
    return solutions, exhausted, nodes
end

-- ---------------------------------------------------------------------------
-- Human-solvability check
-- ---------------------------------------------------------------------------
-- Verifies a cage layout (plus its deliberate given digits) can be fully
-- deduced with beginner/intermediate killer-sudoku techniques -- naked/hidden
-- singles, cage-sum combo elimination, and the "45 rule" (every row/col/box
-- sums to 45, so a single cell that's the only overhang of an otherwise fully
-- contained cage can be read off directly) -- with NO backtracking/guessing.
-- Used to gate Easy/Medium generation: countCageSolutions above only proves a
-- unique solution *exists*, not that a human can reach it without guessing.

-- Which digits each empty cell of a cage can take in at least one complete
-- filling of the cage: distinct digits, none of them already in the cage
-- (used), each within its cell's candidate mask, adding up to target. ORs
-- every such filling into possible[1..k]; leaves it all 0 when there is none.
--
-- This replaced listing every digit combination that makes the sum and then
-- every permutation of each against the candidates: the same fillings, found
-- by walking the cells instead, so it skips at once the digits a cell cannot
-- take, and creates no closures (LuaJIT cannot compile those).
local DIGIT_OF_BIT = {}
for v = 1, 9 do DIGIT_OF_BIT[lshift(1, v)] = v end

local function cageCellOptions(masks, k, target, used, possible, chosen, i)
    if i > k then
        if target == 0 then
            for j = 1, k do possible[j] = bor(possible[j], chosen[j]) end
        end
        return
    end
    -- The r cells after this one need r distinct digits: at least
    -- 1+...+r and at most 9+...+(10-r).
    local r = k - i
    local lo, hi = r * (r + 1) / 2, r * (19 - r) / 2
    local free = band(masks[i], bnot(used))
    while free ~= 0 do
        local m = band(free, -free)
        local d = DIGIT_OF_BIT[m]
        local rest = target - d
        if rest >= lo and rest <= hi then
            chosen[i] = m
            cageCellOptions(masks, k, target - d, bor(used, m), possible, chosen, i + 1)
        end
        free = band(free, free - 1)
    end
end

local function isHumanSolvable(cages, cell_cage, seed_grid, n, box_rows, box_cols)
    local num_box_cols = n / box_cols
    local function boxIndex(r, c)
        return math.floor((r - 1) / box_rows) * num_box_cols + math.floor((c - 1) / box_cols) + 1
    end

    local grid, filled = {}, 0
    for r = 1, n do
        grid[r] = {}
        for c = 1, n do
            grid[r][c] = seed_grid[r][c]
            if grid[r][c] ~= 0 then filled = filled + 1 end
        end
    end

    -- Precompute the 27 units (9 rows, 9 cols, 9 boxes) once.
    local units = {}
    for r = 1, n do
        local u = {}
        for c = 1, n do u[#u + 1] = { r = r, c = c } end
        units[#units + 1] = u
    end
    for c = 1, n do
        local u = {}
        for r = 1, n do u[#u + 1] = { r = r, c = c } end
        units[#units + 1] = u
    end
    for br = 0, (n / box_rows) - 1 do
        for bc = 0, num_box_cols - 1 do
            local u = {}
            for r = br * box_rows + 1, br * box_rows + box_rows do
                for c = bc * box_cols + 1, bc * box_cols + box_cols do
                    u[#u + 1] = { r = r, c = c }
                end
            end
            units[#units + 1] = u
        end
    end

    local passes, progress = 0, true
    while progress and filled < n * n do
        progress = false
        passes = passes + 1
        if passes > 60 then break end

        local row_mask, col_mask, box_mask = {}, {}, {}
        for i = 1, n do row_mask[i] = 0; col_mask[i] = 0 end
        for i = 1, (n / box_rows) * num_box_cols do box_mask[i] = 0 end
        for r = 1, n do
            for c = 1, n do
                local v = grid[r][c]
                if v ~= 0 then
                    local vbit = lshift(1, v)
                    row_mask[r] = bor(row_mask[r], vbit)
                    col_mask[c] = bor(col_mask[c], vbit)
                    local b = boxIndex(r, c)
                    box_mask[b] = bor(box_mask[b], vbit)
                end
            end
        end

        local cand = {}
        for r = 1, n do
            cand[r] = {}
            for c = 1, n do
                if grid[r][c] == 0 then
                    local used = bor(bor(row_mask[r], col_mask[c]), box_mask[boxIndex(r, c)])
                    cand[r][c] = band(bnot(used), FULL_DIGIT_MASK)
                end
            end
        end

        -- Cage-sum combo elimination: narrow each empty cage cell's candidate
        -- mask to digits reachable by *some* combo+permutation consistent
        -- with every cell's current candidate mask.
        for _, cage in ipairs(cages) do
            local empties, filled_sum, filled_mask = {}, 0, 0
            for _, cell in ipairs(cage.cells) do
                local v = grid[cell.r][cell.c]
                if v ~= 0 then
                    filled_sum = filled_sum + v
                    filled_mask = bor(filled_mask, lshift(1, v))
                else
                    empties[#empties + 1] = cell
                end
            end
            local k = #empties
            if k > 0 then
                local target = cage.sum - filled_sum
                local masks, possible, chosen = {}, {}, {}
                for i, cell in ipairs(empties) do
                    masks[i]    = cand[cell.r][cell.c]
                    possible[i] = 0
                end
                cageCellOptions(masks, k, target, filled_mask, possible, chosen, 1)
                -- A cage with no filling left empties its cells' masks, which
                -- the naked-singles pass below reports as a contradiction.
                for i, cell in ipairs(empties) do
                    cand[cell.r][cell.c] = band(cand[cell.r][cell.c], possible[i])
                end
            end
        end

        -- 45-rule: if a unit (row/col/box) is covered by cages fully inside it
        -- plus exactly one cage crossing its boundary with a single-cell
        -- overhang, that overhang cell's value is 45 minus the fully-inside
        -- cages' sums (or, symmetrically, cage.sum minus that for a single
        -- cell sticking *out* of the unit).
        for _, unit in ipairs(units) do
            local inside_count, full_sum, crossing, ambiguous = {}, 0, nil, false
            for _, cell in ipairs(unit) do
                local cid = cell_cage[cell.r][cell.c]
                inside_count[cid] = (inside_count[cid] or 0) + 1
            end
            for cid, cnt in pairs(inside_count) do
                local cage = cages[cid]
                if cnt == #cage.cells then
                    full_sum = full_sum + cage.sum
                elseif crossing == nil then
                    crossing = { cage = cage, inside = cnt }
                else
                    ambiguous = true
                end
            end
            if not ambiguous and crossing then
                local cage, inside = crossing.cage, crossing.inside
                if inside == 1 then
                    local v = 45 - full_sum
                    if v >= 1 and v <= 9 then
                        for _, cell in ipairs(unit) do
                            if cell_cage[cell.r][cell.c] == cage.id and grid[cell.r][cell.c] == 0
                                and band(cand[cell.r][cell.c], lshift(1, v)) ~= 0 then
                                cand[cell.r][cell.c] = lshift(1, v)
                            end
                        end
                    end
                elseif #cage.cells - inside == 1 then
                    local v = cage.sum - (45 - full_sum)
                    if v >= 1 and v <= 9 then
                        for _, cell in ipairs(cage.cells) do
                            local in_unit = false
                            for _, u in ipairs(unit) do
                                if u.r == cell.r and u.c == cell.c then in_unit = true; break end
                            end
                            if not in_unit and grid[cell.r][cell.c] == 0
                                and band(cand[cell.r][cell.c], lshift(1, v)) ~= 0 then
                                cand[cell.r][cell.c] = lshift(1, v)
                            end
                        end
                    end
                end
            end
        end

        -- naked singles
        for r = 1, n do
            for c = 1, n do
                if grid[r][c] == 0 then
                    local mask = cand[r][c]
                    if mask == 0 then return false end -- contradiction
                    if band(mask, mask - 1) == 0 then
                        for v = 1, 9 do
                            if band(mask, lshift(1, v)) ~= 0 then
                                grid[r][c] = v
                                filled = filled + 1
                                progress = true
                                break
                            end
                        end
                    end
                end
            end
        end

        -- hidden singles per unit
        if not progress then
            for _, unit in ipairs(units) do
                for v = 1, 9 do
                    local vbit = lshift(1, v)
                    local spot, cnt = nil, 0
                    for _, cell in ipairs(unit) do
                        if grid[cell.r][cell.c] == 0 and band(cand[cell.r][cell.c], vbit) ~= 0 then
                            cnt = cnt + 1
                            spot = cell
                        end
                    end
                    if cnt == 1 then
                        grid[spot.r][spot.c] = v
                        filled = filled + 1
                        progress = true
                    end
                end
            end
        end
    end

    return filled == n * n
end

-- Generate a cage layout for `solution`, retrying up to a bounded number of
-- attempts to find one with a provably unique solution (and, for Easy/Medium,
-- one that's also fully solvable by isHumanSolvable). Cage-sum constraints
-- alone are weak, so most random layouts are ambiguous; we prefer, in order:
-- (3) proven-unique AND human-solvable (only tier that returns immediately),
-- (2) proven-unique, (1) unproven-but-not-disproven (solver ran out of budget
-- before finding a 2nd solution), (0) whatever the last attempt produced.
local function generateVerifiedCages(solution, difficulty, n, box_rows, box_cols, on_progress)
    local require_human_solvable = HUMAN_SOLVABLE_DIFFICULTIES[difficulty] or false
    local max_attempts = require_human_solvable and HUMAN_SOLVABLE_MAX_ATTEMPTS or CAGE_GEN_MAX_ATTEMPTS

    local fallback_cages, fallback_cell_cage
    local fallback_tier = -1
    for attempt = 1, max_attempts do
        local cages, cell_cage = generateCages(solution, difficulty, n)
        local solutions, exhausted = countCageSolutions(
            cell_cage, cages, n, box_rows, box_cols, 2, CAGE_SOLVER_NODE_BUDGET)
        local proven_unique = not exhausted and solutions == 1

        if proven_unique then
            local solved = true
            if require_human_solvable then
                local seed_grid = emptyGrid(n)
                for _, cage in ipairs(cages) do
                    if #cage.cells == 1 then
                        local cell = cage.cells[1]
                        seed_grid[cell.r][cell.c] = solution[cell.r][cell.c]
                    end
                end
                solved = isHumanSolvable(cages, cell_cage, seed_grid, n, box_rows, box_cols)
            end
            if solved then
                if on_progress then on_progress(max_attempts, max_attempts) end
                return cages, cell_cage
            end
            if fallback_tier < 2 then
                fallback_cages, fallback_cell_cage = cages, cell_cage
                fallback_tier = 2
            end
        elseif exhausted then
            if fallback_tier < 1 then
                fallback_cages, fallback_cell_cage = cages, cell_cage
                fallback_tier = 1
            end
        elseif fallback_tier < 0 then
            fallback_cages, fallback_cell_cage = cages, cell_cage
            fallback_tier = 0
        end
        if on_progress then on_progress(attempt, max_attempts) end
    end
    return fallback_cages, fallback_cell_cage
end

-- ---------------------------------------------------------------------------
-- KillerSudokuBoard
-- ---------------------------------------------------------------------------

local KillerSudokuBoard = setmetatable({}, { __index = BaseBoard })
KillerSudokuBoard.__index = KillerSudokuBoard

function KillerSudokuBoard:new()
    local n = 9
    local board = {
        n               = n,
        box_rows        = 3,
        box_cols        = 3,
        grid_id         = "9x9",
        solution        = emptyGrid(n),
        user            = emptyGrid(n),
        conflicts       = emptyGrid(n),
        notes           = emptyNotes(n),
        wrong_marks     = emptyMarkerGrid(n),
        selected        = { row = 1, col = 1 },
        difficulty      = DEFAULT_DIFFICULTY,
        reveal_solution = false,
        undo_stack      = {},
        cages           = {},
        cell_cage       = emptyGrid(n),
    }
    setmetatable(board, self)
    board:recalcConflicts()
    return board
end

function KillerSudokuBoard:serialize()
    local n = self.n
    return {
        n               = n,
        box_rows        = self.box_rows,
        box_cols        = self.box_cols,
        grid_id         = self.grid_id,
        solution        = copyGrid(self.solution, n),
        user            = copyGrid(self.user, n),
        notes           = copyNotes(self.notes, n),
        wrong_marks     = copyGrid(self.wrong_marks, n),
        selected        = { row = self.selected.row, col = self.selected.col },
        difficulty      = self.difficulty,
        reveal_solution = self.reveal_solution,
        cages           = self.cages,
        cell_cage       = copyGrid(self.cell_cage, n),
    }
end

-- 1.9.0 could split a given out of the middle of a cage, leaving two pieces
-- under one sum. A game saved then is repaired on load: each piece becomes
-- its own cage, its sum read from the solution, so the grid shows cages that
-- are each in one piece and add up. Returns the cages and a fresh cell map.
local function splitDisconnectedCages(cages, solution, n)
    local out = {}
    for _, cage in ipairs(cages) do
        local inside = {}
        for _, cell in ipairs(cage.cells) do inside[cell.r * 16 + cell.c] = cell end
        local seen = {}
        for _, start in ipairs(cage.cells) do
            local key = start.r * 16 + start.c
            if not seen[key] then
                seen[key] = true
                local piece, stack, sum = { start }, { start }, solution[start.r][start.c]
                while #stack > 0 do
                    local cell = table.remove(stack)
                    for _, d in ipairs({ { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 } }) do
                        local k = (cell.r + d[1]) * 16 + cell.c + d[2]
                        local nb = inside[k]
                        if nb and not seen[k] then
                            seen[k] = true
                            piece[#piece + 1] = nb
                            stack[#stack + 1] = nb
                            sum = sum + solution[nb.r][nb.c]
                        end
                    end
                end
                local id = #out + 1
                out[id] = { id = id, cells = piece,
                            sum = (#piece == #cage.cells) and cage.sum or sum,
                            is_given = cage.is_given }
            end
        end
    end
    local map = {}
    for r = 1, n do
        map[r] = {}
        for c = 1, n do map[r][c] = 0 end
    end
    for _, cage in ipairs(out) do
        for _, cell in ipairs(cage.cells) do map[cell.r][cell.c] = cage.id end
    end
    return out, map
end

function KillerSudokuBoard:load(state)
    if not state or not state.solution or not state.user or not state.cages then
        return false
    end
    local n         = state.n or 9
    self.n          = n
    self.box_rows   = state.box_rows or 3
    self.box_cols   = state.box_cols or 3
    self.grid_id    = state.grid_id  or "9x9"
    self.solution   = copyGrid(state.solution, n)
    self.user       = copyGrid(state.user, n)
    self.notes      = copyNotes(state.notes, n)
    self.wrong_marks = state.wrong_marks and copyGrid(state.wrong_marks, n) or emptyMarkerGrid(n)
    self.conflicts  = emptyGrid(n)
    self.difficulty = state.difficulty or DEFAULT_DIFFICULTY
    self.undo_stack = {}
    self.reveal_solution = state.reveal_solution or false
    self.cages, self.cell_cage = splitDisconnectedCages(state.cages or {}, self.solution, n)
    -- A 1-cell cage is a given: a piece split off above may be one.
    for _, cage in ipairs(self.cages) do
        local cell = cage.cells[1]
        if #cage.cells == 1 and self.user[cell.r][cell.c] == 0 then
            self.user[cell.r][cell.c] = self.solution[cell.r][cell.c]
        end
    end
    if state.selected then
        self.selected = {
            row = math.max(1, math.min(n, state.selected.row or 1)),
            col = math.max(1, math.min(n, state.selected.col or 1)),
        }
    else
        self.selected = { row = 1, col = 1 }
    end
    self:recalcConflicts()
    return true
end

-- ---------------------------------------------------------------------------
-- Pure-logic guarantee
--
-- Cage geometry alone does not decide whether a killer grid can be solved by
-- deduction: this generator grows cages at random and then checks the puzzle
-- has one solution, which is weaker -- a unique solution can still need
-- guessing. Measured before this, easy and medium grids were deducible only
-- once the cage-aware solver existed, and hard and expert were not deducible
-- at all, because they are dealt with barely a given digit.
--
-- So: hand the starting position to the solver, and while it cannot finish,
-- split one more cell out into its own 1-cell cage (which the board shows as
-- a given). Each split strictly reduces the unknowns, so this terminates; in
-- the worst case every cell becomes a given, which is trivially deducible.
--
-- The cell chosen is the one the solver got furthest with -- the first it
-- could not resolve in reading order -- rather than a random one, so the
-- givens land where the deduction actually stalls.
--
-- Only Easy and Medium go through this. Hard and Expert are deliberately
-- genre-pure: a real Killer Sudoku carries no given digits at all, the cages
-- say everything, and test_board_spec.lua pins that. Adding the givens they
-- would need to become deducible would turn them into a different puzzle. They
-- keep their cage geometry, and the Hint button simply stops when the cages
-- stop deciding -- see the note in README.md.
local function startingGrid(cages, solution, n)
    local grid = emptyGrid(n)
    for _, cage in ipairs(cages) do
        if #cage.cells == 1 then
            local cell = cage.cells[1]
            grid[cell.r][cell.c] = solution[cell.r][cell.c]
        end
    end
    return grid
end

local function rebuildCellCage(cages, n)
    local map = {}
    for r = 1, n do
        map[r] = {}
        for c = 1, n do map[r][c] = 0 end
    end
    for _, cage in ipairs(cages) do
        for _, cell in ipairs(cage.cells) do map[cell.r][cell.c] = cage.id end
    end
    return map
end

-- Being deducible is not the same as being easy. Measured before this cap
-- (30 grids per level), Easy and Medium were alike: every grid needed about
-- 12 steps beyond singles -- working out which digits fit a cage given its
-- sum and the digits around it, or a 45-rule innie/outie -- and Easy even
-- dealt fewer givens than Medium. So each level also caps how many such
-- steps the solver may take, with nothing above locked candidates / pairs;
-- past the cap, the grid counts as stuck and gets one more given, exactly as
-- when it cannot be deduced at all.
local DEDUCTION_TIER = logic_solver.TIER.LOCKED
local HARD_STEP_BUDGET = {
    easy   = 3,
    medium = 8,
}
local SIMPLE_STEPS = { naked_single = true, hidden_single = true, cage_last_cell = true }

-- Solve from `grid` within the level's tier and budget. Returns whether it
-- finished, the grid as far as the solver got, and -- when it ran out of
-- budget -- the step it could not afford, whose cells are where a given
-- would save the reasoning.
local function deduceWithinBudget(grid, cages, n, box_rows, box_cols, budget)
    local res = logic_solver.solve(grid, n, box_rows, box_cols, nil,
        { cages = cages, max_tier = DEDUCTION_TIER, trace = true })
    local reached = {}
    for r = 1, n do
        reached[r] = {}
        for c = 1, n do reached[r][c] = grid[r][c] end
    end
    local hard = 0
    for _, step in ipairs(res.steps) do
        if not SIMPLE_STEPS[step.technique] then
            hard = hard + 1
            if hard > budget then return false, reached, step end
        end
        if step.placements then
            for _, p in ipairs(step.placements) do reached[p.r][p.c] = p.digit end
        end
    end
    return res.solved, reached
end

local function ensureDeducible(solution, cages, cell_cage, n, box_rows, box_cols, budget, on_progress)
    -- Each pass either finishes or adds one given, so the work is bounded by
    -- the number of cells; report against that so the progress bar keeps
    -- moving through what is the slowest part of generating a killer grid.
    local guard, added = n * n, 0
    while guard > 0 do
        guard = guard - 1
        if on_progress then on_progress(added, added + 4) end
        local grid = startingGrid(cages, solution, n)
        local solved, reached, unaffordable = deduceWithinBudget(grid, cages, n, box_rows, box_cols, budget)
        if solved then break end

        -- A cell of the step over budget; otherwise (the solver stalled) the
        -- first unresolved cell in reading order: where the deduction stopped.
        -- Reading order alone piled the givens into the top rows.
        -- Only a cell whose removal leaves its cage in one piece: 1.9.0 split
        -- the middle of a cage, leaving two parts under one sum.
        local function splittable(r, c)
            local parent = cages[cell_cage[r][c]]
            if not parent or #parent.cells <= 1 then return false end
            local rest, start = {}, nil
            for _, cell in ipairs(parent.cells) do
                if cell.r ~= r or cell.c ~= c then
                    rest[cell.r * 16 + cell.c] = true
                    start = start or cell
                end
            end
            local seen, stack, count = { [start.r * 16 + start.c] = true }, { start }, 1
            while #stack > 0 do
                local cell = table.remove(stack)
                for _, d in ipairs({ { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 } }) do
                    local nr, nc = cell.r + d[1], cell.c + d[2]
                    local k = nr * 16 + nc
                    if rest[k] and not seen[k] then
                        seen[k] = true
                        count = count + 1
                        stack[#stack + 1] = { r = nr, c = nc }
                    end
                end
            end
            return count == #parent.cells - 1
        end
        local pick
        for _, cell in ipairs(unaffordable and unaffordable.focus or {}) do
            if reached[cell.r][cell.c] == 0 and splittable(cell.r, cell.c) then
                pick = { r = cell.r, c = cell.c } break
            end
        end
        for r = 1, n do
            if pick then break end
            for c = 1, n do
                if reached[r][c] == 0 and grid[r][c] == 0 and splittable(r, c) then
                    pick = { r = r, c = c } break
                end
            end
            if pick then break end
        end
        if not pick then break end

        -- Split it out of its cage into a 1-cell cage, moving its share of the
        -- sum with it so both cages stay consistent.
        local parent = cages[cell_cage[pick.r][pick.c]]
        if not parent or #parent.cells <= 1 then break end
        local value = solution[pick.r][pick.c]
        for i, cell in ipairs(parent.cells) do
            if cell.r == pick.r and cell.c == pick.c then table.remove(parent.cells, i) break end
        end
        parent.sum = parent.sum - value
        cages[#cages + 1] = {
            id       = #cages + 1,
            cells    = { { r = pick.r, c = pick.c } },
            sum      = value,
            is_given = true,
        }
        cell_cage = rebuildCellCage(cages, n)
        added = added + 1
    end
    if on_progress then on_progress(1, 1) end
    return cages, cell_cage
end

function KillerSudokuBoard:generate(difficulty, randInt, on_progress)
    self.difficulty = difficulty or self.difficulty or DEFAULT_DIFFICULTY
    local n, box_rows, box_cols = self.n, self.box_rows, self.box_cols
    local solution = generateSolvedBoard(n, box_rows, box_cols, nil, randInt)
    local cages, cell_cage = generateVerifiedCages(solution, self.difficulty, n, box_rows, box_cols, on_progress)
    local budget = HARD_STEP_BUDGET[self.difficulty]
    if budget then
        cages, cell_cage = ensureDeducible(solution, cages, cell_cage, n, box_rows, box_cols, budget, on_progress)
    end
    self.solution        = solution
    self.cages           = cages
    self.cell_cage       = cell_cage
    self.user            = emptyGrid(n)
    for _, cage in ipairs(cages) do
        if #cage.cells == 1 then
            local cell = cage.cells[1]
            self.user[cell.r][cell.c] = solution[cell.r][cell.c]
        end
    end
    self.notes           = emptyNotes(n)
    self.wrong_marks     = emptyMarkerGrid(n)
    self.selected        = { row = 1, col = 1 }
    self.reveal_solution = false
    self.undo_stack      = {}
    self:recalcConflicts()
end

-- ---------------------------------------------------------------------------
-- Killer-specific: cage helpers
-- ---------------------------------------------------------------------------

function KillerSudokuBoard:getCage(row, col)
    local cage_id = self.cell_cage[row] and self.cell_cage[row][col] or 0
    if cage_id == 0 then return nil end
    return self.cages[cage_id]
end

function KillerSudokuBoard:getCageLabelCell(cage)
    local best     = nil
    local best_idx = math.huge
    for _, cell in ipairs(cage.cells) do
        local idx = (cell.r - 1) * self.n + (cell.c - 1)
        if idx < best_idx then
            best_idx = idx
            best     = cell
        end
    end
    return best
end

function KillerSudokuBoard:isCageBoundary(r1, c1, r2, c2)
    local id1 = self.cell_cage[r1] and self.cell_cage[r1][c1] or 0
    local id2 = self.cell_cage[r2] and self.cell_cage[r2][c2] or 0
    if id1 == id2 then return false end
    if r1 ~= r2 then
        return (r1 % self.box_rows) ~= 0
    else
        return (c1 % self.box_cols) ~= 0
    end
end

-- ---------------------------------------------------------------------------
-- Overrides
-- ---------------------------------------------------------------------------

-- Hints must see the cage sums: without them the solver knows only the grid,
-- and a killer grid barely has one to go on.
function KillerSudokuBoard:getCages()
    return self.cages
end

function KillerSudokuBoard:isGiven(row, col)
    local cage_id = self.cell_cage[row] and self.cell_cage[row][col] or 0
    if cage_id == 0 then return false end
    local cage = self.cages[cage_id]
    return cage ~= nil and #cage.cells == 1
end

function KillerSudokuBoard:getWorkingValue(row, col)
    return self.user[row][col]
end

function KillerSudokuBoard:getDisplayValue(row, col)
    if self.reveal_solution then
        return self.solution[row][col], false
    end
    local value = self.user[row][col]
    if value == 0 then return nil end
    return value, false
end

function KillerSudokuBoard:isConflict(row, col)
    return self.conflicts[row][col]
end

-- Extends base row/col/box detection with cage duplicate detection
function KillerSudokuBoard:recalcConflicts()
    BaseBoard.recalcConflicts(self)
    for _, cage in ipairs(self.cages) do
        local seen = {}
        for _, cell in ipairs(cage.cells) do
            local v = self:getWorkingValue(cell.r, cell.c)
            if v ~= 0 then
                if seen[v] then
                    self.conflicts[cell.r][cell.c] = true
                    if type(seen[v]) == "table" then
                        self.conflicts[seen[v].r][seen[v].c] = true
                        seen[v] = true
                    end
                else
                    seen[v] = cell
                end
            end
        end
    end
end

return {
    KillerSudokuBoard  = KillerSudokuBoard,
    DEFAULT_DIFFICULTY = DEFAULT_DIFFICULTY,
    CAGE_COUNT_RANGES  = CAGE_COUNT_RANGES,
    -- Drops the generator's sum tables (rebuilt on the next generation).
    release            = function() MIN_SUM, MAX_SUM, POPCOUNT = nil, nil, nil end,
    sumTablesBuilt     = function() return POPCOUNT ~= nil end,
    -- For test_board_spec.lua only.
    _countCageSolutions = countCageSolutions,
    _generateCages      = generateCages,
    _isHumanSolvable    = isHumanSolvable,
}
