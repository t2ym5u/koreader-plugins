local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"
package.path = _dir .. "?.lua;" .. _dir .. "common/?.lua;" .. package.path

local function lrequire(name)
    local key = _dir .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. name .. ".lua"))()
    end
    return package.loaded[key]
end

local DataStorage     = require("datastorage")
local LuaSettings     = require("luasettings")
local UIManager       = require("ui/uimanager")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local _               = require("i18n")

require("i18n").extend(lrequire("i18n_fr"))

local board_module       = lrequire("board")
local KillerSudokuBoard  = board_module.KillerSudokuBoard
local DEFAULT_DIFFICULTY = board_module.DEFAULT_DIFFICULTY
local generateWithProgress = lrequire("common/base_screen").generateWithProgress

local KillerSudokuScreen = lrequire("screen")

local function file_exists(path)
    local f = io.open(path, "r")
    if f then f:close(); return true end
    return false
end

-- `name` must match the directory basename: since KOReader 2026.03 (PR
-- #15096) PluginLoader overwrites it with the directory name regardless of
-- what is declared here.
local KillerSudoku = WidgetContainer:extend{
    name        = "sudokukiller",
    is_doc_only = false,
}

function KillerSudoku:ensureSettings()
    if not self.settings_file then
        local dir = DataStorage:getSettingsDir()
        self.settings_file = dir .. "/sudokukiller.lua"
        -- The settings file used to be named after the old "killer_sudoku"
        -- plugin id. Carry a player's saved grid over rather than silently
        -- starting them on an empty board.
        local legacy = dir .. "/killer_sudoku.lua"
        if not file_exists(self.settings_file) and file_exists(legacy) then
            os.rename(legacy, self.settings_file)
            os.remove(legacy .. ".old")
        end
    end
    if not self.settings then
        self.settings = LuaSettings:open(self.settings_file)
    end
end

function KillerSudoku:init()
    self:ensureSettings()
    self.ui.menu:registerToMainMenu(self)
end

function KillerSudoku:addToMainMenu(menu_items)
    menu_items.sudokukiller = {
        text         = _("Killer Sudoku"),
        sorting_hint = "tools",
        callback     = function() self:showGame() end,
    }
end

function KillerSudoku:getBoard()
    if not self.board then
        self:ensureSettings()
        self.board = KillerSudokuBoard:new()
        local state = self.settings:readSetting("state")
        if not self.board:load(state) then
            generateWithProgress(self.board, DEFAULT_DIFFICULTY)
        end
    end
    return self.board
end

function KillerSudoku:saveState()
    if not self.board then return end
    self:ensureSettings()
    self.settings:saveSetting("state", self.board:serialize())
    self.settings:flush()
end

function KillerSudoku:showGame()
    if self.screen then return end
    self.screen = KillerSudokuScreen:new{
        board  = self:getBoard(),
        plugin = self,
    }
    UIManager:show(self.screen)
end

function KillerSudoku:onScreenClosed()
    self.screen = nil
end

return KillerSudoku
