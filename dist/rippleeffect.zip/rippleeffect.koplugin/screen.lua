local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"
local function lrequire(name)
    local key = _dir .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. name .. ".lua"))()
    end
    return package.loaded[key]
end

local Button          = require("ui/widget/button")
local ButtonTable     = require("ui/widget/buttontable")
local Device          = require("device")
local FrameContainer  = require("ui/widget/container/framecontainer")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local Size            = require("ui/size")
local UIManager       = require("ui/uimanager")
local VerticalGroup   = require("ui/widget/verticalgroup")
local VerticalSpan    = require("ui/widget/verticalspan")
local _               = require("i18n")
local T               = require("ffi/util").template

local ScreenBase               = require("screen_base")
local MenuHelper               = require("menu_helper")
local RippleEffectBoard        = lrequire("board")
local RippleEffectBoardWidget  = lrequire("board_widget")

local DeviceScreen = Device.screen

local GAME_RULES_EN = _([[
Ripple Effect — Rules

Fill every cell so that each outlined region contains the numbers 1 to N (where N is the region size) exactly once.

Distance constraint:
• If the same number appears twice in the same row or column, those two cells must be at least that number of cells apart.
  Example: two cells both containing 3 must have at least 3 cells (not counting themselves) between them.

Tap a cell to select it, then tap a digit to fill it in.
]])

local GAME_RULES_FR = [[
Effet de Vague — Règles

Remplissez chaque case de sorte que chaque région délimitée de taille N contienne les nombres de 1 à N exactement une fois.

Contrainte de distance :
• Si le même nombre apparaît deux fois dans la même ligne ou colonne, ces deux cases doivent être séparées d'au moins ce nombre de cases.
  Exemple : deux cases contenant toutes les deux le chiffre 3 doivent avoir au moins 3 cases entre elles dans la même ligne ou colonne.

Appuyez sur une case pour la sélectionner, puis sur un chiffre pour le placer.
]]

local RippleEffectScreen = ScreenBase:extend{}

function RippleEffectScreen:init()
    local state = self.plugin:loadState()
    local n     = self.plugin:getSetting("grid_n", RippleEffectBoard.DEFAULT_N)
    self.board  = RippleEffectBoard:new{ n = n }
    if not self.board:load(state) then
        self.board:generate(self.plugin:getSetting("difficulty", "easy"))
    end
    self.selected = nil
    ScreenBase.init(self)
end

function RippleEffectScreen:serializeState()
    return self.board:serialize()
end

function RippleEffectScreen:buildLayout()
    local sw           = DeviceScreen:getWidth()
    local is_landscape = self:isLandscape()

    self.board_widget = RippleEffectBoardWidget:new{
        board           = self.board,
        onCellTap_cb    = function(r, c) self:onCellTap(r, c) end,
        onCellHold_cb   = function(r, c) self:onCellHold(r, c) end,
    }

    local board_frame = FrameContainer:new{
        padding = Size.padding.large,
        margin  = Size.margin.default,
        self.board_widget,
    }

    local board_frame_size  = self.board_widget.size + (Size.padding.large + Size.margin.default) * 2
    local right_panel_width = sw - board_frame_size - Size.span.horizontal_default
    local button_width = is_landscape
        and math.max(right_panel_width - Size.span.horizontal_default, 100)
        or  math.floor(sw * 0.9)

    self.status_text:setMaxWidth(is_landscape and button_width or board_frame_size)

    local title_bar = self:buildTitleBar(_("Ripple Effect"), function()
        return {
            { text = _("New game"),            callback = function() self:onNewGame() end },
            { text = self:getSizeButtonText(), callback = function() self:openSizeMenu() end },
            { text = self:getDiffButtonText(), callback = function() self:openDifficultyMenu() end },
            self:makeRulesButtonConfig(GAME_RULES_EN, GAME_RULES_FR),
        }
    end)

    -- Digit buttons 1-MAX_ROOM, drawn as real bordered buttons
    local max_room = RippleEffectBoard.MAX_ROOM
    local digit_btn_width = math.floor(button_width / max_room)
    local digit_buttons = HorizontalGroup:new{}
    for d = 1, max_room do
        local dv = d
        local digit_btn = Button:new{
            text       = tostring(dv),
            width      = digit_btn_width,
            margin     = Size.margin.small,
            bordersize = Size.border.button,
            radius     = Size.radius.button,
            padding    = Size.padding.buttontable,
            callback   = function() self:onDigitKey(dv) end,
        }
        table.insert(digit_buttons, digit_btn)
    end

    local bottom_buttons = ButtonTable:new{
        shrink_unneeded_width = true,
        width   = button_width,
        buttons = {{
            { text = _("Undo"),   callback = function() self:onUndo() end },
            { text = _("Erase"),  callback = function() self:onErase() end },
            { text = _("Check"),  callback = function() self:onCheck() end },
            { text = _("Hint"), callback = function() self:onHint() end },
            { text = _("Reveal"), callback = function() self:onReveal() end },
        }},
    }

    local footer = VerticalGroup:new{
        align = "center",
        digit_buttons,
        VerticalSpan:new{ width = Size.span.vertical_large },
        bottom_buttons,
    }

    if is_landscape then
        local right_panel = VerticalGroup:new{
            align = "center",
            self.status_text,
            VerticalSpan:new{ width = Size.span.vertical_large },
            footer,
        }
        local content = HorizontalGroup:new{
            align  = "center",
            board_frame,
            HorizontalSpan:new{ width = Size.span.horizontal_default },
            right_panel,
        }
        self:buildLandscapeLayout(title_bar, content)
    else
        local content = VerticalGroup:new{
            align = "center",
            board_frame,
            VerticalSpan:new{ width = Size.span.vertical_large },
            self.status_text,
        }
        self:buildPortraitLayout(title_bar, content, footer)
    end
    self:updateStatus()
end

function RippleEffectScreen:onCellTap(r, c)
    self.selected = { r, c }
    self.board_widget.selected = self.selected
    self.board_widget:refresh()
    self:updateStatus()
end

function RippleEffectScreen:onCellHold(r, c)
    self:onCellTap(r, c)
    self:onErase()
end

function RippleEffectScreen:onDigitKey(d)
    if not self.selected then
        self:updateStatus(_("Tap a cell first."))
        return
    end
    local r, c = self.selected[1], self.selected[2]
    local ok = self.board:setCell(r, c, d)
    if ok then
        self.plugin:saveState(self.board:serialize())
        if self.board.won then
            self:updateStatus(_("Congratulations! Puzzle solved!"))
        else
            self:updateStatus()
        end
    end
    self.board_widget:refresh()
end

function RippleEffectScreen:onErase()
    if not self.selected then return end
    local r, c = self.selected[1], self.selected[2]
    self.board:eraseCell(r, c)
    self.plugin:saveState(self.board:serialize())
    self.board_widget:refresh()
    self:updateStatus()
end

function RippleEffectScreen:onUndo()
    if self.board:undoMove() then
        self.board_widget:refresh()
        self:updateStatus()
        self.plugin:saveState(self.board:serialize())
    end
end

function RippleEffectScreen:onCheck()
    self.board:check()
    self.board_widget:refresh()
    local empty = self.board:countEmpty()
    if self.board.won then
        self:updateStatus(_("Congratulations! Puzzle solved!"))
    elseif empty > 0 then
        self:updateStatus(T(_("Check done. Empty: %1"), empty))
    else
        self:updateStatus(_("Some cells have errors."))
    end
end

function RippleEffectScreen:onReveal()
    self.board:reveal()
    self.board_widget:refresh()
    self:updateStatus(_("Solution revealed."))
    self.plugin:saveState(self.board:serialize())
end

function RippleEffectScreen:onNewGame()
    local diff = self.plugin:getSetting("difficulty", "easy")
    local n    = self.plugin:getSetting("grid_n", RippleEffectBoard.DEFAULT_N)
    self.board = RippleEffectBoard:new{ n = n }
    self.board:generate(diff)
    self.selected = nil
    self.plugin:saveState(self.board:serialize())
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
end

function RippleEffectScreen:openSizeMenu()
    local sizes = {}
    for _, sz in ipairs(RippleEffectBoard.SIZES) do
        sizes[#sizes + 1] = { id = sz, text = sz .. "\xC3\x97" .. sz }
    end
    MenuHelper.openSizeMenu{
        title     = _("Select grid size"),
        sizes     = sizes,
        current   = self.plugin:getSetting("grid_n", RippleEffectBoard.DEFAULT_N),
        parent    = self,
        on_select = function(sz)
            if sz ~= self.board.n then
                self.plugin:saveSetting("grid_n", sz)
                self:onNewGame()
            end
        end,
    }
end

function RippleEffectScreen:openDifficultyMenu()
    MenuHelper.openDifficultyMenu{
        current   = self.plugin:getSetting("difficulty", "easy"),
        parent    = self,
        on_select = function(id)
            self.plugin:saveSetting("difficulty", id)
            if self.diff_button then
                self.diff_button:setText(self:getDiffButtonText(), self.diff_button.width)
            end
            self:onNewGame()
        end,
    }
end

function RippleEffectScreen:updateStatus(msg)
    local status
    if msg then
        status = msg
    elseif self.board.won then
        status = _("Congratulations! Puzzle solved!")
    else
        local empty = self.board:countEmpty()
        local n     = self.board.n
        local diff  = self.plugin:getSetting("difficulty", "easy")
        local label = MenuHelper.DIFFICULTY_LABELS[diff] or diff
        status = T(_("%1\xC3\x97%2 \xC2\xB7 %3 \xC2\xB7 Empty: %4"), n, n, label, empty)
    end
    ScreenBase.updateStatus(self, status)
end

function RippleEffectScreen:getSizeButtonText()
    local n = self.board.n
    return T(_("Size: %1"), n .. "\xC3\x97" .. n)
end

function RippleEffectScreen:getDiffButtonText()
    local diff  = self.plugin:getSetting("difficulty", "easy")
    local label = MenuHelper.DIFFICULTY_LABELS[diff] or diff
    return T(_("Diff: %1"), label)
end

return RippleEffectScreen
