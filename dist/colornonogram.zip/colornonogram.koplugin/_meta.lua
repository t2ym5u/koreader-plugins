local _ = require("gettext")
return {
    fullname    = _("Color Nonogram"),
    description = _("Colored picross / nonogram"),
    version     = "1.5.0",
}
