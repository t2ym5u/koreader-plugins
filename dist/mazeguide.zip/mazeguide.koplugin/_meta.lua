local _ = require("gettext")
return {
    fullname    = _("Guide & Explorer"),
    description = _("Two readers, one maze: the guide has the map, the explorer is lost inside. Talk your way to the exit."),
    version     = "1.0.0",
}
