local _ = require("gettext")
return {
    version     = "1.2.14",
    fullname    = _("Cours d'échecs"),
    description = _("Puzzles et leçons d'échecs"),
}
