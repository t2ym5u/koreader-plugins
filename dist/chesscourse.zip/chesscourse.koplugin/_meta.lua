local _ = require("gettext")
return {
    version     = "1.2.15",
    fullname    = _("Chess Course"),
    description = _("Chess puzzles and lessons"),
}
