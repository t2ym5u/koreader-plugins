local _ = require("gettext")
return {
    version     = "1.2.11",
    fullname    = _("Cours d'échecs"),
    description = _("Puzzles et leçons d'échecs"),
}
