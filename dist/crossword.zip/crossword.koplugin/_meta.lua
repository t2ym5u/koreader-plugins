local _ = require("gettext")

return {
    fullname    = _("Crossword"),
    description = _("Classic crossword puzzles. Fill the grid from the across and down clues."),
    version     = "1.1.14",
}
