local _ = require("gettext")
return {
    fullname    = _("Bridges"),
    description = _("Connect islands with the right number of bridges"),
    version     = "1.4.1",
}
