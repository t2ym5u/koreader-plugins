return {
    ["Decoded: %1/%2 letters"]            = { fr = "Déchiffré : %1/%2 lettres", es = "Descifrado: %1/%2 letras", de = "Entschlüsselt: %1/%2 Buchstaben" },
    ["Selected: %1  Decoded: %2/%3"]      = { fr = "Sélectionné : %1  Déchiffré : %2/%3", es = "Seleccionado: %1  Descifrado: %2/%3", de = "Ausgewählt: %1  Entschlüsselt: %2/%3" },
    ["Selected: %1 = %2  Decoded: %3/%4"] = { fr = "Sélectionné : %1 = %2  Déchiffré : %3/%4", es = "Seleccionado: %1 = %2  Descifrado: %3/%4", de = "Ausgewählt: %1 = %2  Entschlüsselt: %3/%4" },
    ["Solved! Wins: %1"]                      = { fr = "Résolu ! Victoires : %1", es = "¡Resuelto! Victorias: %1", de = "Gelöst! Siege: %1" },
    ["Tap a cipher letter first."]               = { fr = "Appuyez d'abord sur une lettre chiffrée.", es = "Toca primero una letra cifrada.", de = "Tippe zuerst auf einen verschlüsselten Buchstaben." },
    ["Cryptogram"]                                = { fr = "Cryptogramme", es = "Criptograma", de = "Kryptogramm" },
    ["Substitution cipher word puzzle"]           = { fr = "Casse-tête de mots à chiffrement par substitution", es = "Puzzle de palabras con cifrado por sustitución", de = "Worträtsel mit Substitutionschiffre" },
}
