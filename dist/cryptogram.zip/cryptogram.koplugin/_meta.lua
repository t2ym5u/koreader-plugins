local _ = require("gettext")
return {
    fullname    = _("Cryptogram"),
    description = _("Substitution cipher word puzzle"),
    version     = "1.1.15",
}
