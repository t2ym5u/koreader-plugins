local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"
local function lrequire(name)
    local key = _dir .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. name .. ".lua"))()
    end
    return package.loaded[key]
end

local ButtonTable     = require("ui/widget/buttontable")
local Device          = require("device")
local FrameContainer  = require("ui/widget/container/framecontainer")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local Size            = require("ui/size")
local UIManager       = require("ui/uimanager")
local VerticalGroup   = require("ui/widget/verticalgroup")
local VerticalSpan    = require("ui/widget/verticalspan")
local _               = require("i18n")
local T               = require("ffi/util").template

local ScreenBase             = require("screen_base")
local MenuHelper             = require("menu_helper")
local KeyboardWidget         = lrequire("common/keyboard_widget")
local CryptogramBoard        = lrequire("board")
local CryptogramBoardWidget  = lrequire("board_widget")

local DeviceScreen = Device.screen

-- ---------------------------------------------------------------------------
-- CryptogramScreen
-- ---------------------------------------------------------------------------

local GAME_RULES_EN = _([[
Cryptogram — Rules

Decode the encrypted message by cracking the letter substitution cipher.

Each letter has been replaced by another letter.
The same substitution is used consistently throughout the message.
Tap a cipher letter to select it, then tap the keyboard to type your guess for the real letter.
Use logic and common word patterns to deduce the full message.
]])

local GAME_RULES_FR = [[
Cryptogramme — Règles

Décodez le message chiffré en craquant son chiffre par substitution de lettres.

Chaque lettre a été remplacée par une autre lettre, de façon cohérente dans tout le texte.
Appuyez sur une lettre chiffrée pour la sélectionner, puis tapez votre proposition.
Utilisez les motifs des mots et la fréquence des lettres pour déduire le message complet.
]]

local CryptogramScreen = ScreenBase:extend{}

function CryptogramScreen:init()
    local state = self.plugin:loadState()
    local lang  = self.plugin:getSetting("lang", "en")
    self.board  = CryptogramBoard:new{ lang = lang }
    if not self.board:load(state) then
        -- fresh game
    end
    ScreenBase.init(self)
end

function CryptogramScreen:serializeState()
    return self.board:serialize()
end

function CryptogramScreen:buildLayout()
    local sw           = DeviceScreen:getWidth()
    local sh = DeviceScreen:getHeight()
    local is_landscape = self:isLandscape()

    local btn_width = is_landscape
        and math.max(math.floor(sw * 0.38), 120)
        or  math.floor(sw * 0.9)

    local title_bar = self:buildTitleBar(_("Cryptogram"), function()
        return {
            { text = _("New game"),     callback = function() self:onNewGame() end },
            { text = self:_langLabel(), callback = function() self:openLangMenu() end },
            self:makeRulesButtonConfig(GAME_RULES_EN, GAME_RULES_FR),
        }
    end)

    local action_buttons = ButtonTable:new{
        shrink_unneeded_width = true,
        width   = btn_width,
        buttons = {{
            { text = _("Clear"), callback = function() self:onClearAll() end },
        }},
    }

    local margin      = Size.margin.default
    local padding     = Size.padding.default
    local frame_extra = (padding + margin) * 2

    local board_max_w = is_landscape and math.floor(sw * 0.55) or sw - frame_extra
    local board_max_h = math.floor(sh * 0.35)
    board_max_w = math.max(board_max_w, 80)
    board_max_h = math.max(board_max_h, 60)

    self.board_widget = CryptogramBoardWidget:new{
        board             = self.board,
        max_width         = board_max_w,
        max_height        = board_max_h,
        cipherTapCallback = function(ch) self:onCipherTap(ch) end,
    }

    local board_frame = FrameContainer:new{
        padding = padding,
        margin  = margin,
        self.board_widget,
    }

    -- Keyboard
    self.keyboard_widget = KeyboardWidget.build{
        width  = btn_width,
        layout = (self.board.lang == "fr") and "azerty" or "qwerty",
        onKey  = function(k) self:onVirtualKey(k) end,
    }

    if is_landscape then
        local right = VerticalGroup:new{
            align = "center",
            self.status_text,
            VerticalSpan:new{ width = Size.span.vertical_large },
            self.keyboard_widget,
            VerticalSpan:new{ width = Size.span.vertical_large },
            action_buttons,
        }
        local content = HorizontalGroup:new{
            align  = "center",
            board_frame,
            HorizontalSpan:new{ width = Size.span.horizontal_default },
            right,
        }
        self:buildLandscapeLayout(title_bar, content)
    else
        local content = VerticalGroup:new{
            align = "center",
            board_frame,
        }
        local footer = VerticalGroup:new{
            align = "center",
            self.keyboard_widget,
            VerticalSpan:new{ width = Size.span.vertical_large },
            action_buttons,
            VerticalSpan:new{ width = Size.span.vertical_large },
            self.status_text,
        }
        self:buildPortraitLayout(title_bar, content, footer)
    end
    self:updateStatus()
end

function CryptogramScreen:onCipherTap(ch)
    self.board:selectCipher(ch)
    self.board_widget:refresh()
    self:updateStatus()
    self.plugin:saveState(self.board:serialize())
end

function CryptogramScreen:onVirtualKey(key)
    if not self.board.selected_cipher then
        self:updateStatus(_("Tap a cipher letter first."))
        return
    end
    self.board:assignLetter(key)
    self.board_widget:refresh()
    if self.board:isComplete() then
        self.board.wins = self.board.wins + 1
        self:updateStatus(T(_("Solved! Wins: %1"), self.board.wins))
        self.plugin:saveState(self.board:serialize())
    else
        self:updateStatus()
        self.plugin:saveState(self.board:serialize())
    end
end

function CryptogramScreen:onClearAll()
    self.board:clearAll()
    self.board_widget:refresh()
    self:updateStatus()
    self.plugin:saveState(self.board:serialize())
end

function CryptogramScreen:onNewGame()
    local lang = self.plugin:getSetting("lang", "en")
    self.board.lang = lang
    local wins = self.board.wins
    self.board:newGame()
    self.board.wins = wins
    self.plugin:saveState(self.board:serialize())
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
end

function CryptogramScreen:openLangMenu()
    local items = {
        { id = "en", text = _("English") },
        { id = "fr", text = _("Français") },
    }
    MenuHelper.openPickerMenu{
        title      = _("Language"),
        items      = items,
        current_id = self.plugin:getSetting("lang", "en"),
        parent     = self,
        on_select  = function(lang)
            self.plugin:saveSetting("lang", lang)
            self.board.lang = lang
            if self.lang_btn then
                self.lang_btn:setText(self:_langLabel(), self.lang_btn.width)
            end
            self:onNewGame()
        end,
    }
end

function CryptogramScreen:updateStatus(msg)
    local status
    if msg then
        status = msg
    else
        local sel = self.board.selected_cipher
        local decoded, total = self.board:decodedCount()
        if sel then
            local assigned = self.board.user_map[sel]
            if assigned then
                status = T(_("Selected: %1 = %2  Decoded: %3/%4"),
                    sel, assigned, decoded, total)
            else
                status = T(_("Selected: %1  Decoded: %2/%3"), sel, decoded, total)
            end
        else
            status = T(_("Decoded: %1/%2 letters"), decoded, total)
        end
    end
    ScreenBase.updateStatus(self, status)
end

function CryptogramScreen:_langLabel()
    local lang = self.plugin:getSetting("lang", "en")
    return lang == "fr" and "FR" or "EN"
end

return CryptogramScreen
