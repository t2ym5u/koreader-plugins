local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"
package.path = _dir .. "?.lua;" .. _dir .. "common/?.lua;" .. package.path

local function lrequire(name)
    local key = _dir .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. name .. ".lua"))()
    end
    return package.loaded[key]
end

local PluginBase = require("plugin_base")
local _          = require("i18n")
local Screen     = lrequire("screen")

require("i18n").extend(lrequire("i18n_fr"))

local DoubleOrNothing = PluginBase:extend{
    name      = "doubleornothing",
    menu_text = _("Double or Nothing Party"),
    menu_hint = "tools",
}

function DoubleOrNothing:createScreen()
    return Screen:new{ plugin = self }
end

return DoubleOrNothing
