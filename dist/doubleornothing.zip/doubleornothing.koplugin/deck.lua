-- The question deck: what the next question is, at which difficulty, and
-- never the same one twice until the whole bank has been played.
--
-- Pure Lua, no UI, so it can be tested without KOReader. Questions come from
-- two shapes:
--   * the bundled banks (questions_fr.lua / questions_en.lua), grouped by
--     category:  { { cat = "Sport", q = { { level, question, answer, alt? }, ... } }, ... }
--   * a user's JSON file, a flat list of objects:
--     { question = ..., answer = ..., category = ..., difficulty = 1..5, alt = ... }
-- Deck.normalize() turns either into one flat list of
--   { question, answer, category, level, rated, alt }.

local Deck = {}
Deck.__index = Deck

Deck.MIN_LEVEL = 1
Deck.MAX_LEVEL = 5
-- A question with no usable difficulty sits in the middle of the range, so a
-- user deck without levels still plays (every draw falls back to level 3).
Deck.DEFAULT_LEVEL = 3

local WORD_LEVELS = {
    easy = 1, facile = 1,
    medium = 3, moyen = 3, normal = 3,
    hard = 5, difficile = 5,
}

-- 1..5 from a number, a numeric string or an easy/medium/hard word.
function Deck.parseLevel(v)
    if type(v) == "string" then
        v = tonumber(v) or WORD_LEVELS[v:lower()]
    end
    if type(v) ~= "number" then return Deck.DEFAULT_LEVEL end
    v = math.floor(v + 0.5)
    if v < Deck.MIN_LEVEL then return Deck.MIN_LEVEL end
    if v > Deck.MAX_LEVEL then return Deck.MAX_LEVEL end
    return v
end

local function nonEmpty(s)
    if type(s) == "number" then s = tostring(s) end
    if type(s) ~= "string" then return nil end
    s = s:match("^%s*(.-)%s*$")
    if s == "" then return nil end
    return s
end

local function addEntry(out, question, answer, category, level, alt)
    question, answer = nonEmpty(question), nonEmpty(answer)
    if not question or not answer then return end
    out[#out + 1] = {
        question = question,
        answer   = answer,
        category = nonEmpty(category),
        level    = Deck.parseLevel(level),
        -- false when the file gave no difficulty: the level is then only the
        -- default and the card does not claim one
        rated    = level ~= nil and level ~= "",
        alt      = nonEmpty(alt),
    }
end

-- Flatten a bundled bank or a user JSON list into question records.
-- Malformed entries are skipped rather than failing the whole file.
function Deck.normalize(data)
    local out = {}
    if type(data) ~= "table" then return out end
    for _, item in ipairs(data) do
        if type(item) == "table" then
            if type(item.q) == "table" then
                for _, e in ipairs(item.q) do
                    if type(e) == "table" then
                        addEntry(out, e[2], e[3], item.cat, e[1], e[4])
                    end
                end
            else
                addEntry(out, item.question, item.answer, item.category,
                    item.difficulty or item.level, item.alt)
            end
        end
    end
    return out
end

-- Sorted list of the distinct categories in a normalized list.
function Deck.categories(list)
    local seen, cats = {}, {}
    for _, q in ipairs(list) do
        if q.category and not seen[q.category] then
            seen[q.category] = true
            cats[#cats + 1] = q.category
        end
    end
    table.sort(cats)
    return cats
end

-- A question's identity for the no-repeat rule: its text, so a question that
-- survives a reload or a category change is still recognised as already played.
function Deck.key(q)
    return q.question
end

-- opts.category : only questions of that category (nil = all)
-- opts.used     : shared { [key] = true } set of questions already played;
--                 pass the same table across rebuilds to keep the session's
--                 history when the category or the file changes
-- opts.random   : function(n) -> 1..n (default math.random), for tests
function Deck.new(list, opts)
    opts = opts or {}
    local self = setmetatable({
        random = opts.random or math.random,
        used   = opts.used or {},
        pools  = {},
        count  = 0,
    }, Deck)
    for l = Deck.MIN_LEVEL, Deck.MAX_LEVEL do self.pools[l] = {} end
    for _, q in ipairs(list or {}) do
        if not opts.category or q.category == opts.category then
            local pool = self.pools[Deck.parseLevel(q.level)]
            pool[#pool + 1] = q
            self.count = self.count + 1
        end
    end
    return self
end

function Deck:size()
    return self.count
end

-- Questions of this deck not yet played (at `level`, or at any level).
function Deck:remaining(level)
    local n = 0
    for l = Deck.MIN_LEVEL, Deck.MAX_LEVEL do
        if not level or l == level then
            for _, q in ipairs(self.pools[l]) do
                if not self.used[Deck.key(q)] then n = n + 1 end
            end
        end
    end
    return n
end

function Deck:_pickUnused(level)
    local free = {}
    for _, q in ipairs(self.pools[level]) do
        if not self.used[Deck.key(q)] then free[#free + 1] = q end
    end
    if #free == 0 then return nil end
    return free[self.random(#free)]
end

-- The nearest level that still has an unused question: the asked level
-- first, then one step harder, one step easier, two harder, ... A Double asks
-- for a harder question, so on a tie the harder side wins.
function Deck:_pickNear(level)
    for d = 0, Deck.MAX_LEVEL - Deck.MIN_LEVEL do
        for _, l in ipairs(d == 0 and { level } or { level + d, level - d }) do
            if l >= Deck.MIN_LEVEL and l <= Deck.MAX_LEVEL then
                local q = self:_pickUnused(l)
                if q then return q end
            end
        end
    end
    return nil
end

-- Draw a question at (or as near as possible to) `level` and mark it played.
-- Once every question of the deck has been played, the history of this
-- deck's questions is cleared and a new cycle starts. nil if the deck is empty.
function Deck:draw(level)
    if self.count == 0 then return nil end
    level = Deck.parseLevel(level)
    local q = self:_pickNear(level)
    if not q then
        for l = Deck.MIN_LEVEL, Deck.MAX_LEVEL do
            for _, p in ipairs(self.pools[l]) do self.used[Deck.key(p)] = nil end
        end
        q = self:_pickNear(level)
    end
    self.used[Deck.key(q)] = true
    return q
end

return Deck
