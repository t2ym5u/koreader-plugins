local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"

local Blitbuffer      = require("ffi/blitbuffer")
local CenterContainer = require("ui/widget/container/centercontainer")
local DataStorage     = require("datastorage")
local Device          = require("device")
local Font            = require("ui/font")
local FrameContainer  = require("ui/widget/container/framecontainer")
local Geom            = require("ui/geometry")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local InfoMessage     = require("ui/widget/infomessage")
local LineWidget      = require("ui/widget/linewidget")
local RenderText      = require("ui/rendertext")
local Size            = require("ui/size")
local TextBoxWidget   = require("ui/widget/textboxwidget")
local TextWidget      = require("ui/widget/textwidget")
local UIManager       = require("ui/uimanager")
local VerticalGroup   = require("ui/widget/verticalgroup")
local VerticalSpan    = require("ui/widget/verticalspan")
local _               = require("i18n")
local T               = require("ffi/util").template

local MenuHelper = require("menu_helper")
local Deck       = require("deck")
local Round      = require("round")
local ScreenBase  = require("screen_base")

local DeviceScreen = Device.screen

-- ---------------------------------------------------------------------------
-- Text sizing helpers
--
-- Font:getFace() scales its size by the screen DPI, so a size worked out from
-- pixel dimensions has to be divided back first, or every line comes out
-- about twice too big on a 300 dpi reader and runs off the screen edges.
-- ---------------------------------------------------------------------------

local DPI_SCALE = DeviceScreen:scaleBySize(1000) / 1000

local function pxFace(px)
    return Font:getFace("cfont", math.max(8, math.floor(px / DPI_SCALE)))
end

-- One line of text at up to `px` pixels, shrunk until it fits `max_w`.
local function fitLine(text, px, max_w)
    local face = pxFace(px)
    while px > 12 do
        local m = RenderText:sizeUtf8Text(0, max_w * 10, face, text, true, false)
        if m.x <= max_w then break end
        px   = math.floor(px * 0.9)
        face = pxFace(px)
    end
    return TextWidget:new{ text = text, face = face, max_width = max_w }
end

-- A paragraph wrapped to `width`, centred.
local function wrapText(text, face, width)
    return TextBoxWidget:new{ text = text, face = face, width = width, alignment = "center" }
end

local DEFAULT_DURATION = 0    -- seconds to think before reveal (0 = no timer)
local DEFAULT_NB_TEAMS = 2

local GAME_RULES_EN = _([[
Double or Nothing — Rules

Teams take turns. On your turn, a question is shown — confer with your team, then tap "Reveal" to see the answer.

• ✗ Wrong = you lose everything you were sitting on this turn. Turn ends, pot resets to 0.
• ✓ Correct = the pot is won (1 point first time, then doubled each time you keep going). Choose:
    – Bank it — add the pot to your score, turn ends.
    – Double or Nothing — draw a new (harder) question and risk the pot to double it.

Difficulty: the first question of a turn is easy (level 1 or 2); every Double climbs one level, up to 5.
No question comes back until the whole deck has been played.

Teams swap after every turn (banked or busted).
]])

local GAME_RULES_FR = [[
Quitte ou double — Règles

Les équipes jouent à tour de rôle. À votre tour, une question s'affiche — concertez-vous, puis appuyez sur « Révéler » pour voir la réponse.

• ✗ Faux = vous perdez tout ce que vous aviez en jeu ce tour-ci. Le tour s'arrête, la cagnotte repart à 0.
• ✓ Juste = la cagnotte est gagnée (1 point la première fois, puis doublée à chaque fois que vous continuez). Choisissez :
    – Encaisser — la cagnotte s'ajoute à votre score, le tour s'arrête.
    – Quitte ou double — une nouvelle question (plus dure) arrive, vous risquez la cagnotte pour la doubler.

Difficulté : la première question d'un tour est facile (palier 1 ou 2) ; chaque « Doubler » monte d'un palier, jusqu'à 5.
Aucune question ne revient avant que tout le paquet ait été joué.

Les équipes échangent leur tour après chaque manche (encaissée ou perdue).
]]

local function jsonDecode(s)
    local ok, json = pcall(require, "json")
    if ok then
        local ok2, result = pcall(json.decode, s)
        if ok2 then return result end
    end
    return nil
end

-- ---------------------------------------------------------------------------
-- DoubleOrNothingScreen
-- ---------------------------------------------------------------------------

local DoubleOrNothingScreen = ScreenBase:extend{}

function DoubleOrNothingScreen:init()
    self.lang     = self.plugin:getSetting("lang", "fr")
    self.duration = self.plugin:getSetting("duration", DEFAULT_DURATION)
    local nb      = self.plugin:getSetting("nb_teams", DEFAULT_NB_TEAMS)

    self.teams = {}
    for i = 1, nb do
        self.teams[i] = { name = self.plugin:getSetting("team_name_" .. i, T(_("Team %1"), i)), score = 0 }
    end
    self.current_team = 1

    self.questions       = {}   -- normalized list of the loaded file/bank
    self.categories      = {}
    self.used            = {}   -- questions played this session (Deck no-repeat)
    self.question        = nil  -- the question on screen
    self.level           = 1    -- its difficulty level (1..5)
    self.phase            = "idle"  -- "idle" | "question" | "reveal" | "choice"
    self.pot              = 0
    self.time_remaining  = self.duration

    self:_loadQuestions()
    ScreenBase.init(self)
end

-- ---------------------------------------------------------------------------
-- Question loading
--
-- A user's JSON file in the documents folder wins; otherwise the bundled
-- bank for the question language (questions_<lang>.lua). The bank is loaded
-- with loadfile rather than require so it is not pinned in package.loaded:
-- switching language lets the other one be collected (Kobo Aura, 256 MB).
-- ---------------------------------------------------------------------------

local function loadBundled(lang)
    local chunk = loadfile(_dir .. "questions_" .. lang .. ".lua")
    if not chunk then return nil end
    local ok, data = pcall(chunk)
    if ok and type(data) == "table" then return data end
    return nil
end

function DoubleOrNothingScreen:_readQuestionData()
    local docs = DataStorage:getDataDir()
    for _, path in ipairs({
        docs .. "/doubleornothing_questions_" .. self.lang .. ".json",
        docs .. "/doubleornothing_questions.json",
    }) do
        local f = io.open(path, "r")
        if f then
            local content = f:read("*all")
            f:close()
            local list = Deck.normalize(jsonDecode(content))
            if #list > 0 then return list end
        end
    end
    return Deck.normalize(loadBundled(self.lang) or loadBundled("en"))
end

function DoubleOrNothingScreen:_loadQuestions()
    self.questions  = self:_readQuestionData()
    self.categories = Deck.categories(self.questions)
    self.category   = self.plugin:getSetting("category_" .. self.lang, "all")
    local known = false
    for _, c in ipairs(self.categories) do
        if c == self.category then known = true end
    end
    if not known then self.category = "all" end
    self:_buildDeck()
end

function DoubleOrNothingScreen:_buildDeck()
    self.deck = Deck.new(self.questions, {
        category = self.category ~= "all" and self.category or nil,
        used     = self.used,
    })
end

function DoubleOrNothingScreen:_deckSize()
    return self.deck and self.deck:size() or 0
end

-- Draw the question for the current level; nil when the deck is empty.
function DoubleOrNothingScreen:_drawQuestion()
    self.question = self.deck and self.deck:draw(self.level) or nil
end

function DoubleOrNothingScreen:_currentQuestion()
    return self.question
end

-- ---------------------------------------------------------------------------
-- Timer (optional reflection countdown during "question" phase)
-- ---------------------------------------------------------------------------

function DoubleOrNothingScreen:_startCountdown()
    if self.duration <= 0 then return end
    self._tick_gen = (self._tick_gen or 0) + 1
    local gen = self._tick_gen
    UIManager:scheduleIn(1, function() self:_onTick(gen) end)
end

function DoubleOrNothingScreen:_stopCountdown()
    self._tick_gen = (self._tick_gen or 0) + 1
end

function DoubleOrNothingScreen:_onTick(gen)
    if gen ~= self._tick_gen then return end
    self.time_remaining = math.max(0, self.time_remaining - 1)
    if self.timer_widget then
        self.timer_widget:setText(self:_timerText())
        UIManager:setDirty(self, function() return "fast", self.dimen end)
    end
    if self.time_remaining <= 0 then
        self:onReveal()
    else
        UIManager:scheduleIn(1, function() self:_onTick(gen) end)
    end
end

function DoubleOrNothingScreen:_timerText()
    if self.duration <= 0 then return "" end
    local m = math.floor(self.time_remaining / 60)
    local s = self.time_remaining % 60
    return string.format("%d:%02d", m, s)
end

-- ---------------------------------------------------------------------------
-- Game actions
-- ---------------------------------------------------------------------------

function DoubleOrNothingScreen:onStartTurn()
    if self:_deckSize() == 0 then
        UIManager:show(InfoMessage:new{
            text = T(_("No questions loaded.\n\nCopy %1\nto KOReader's documents folder."),
                "doubleornothing_questions_" .. self.lang .. ".json"),
            timeout = 6,
        })
        return
    end
    self.pot             = 0
    self.level           = Round.startLevel()
    self:_drawQuestion()
    self.time_remaining  = self.duration
    self.phase           = "question"
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
    self:_startCountdown()
end

function DoubleOrNothingScreen:onReveal()
    self:_stopCountdown()
    self.phase = "reveal"
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
end

function DoubleOrNothingScreen:onCorrect()
    self.pot = Round.nextPot(self.pot)
    self.phase = "choice"
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
end

function DoubleOrNothingScreen:onWrong()
    local team  = self.teams[self.current_team]
    UIManager:show(InfoMessage:new{
        text = T(_("%1 loses it all (%2 pt in play). Next team!"), team.name, self.pot),
        timeout = 3,
    })
    self:_endTurn()
end

function DoubleOrNothingScreen:onBank()
    local team = self.teams[self.current_team]
    team.score = team.score + self.pot
    self:_endTurn()
end

function DoubleOrNothingScreen:onDoubleAgain()
    self.level           = Round.nextLevel(self.level)
    self:_drawQuestion()
    self.time_remaining  = self.duration
    self.phase           = "question"
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
    self:_startCountdown()
end

function DoubleOrNothingScreen:_endTurn()
    self.pot           = 0
    self.question      = nil
    self.current_team  = Round.nextTeam(self.current_team, #self.teams)
    self.phase          = "idle"
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
end

-- New game: scores back to zero, first team to play, nothing in the pot.
function DoubleOrNothingScreen:onNewGame()
    self:_stopCountdown()
    for _, t in ipairs(self.teams) do t.score = 0 end
    self.current_team = 1
    self.pot          = 0
    self.question     = nil
    self.phase        = "idle"
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
end

-- ---------------------------------------------------------------------------
-- Options
-- ---------------------------------------------------------------------------

function DoubleOrNothingScreen:_durationLabel(dur)
    if dur <= 0 then return _("Off") end
    return string.format("%d:%02d", math.floor(dur / 60), dur % 60)
end

function DoubleOrNothingScreen:onReloadFile()
    self:_loadQuestions()
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
end

function DoubleOrNothingScreen:openLangMenu()
    MenuHelper.openPickerMenu{
        title = _("Language"),
        items = { { id = "fr", text = "Français" }, { id = "en", text = "English" } },
        current_id = self.lang, parent = self,
        on_select = function(lang)
            self.lang = lang
            self.plugin:saveSetting("lang", lang)
            self:_loadQuestions()
            self:buildLayout()
            UIManager:setDirty(self, function() return "ui", self.dimen end)
        end,
    }
end

function DoubleOrNothingScreen:_categoryLabel()
    if self.category == "all" then return _("Category: All") end
    return T(_("Category: %1"), self.category)
end

function DoubleOrNothingScreen:openCategoryMenu()
    local items = { { id = "all", text = _("All") } }
    for _i, c in ipairs(self.categories) do
        items[#items + 1] = { id = c, text = c }
    end
    MenuHelper.openPickerMenu{
        title = _("Category"),
        items = items, current_id = self.category, parent = self,
        on_select = function(cat)
            self.category = cat
            self.plugin:saveSetting("category_" .. self.lang, cat)
            self:_buildDeck()
            self:buildLayout()
            UIManager:setDirty(self, function() return "ui", self.dimen end)
        end,
    }
end

function DoubleOrNothingScreen:openTeamsMenu()
    local items = {}
    for n = 2, 6 do
        items[#items + 1] = { id = n, text = T(_("%1 teams"), n) }
    end
    MenuHelper.openPickerMenu{
        title = _("Teams"),
        items = items, current_id = #self.teams, parent = self,
        on_select = function(n)
            self.plugin:saveSetting("nb_teams", n)
            while #self.teams < n do
                local i = #self.teams + 1
                self.teams[i] = { name = T(_("Team %1"), i), score = 0 }
            end
            while #self.teams > n do table.remove(self.teams) end
            if self.current_team > #self.teams then self.current_team = 1 end
            self:buildLayout()
            UIManager:setDirty(self, function() return "ui", self.dimen end)
        end,
    }
end

function DoubleOrNothingScreen:openDurationMenu()
    local items = {}
    for _, d in ipairs({ 0, 15, 20, 30, 45 }) do
        items[#items + 1] = { id = d, text = self:_durationLabel(d) }
    end
    MenuHelper.openPickerMenu{
        title = _("Timer"),
        items = items, current_id = self.duration, parent = self,
        on_select = function(dur)
            self.duration = dur
            self.plugin:saveSetting("duration", dur)
        end,
    }
end

-- ---------------------------------------------------------------------------
-- Layout
-- ---------------------------------------------------------------------------

function DoubleOrNothingScreen:buildLayout()
    if self.phase == "idle" then
        self:_buildIdleLayout()
    else
        self:_buildPlayLayout()
    end
    self[1] = self.layout
    self:updateStatus()
end

function DoubleOrNothingScreen:_titleBar()
    return self:buildTitleBar(_("Double or Nothing"), function()
        return {
            { text = _("New game"), callback = function() self:onNewGame() end },
            { text = T(_("Language: %1"), self.lang:upper()), callback = function() self:openLangMenu() end },
            { text = self:_categoryLabel(), callback = function() self:openCategoryMenu() end },
            { text = T(_("Teams: %1"), #self.teams),          callback = function() self:openTeamsMenu() end },
            { text = T(_("Timer: %1"), self:_durationLabel(self.duration)),
              callback = function() self:openDurationMenu() end },
            { text = _("Reload file"), callback = function() self:onReloadFile() end },
            self:makeRulesButtonConfig(GAME_RULES_EN, GAME_RULES_FR),
        }
    end)
end

function DoubleOrNothingScreen:_buildIdleLayout()
    local team  = self.teams[self.current_team]

    local title_bar = self:_titleBar()
    local controls  = self:_buildControls({
        { text = _("Start turn"),
          callback = function() self:onStartTurn() end },
    })
    local bw, bh = self:getBoardBudget(title_bar, controls)
    local short  = math.min(bw, bh)
    local vs     = Size.span.vertical_large

    local deck_line
    if self:_deckSize() == 0 then
        deck_line = "⚠ " .. T(_("No questions loaded.\n\nCopy %1\nto KOReader's documents folder."),
            "doubleornothing_questions_" .. self.lang .. ".json")
    else
        deck_line = T(_("%1 questions loaded"), self:_deckSize())
    end

    self.timer_widget = nil
    local content = VerticalGroup:new{
        align = "center",
        fitLine(team.name:upper(), short * 0.14, bw),
        VerticalSpan:new{ width = vs },
        wrapText(_("It's your turn!"), Font:getFace("infofont"), bw),
        VerticalSpan:new{ width = vs * 4 },
        wrapText(deck_line, Font:getFace("smallinfofont"), bw),
    }
    self:_placeLayout(title_bar, content, controls)
end

function DoubleOrNothingScreen:_buildPlayLayout()
    local q     = self:_currentQuestion()
    local team  = self.teams[self.current_team]

    local rows
    if self.phase == "question" then
        rows = {
            { text = _("Reveal answer"),
              callback = function() self:onReveal() end },
        }
    elseif self.phase == "reveal" then
        rows = {
            { text = "✓  " .. _("Correct"),
              callback = function() self:onCorrect() end },
            { text = "✗  " .. _("Wrong"),
              callback = function() self:onWrong() end },
        }
    else -- "choice"
        -- No emoji here: the UI fonts have no glyph for the 🏦 that used to
        -- prefix "Bank", so it rendered as a missing-glyph box.
        local next_pot = self.pot * 2
        rows = {
            { text = T(_("Bank +%1"), self.pot),
              callback = function() self:onBank() end },
            { text = T(_("Double → %1"), next_pot),
              callback = function() self:onDoubleAgain() end },
        }
    end

    local title_bar = self:_titleBar()
    local controls  = self:_buildControls(rows)
    local bw, bh = self:getBoardBudget(title_bar, controls)
    local short  = math.min(bw, bh)
    local vs     = Size.span.vertical_large

    local pot_text = T(_("Pot in play: %1 pt"), self.pot)

    -- The card fills the width; its text wraps inside the frame.
    local frame_pad = Size.padding.large
    local inner_w   = bw - 2 * (frame_pad + Size.border.window)
    local card_group
    if not q then
        card_group = wrapText(_("No questions."), Font:getFace("infofont"), inner_w)
    else
        local question_text = q.question or "?"
        local answer_text   = q.answer or "?"
        local badge = {}
        if q.category then badge[#badge + 1] = q.category end
        if q.rated then badge[#badge + 1] = T(_("Level %1"), q.level) end

        local body = VerticalGroup:new{ align = "center" }
        if #badge > 0 then
            body[#body + 1] = wrapText("[ " .. table.concat(badge, " · ") .. " ]", Font:getFace("smallinfofont"), inner_w)
            body[#body + 1] = VerticalSpan:new{ width = vs }
        end

        local qlen = #question_text
        local q_px = short * (qlen > 80 and 0.045 or qlen > 40 and 0.055 or 0.065)
        body[#body + 1] = wrapText(question_text, pxFace(q_px), inner_w)

        if self.phase == "reveal" or self.phase == "choice" then
            body[#body + 1] = VerticalSpan:new{ width = vs * 2 }
            body[#body + 1] = LineWidget:new{
                background = Blitbuffer.COLOR_DARK_GRAY,
                dimen      = Geom:new{ w = math.floor(inner_w * 0.6), h = Size.line.medium },
            }
            body[#body + 1] = VerticalSpan:new{ width = vs }
            body[#body + 1] = TextWidget:new{
                text = _("Answer:"),
                face = Font:getFace("smallinfofont"),
            }
            body[#body + 1] = VerticalSpan:new{ width = vs }
            body[#body + 1] = wrapText(answer_text, pxFace(short * 0.08), inner_w)
            if q.alt then
                body[#body + 1] = VerticalSpan:new{ width = vs }
                body[#body + 1] = wrapText(T(_("Also accepted: %1"), q.alt), Font:getFace("smallinfofont"), inner_w)
            end
        end

        card_group = body
    end

    local card_frame = FrameContainer:new{
        padding = frame_pad,
        margin  = 0,
        width   = bw,
        CenterContainer:new{
            dimen = Geom:new{ w = inner_w, h = card_group:getSize().h },
            card_group,
        },
    }

    local content = VerticalGroup:new{ align = "center" }
    self.timer_widget = nil
    if self.phase == "question" and self.duration > 0 then
        self.timer_widget = TextWidget:new{
            text = self:_timerText(),
            face = pxFace(short * 0.1),
        }
        content[#content + 1] = self.timer_widget
        content[#content + 1] = VerticalSpan:new{ width = vs }
    end
    content[#content + 1] = fitLine(team.name:upper(), short * 0.07, bw)
    content[#content + 1] = VerticalSpan:new{ width = vs }
    content[#content + 1] = TextWidget:new{ text = pot_text, face = Font:getFace("smallinfofont"), max_width = bw }
    content[#content + 1] = VerticalSpan:new{ width = vs * 2 }
    content[#content + 1] = card_frame
    self:_placeLayout(title_bar, content, controls)
end

-- Status line + action bar, built before the content so the content can be
-- sized from what they leave over (getBoardBudget).
function DoubleOrNothingScreen:_buildControls(rows)
    self.status_text:setMaxWidth(self:getControlsWidth())
    return VerticalGroup:new{
        align = "center",
        self.status_text,
        VerticalSpan:new{ width = Size.span.vertical_large },
        self:buildActionBar(rows),
    }
end

function DoubleOrNothingScreen:_placeLayout(title_bar, content, controls)
    if self:isLandscape() then
        self:buildLandscapeLayout(title_bar, HorizontalGroup:new{
            align = "center",
            content,
            HorizontalSpan:new{ width = self:getGutter() },
            controls,
        })
    else
        self:buildPortraitLayout(title_bar, content,
            VerticalGroup:new{ align = "center", controls, VerticalSpan:new{ width = self:getGutter() } })
    end
end

-- "Team 1: 3 · Team 2: 1"
function DoubleOrNothingScreen:_scoreStatus(list)
    local parts = {}
    for _i, t in ipairs(list) do
        parts[#parts + 1] = T(_("%1: %2"), t.name, t.score)
    end
    return self:joinStatus((table.unpack or unpack)(parts))
end

-- ---------------------------------------------------------------------------
-- Status bar
-- ---------------------------------------------------------------------------

function DoubleOrNothingScreen:updateStatus(msg)
    if msg then ScreenBase.updateStatus(self, msg); return end
    ScreenBase.updateStatus(self, self:_scoreStatus(self.teams))
end

function DoubleOrNothingScreen:onClose()
    self:_stopCountdown()
    ScreenBase.onClose(self)
end

return DoubleOrNothingScreen
