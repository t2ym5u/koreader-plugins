local _ = require("gettext")
return {
    fullname    = _("Mystery Face"),
    description = _("Two readers, two secret characters: ask yes/no questions and be the first to find the other's."),
    version     = "1.0.0",
}
