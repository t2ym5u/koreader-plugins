local _ = require("gettext")
return {
    fullname    = _("Windoku"),
    description = _("Sudoku with 4 windowed inner regions"),
    version     = "1.6.0",
}
