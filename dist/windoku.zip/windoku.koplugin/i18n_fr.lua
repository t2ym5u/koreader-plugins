return {
    ["Windoku"] = { fr = "Windoku", es = "Windoku", de = "Windoku" },
    ["Sudoku with 4 windowed inner regions"] = { fr = "Sudoku avec 4 régions internes en fenêtres", es = "Sudoku con 4 regiones internas en ventana", de = "Sudoku mit 4 fensterförmigen inneren Regionen" },
}
