local _ = require("gettext")
return {
    fullname    = _("Pickomino"),
    description = _("Combinatorial dice and tile logic game"),
    version     = "1.1.10",
}
