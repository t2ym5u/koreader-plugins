local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"

local function lrequire(name)
    local key = _dir .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. name .. ".lua"))()
    end
    return package.loaded[key]
end


local Device          = require("device")
local Font            = require("ui/font")
local FrameContainer  = require("ui/widget/container/framecontainer")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local ScrollTextWidget = require("ui/widget/scrolltextwidget")
local Size            = require("ui/size")
local TextWidget      = require("ui/widget/textwidget")
local UIManager       = require("ui/uimanager")
local VerticalGroup   = require("ui/widget/verticalgroup")
local VerticalSpan    = require("ui/widget/verticalspan")
local _               = require("i18n")
local T               = require("ffi/util").template

local MenuHelper   = require("menu_helper")
local ScreenBase   = require("screen_base")
local BoggleBoard  = lrequire("board")  -- board.lua is a symlink → boggle.koplugin/board.lua
local BoardDisplay = lrequire("board_widget")

local DeviceScreen = Device.screen

local DEFAULT_DURATION = 180  -- 3 minutes

local GAME_RULES_EN = _([[
Boggle Party — Rules

Everyone gets a sheet of paper. When the timer starts, all players simultaneously search for words in the grid.

Rules:
• Letters must be adjacent (horizontally, vertically, or diagonally).
• Each letter may be used only once per word.
• Minimum 3 letters.
• Longer words score more: 3=1pt, 4=1pt, 5=2pts, 6=3pts, 7=5pts, 8+=11pts.

When time runs out:
• Read your lists aloud — any word found by more than one player is cancelled.
• Score only your unique words.
]])

local GAME_RULES_FR = [[
Boggle Party — Règles

Chaque joueur prend une feuille. Au signal, tous cherchent simultanément des mots dans la grille.

Règles :
• Les lettres doivent être adjacentes (horizontalement, verticalement ou en diagonale).
• Chaque lettre ne peut être utilisée qu'une seule fois par mot.
• Minimum 3 lettres.
• Score : 3=1pt, 4=1pt, 5=2pts, 6=3pts, 7=5pts, 8+=11pts.

À la fin du temps :
• Chacun lit sa liste à voix haute — les mots trouvés par plusieurs joueurs sont annulés.
• Seuls les mots uniques comptent.
]]

-- ---------------------------------------------------------------------------
-- PartyScreen
-- ---------------------------------------------------------------------------

local PartyScreen = ScreenBase:extend{}

function PartyScreen:init()
    local lang = self.plugin:getSetting("lang", "en")
    self.duration       = self.plugin:getSetting("duration", DEFAULT_DURATION)
    self.show_timer     = self.plugin:getSetting("show_timer", true)
    self.time_remaining = self.duration
    self.phase          = "playing"  -- "playing" | "solved"
    self.timer_running  = false
    self.board          = BoggleBoard:new{ lang = lang }
    ScreenBase.init(self)
    self:_startCountdown()
end

function PartyScreen:serializeState()
    return { lang = self.board.lang, duration = self.duration }
end

-- ---------------------------------------------------------------------------
-- Countdown
-- ---------------------------------------------------------------------------

function PartyScreen:_startCountdown()
    if self.phase ~= "playing" then return end
    -- Generation counter: any tick from a previous countdown sees a stale gen and exits.
    self._tick_gen = (self._tick_gen or 0) + 1
    local gen = self._tick_gen
    UIManager:scheduleIn(1, function() self:_onTick(gen) end)
end

function PartyScreen:_stopCountdown()
    -- Bump generation so any pending tick becomes a no-op.
    self._tick_gen = (self._tick_gen or 0) + 1
end

function PartyScreen:_onTick(gen)
    if gen ~= self._tick_gen then return end
    self.time_remaining = math.max(0, self.time_remaining - 1)
    self:_refreshTimerWidget()
    if self.time_remaining <= 0 then
        self:_onTimerEnd()
    else
        UIManager:scheduleIn(1, function() self:_onTick(gen) end)
    end
end

function PartyScreen:_refreshTimerWidget()
    if not self.timer_widget then return end
    self.timer_widget:setText(self:_timerText())
    -- "fast" (A2) refresh for the full screen: minimal flicker, good enough for a digit change.
    UIManager:setDirty(self, function() return "fast", self.dimen end)
end

function PartyScreen:_onTimerEnd()
    self:_stopCountdown()
    self.phase = "solved"
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
end

function PartyScreen:_timerText()
    local m = math.floor(self.time_remaining / 60)
    local s = self.time_remaining % 60
    return string.format("%d:%02d", m, s)
end

-- ---------------------------------------------------------------------------
-- Actions
-- ---------------------------------------------------------------------------

function PartyScreen:onNewGame()
    self:_stopCountdown()
    self.board:newGame()
    self.time_remaining = self.duration
    self.phase          = "playing"
    self.plugin:saveState(self:serializeState())
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
    self:_startCountdown()
end

function PartyScreen:onSolveNow()
    self:_stopCountdown()
    self.time_remaining = 0
    self:_onTimerEnd()
end

function PartyScreen:openLangMenu()
    local items = {
        { id = "en", text = _("English") },
        { id = "fr", text = _("Français") },
    }
    MenuHelper.openPickerMenu{
        title      = _("Language"),
        items      = items,
        current_id = self.board.lang,
        parent     = self,
        on_select  = function(lang)
            self.board.lang = lang
            self.plugin:saveSetting("lang", lang)
            self.board:_loadDict()
            self:onNewGame()
        end,
    }
end

function PartyScreen:openDurationMenu()
    local durations = {
        { id = 120, text = "2:00" },
        { id = 180, text = "3:00" },
        { id = 240, text = "4:00" },
        { id = 300, text = "5:00" },
        { id = "__toggle_timer__", text = self.show_timer and _("Hide timer") or _("Show timer") },
    }
    MenuHelper.openPickerMenu{
        title      = _("Duration"),
        items      = durations,
        current_id = self.duration,
        parent     = self,
        on_select  = function(dur)
            if dur == "__toggle_timer__" then
                self.show_timer = not self.show_timer
                self.plugin:saveSetting("show_timer", self.show_timer)
                self:buildLayout()
                UIManager:setDirty(self, function() return "ui", self.dimen end)
            else
                self.duration = dur
                self.plugin:saveSetting("duration", dur)
                self:onNewGame()
            end
        end,
    }
end

-- ---------------------------------------------------------------------------
-- Solutions text
-- ---------------------------------------------------------------------------

function PartyScreen:_buildSolutionText()
    local all = self.board._all_words or {}
    local by_len = {}
    local max_len = 3
    for w in pairs(all) do
        local l = #w
        if l > max_len then max_len = l end
        by_len[l] = by_len[l] or {}
        by_len[l][#by_len[l] + 1] = w
    end
    for _, words in pairs(by_len) do
        table.sort(words)
    end

    local total = 0
    for _ in pairs(all) do total = total + 1 end

    local lines = {}
    local is_fr = self.board.lang == "fr"
    for l = 3, max_len do
        local words = by_len[l]
        if words and #words > 0 then
            local label = is_fr
                and string.format("%d lettres (%d) : ", l, #words)
                or  string.format("%d letters (%d): ",  l, #words)
            lines[#lines + 1] = label .. table.concat(words, ", ")
        end
    end
    lines[#lines + 1] = ""
    lines[#lines + 1] = is_fr
        and string.format("Total : %d mot%s", total, total > 1 and "s" or "")
        or  string.format("Total: %d word%s",  total, total > 1 and "s" or "")

    return table.concat(lines, "\n")
end

-- ---------------------------------------------------------------------------
-- Layout
-- ---------------------------------------------------------------------------

function PartyScreen:_langLabel()
    return T(_("Language: %1"), self.board.lang == "fr" and "FR" or "EN")
end

function PartyScreen:_durationLabel()
    return T(_("Duration: %1"), string.format("%d:%02d", math.floor(self.duration / 60), self.duration % 60))
end

function PartyScreen:buildLayout()
    local is_landscape = self:isLandscape()
    local playing      = self.phase == "playing"

    local title_bar = self:buildTitleBar(_("Boggle Party"), function()
        local items = {
            { text = _("New game"),          callback = function() self:onNewGame() end },
            { text = self:_langLabel(),      callback = function() self:openLangMenu() end },
            { text = self:_durationLabel(),  callback = function() self:openDurationMenu() end },
        }
        if self.phase == "playing" then
            items[#items + 1] = { text = _("Show solution"), callback = function() self:onSolveNow() end }
        end
        items[#items + 1] = self:makeRulesButtonConfig(GAME_RULES_EN, GAME_RULES_FR)
        return items
    end)

    -- Controls: the status, then the big countdown while playing or the
    -- solutions list once time is up, then the action bar.
    local controls_w = self:getControlsWidth()
    local sh = self.dimen.h
    self.status_text:setMaxWidth(controls_w)
    local panel
    self.timer_widget = nil
    if playing then
        if self.show_timer then
            -- Readable from across the table: a sixth of the short side,
            -- in pixels (Font:getFace scales by the DPI, hence the division).
            local timer_px = math.floor(math.min(self.dimen.w, sh) * 0.16)
            self.timer_widget = TextWidget:new{
                text = self:_timerText(),
                face = Font:getFace("cfont",
                    math.max(24, math.floor(timer_px * 1000 / DeviceScreen:scaleBySize(1000)))),
            }
            panel = self.timer_widget
        end
    else
        panel = ScrollTextWidget:new{
            text   = self:_buildSolutionText(),
            face   = Font:getFace("smallinfofont"),
            width  = controls_w,
            height = math.floor(sh * (is_landscape and 0.6 or 0.35)),
            dialog = self,
        }
    end

    local buttons = { { text = _("New game"), callback = function() self:onNewGame() end } }
    if playing then
        buttons[#buttons + 1] = { text = _("Solutions"), callback = function() self:onSolveNow() end }
    end
    local controls = VerticalGroup:new{ align = "center", self.status_text }
    if panel then
        table.insert(controls, VerticalSpan:new{ width = Size.span.vertical_large })
        table.insert(controls, panel)
    end
    table.insert(controls, VerticalSpan:new{ width = Size.span.vertical_large })
    table.insert(controls, self:buildActionBar(buttons))

    -- Board: as large as the budget allows. It draws its own border, so the
    -- frame only pads it.
    local frame_pad   = Size.padding.default
    local frame_extra = 2 * frame_pad
    local budget_w, budget_h = self:getBoardBudget(title_bar, controls)
    local board_size = math.max(math.min(budget_w, budget_h) - frame_extra, 80)
    self.board_widget = BoardDisplay:new{
        board      = self.board,
        max_width  = board_size,
        max_height = board_size,
    }
    local board_frame = FrameContainer:new{
        padding    = frame_pad,
        margin     = 0,
        bordersize = 0,
        self.board_widget,
    }

    if is_landscape then
        local content = HorizontalGroup:new{
            align = "center",
            board_frame,
            HorizontalSpan:new{ width = self:getGutter() },
            controls,
        }
        self:buildLandscapeLayout(title_bar, content)
    else
        self:buildPortraitLayout(title_bar, board_frame,
            VerticalGroup:new{ align = "center", controls, VerticalSpan:new{ width = self:getGutter() } })
    end

    self:updateStatus()
end

function PartyScreen:updateStatus(msg)
    local status
    if msg then
        status = msg
    elseif self.phase == "playing" then
        -- The duration only when the countdown is hidden: the big timer
        -- already reads it out, and the line must fit the landscape panel.
        status = self:joinStatus(
            T(_("Words: %1"), self.board.total_possible),
            not self.show_timer and T(_("Duration: %1"), string.format("%d:%02d",
                math.floor(self.duration / 60), self.duration % 60)) or nil)
    else
        status = self:joinStatus(_("Solutions"), T(_("Words: %1"), self.board.total_possible))
    end
    ScreenBase.updateStatus(self, status)
end

function PartyScreen:onClose()
    self:_stopCountdown()
    ScreenBase.onClose(self)
end

return PartyScreen
