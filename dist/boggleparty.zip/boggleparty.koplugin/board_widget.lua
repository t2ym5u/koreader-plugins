local Blitbuffer     = require("ffi/blitbuffer")
local Device         = require("device")
local Font           = require("ui/font")
local Geom           = require("ui/geometry")
local InputContainer = require("ui/widget/container/inputcontainer")
local RenderText     = require("ui/rendertext")

local gwb      = require("grid_widget_base")
local drawLine = gwb.drawLine

local C_BG     = Blitbuffer.COLOR_WHITE
local C_TILE   = Blitbuffer.COLOR_GRAY_E
local C_GRID   = Blitbuffer.COLOR_GRAY_9
local C_BORDER = Blitbuffer.COLOR_BLACK
local C_TEXT   = Blitbuffer.COLOR_BLACK

-- ---------------------------------------------------------------------------
-- BoardDisplay — read-only grid widget for Boggle Party
-- No gesture handling; maximises letter size for table visibility.
-- ---------------------------------------------------------------------------

local BoardDisplay = InputContainer:extend{
    board      = nil,
    max_width  = 300,
    max_height = 300,
}

local Screen = Device.screen

-- Largest face whose ink for `sample` fits max_w x max_h. Measured unbounded
-- (a max_width limit cuts the text, so the width test could never fail), ink
-- height is y_top + y_bottom, and Font:getFace scales its size by the DPI, so
-- the pixel bound is converted back first.
local function fitFace(name, sample, max_w, max_h)
    local lo = 6
    local hi = math.max(lo, math.floor(max_h * 1000 / Screen:scaleBySize(1000)) * 2)
    local best = lo
    while lo <= hi do
        local mid = math.floor((lo + hi) / 2)
        local m = RenderText:sizeUtf8Text(0, Screen:getWidth(), Font:getFace(name, mid), sample, true, false)
        if m.x <= max_w and m.y_top + m.y_bottom <= max_h then
            best, lo = mid, mid + 1
        else
            hi = mid - 1
        end
    end
    return Font:getFace(name, best)
end

-- Centre `text` on (cx, cy): the baseline sits half the ink height below cy.
local function centeredText(bb, text, face, cx, cy)
    local m  = RenderText:sizeUtf8Text(0, Screen:getWidth(), face, text, true, false)
    local tx = cx - math.floor(m.x / 2)
    local ty = cy + math.floor((m.y_top - m.y_bottom) / 2)
    RenderText:renderUtf8Text(bb, tx, ty, face, text, true, false, C_TEXT)
end

function BoardDisplay:init()
    local n    = self.board.n
    local cell = math.floor(math.min(self.max_width / n, self.max_height / n))
    self.cell  = math.max(cell, 20)
    self.w     = self.cell * n
    self.h     = self.cell * n
    self.dimen = Geom:new{ w = self.w, h = self.h }
    -- Bigger than Boggle's own letters: this grid is read from across a table.
    self.letter_face = fitFace("cfont", "W", math.floor(self.cell * 0.75), math.floor(self.cell * 0.56))
end

function BoardDisplay:paintTo(bb, x, y)
    local n    = self.board.n
    local cell = self.cell
    local pad  = math.max(3, math.floor(cell * 0.06))

    bb:paintRect(x, y, self.w, self.h, C_BG)

    for r = 1, n do
        for c = 1, n do
            local cx = x + (c - 1) * cell
            local cy = y + (r - 1) * cell
            bb:paintRect(cx + pad, cy + pad, cell - 2 * pad, cell - 2 * pad, C_TILE)
            centeredText(bb, self.board.grid[r][c], self.letter_face,
                cx + math.floor(cell / 2), cy + math.floor(cell / 2))
        end
    end

    local thin = 1
    for i = 0, n do
        drawLine(bb, x + i * cell, y,           thin,   self.h, C_GRID)
        drawLine(bb, x,            y + i * cell, self.w, thin,   C_GRID)
    end
    local bw = math.max(2, thin)
    drawLine(bb, x,               y,                self.w, bw,     C_BORDER)
    drawLine(bb, x,               y + self.h - bw,  self.w, bw,     C_BORDER)
    drawLine(bb, x,               y,                bw,     self.h, C_BORDER)
    drawLine(bb, x + self.w - bw, y,                bw,     self.h, C_BORDER)
end

return BoardDisplay
