return {
    ["Nurikabe"] = { fr = "Nurikabe", es = "Nurikabe", de = "Nurikabe" },
    ["Paint the river: connect islands of numbered white cells."] = { fr = "Peignez la rivière : reliez les îlots de cases blanches numérotées.", es = "Pinta el río: conecta las islas de casillas blancas numeradas.", de = "Male den Fluss: Verbinde die Inseln nummerierter weißer Zellen." },
}
