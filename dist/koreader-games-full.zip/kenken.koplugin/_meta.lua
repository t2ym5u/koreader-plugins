local _ = require("gettext")

return {
    fullname    = _("KenKen"),
    description = _("Fill the grid with digits satisfying row, column and cage arithmetic constraints."),
    version     = "1.5.1",
}
