local _ = require("gettext")
return {
    fullname    = _("Fillomino"),
    description = _("Fill regions with matching numbers"),
    version     = "1.1.11",
}
