return {
    version     = "1.1.9",
    fullname    = "Dames",
    description = "Jeu de dames 8x8",
}
