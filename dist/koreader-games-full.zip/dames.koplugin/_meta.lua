return {
    name        = "dames",
    version     = "1.1.8",
    fullname    = "Dames",
    description = "Jeu de dames 8x8",
}
