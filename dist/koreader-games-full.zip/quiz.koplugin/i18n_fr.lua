return {
    ["General knowledge quiz — everyone writes their answer, then reveal."] = { fr = "Quiz de culture générale — chacun écrit sa réponse, puis on révèle.", es = "Quiz de cultura general — todos escriben su respuesta, luego se revela.", de = "Allgemeinwissen-Quiz — alle schreiben ihre Antwort, dann wird aufgedeckt." },
    ["Quiz Party"] = { fr = "Quiz Party", es = "Quiz Party", de = "Quiz Party" },
}
