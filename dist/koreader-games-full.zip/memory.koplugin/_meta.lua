local _ = require("gettext")
return {
    fullname    = _("Mémoire"),
    description = _("Jeu de mémoire — trouvez les paires de cartes."),
    version     = "1.1.9",
}
