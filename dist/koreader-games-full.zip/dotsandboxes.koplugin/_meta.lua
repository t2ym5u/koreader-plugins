local _ = require("gettext")

return {
    version     = "1.1.4",
    fullname    = _("Dots and Boxes"),
    description = _("Dots and Boxes — draw lines, close boxes, keep control."),
}
