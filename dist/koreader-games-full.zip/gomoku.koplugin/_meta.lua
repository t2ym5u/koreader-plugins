local _ = require("gettext")
return {
    version     = "1.5.3",
    fullname    = _("Gomoku"),
    description = _("Gomoku — 5 in a row on a 15×15 board."),
}
