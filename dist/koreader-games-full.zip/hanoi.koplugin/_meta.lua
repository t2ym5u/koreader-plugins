local _ = require("gettext")
return {
    fullname    = _("Towers of Hanoi"),
    description = _("Move disks between pegs"),
    version     = "1.2.0",
}
