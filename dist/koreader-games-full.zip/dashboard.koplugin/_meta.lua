local _ = require("gettext")

return {
    fullname    = _("Dashboard"),
    description = _("Tableau de bord : livre en cours, derniers jeux, statistiques."),
    version     = "1.2.12",
}
