local _ = require("gettext")

return {
    fullname    = _("Dashboard"),
    description = _("Dashboard: current book, recent games, stats."),
    version     = "1.2.15",
}
