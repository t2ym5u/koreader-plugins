local _ = require("gettext")

return {
    fullname = _([[Sudoku]]),
    description = _([[Play touch-friendly Sudoku puzzles, resume later, and reveal the solution when needed.]]),
    version = "2.2.11",
}
