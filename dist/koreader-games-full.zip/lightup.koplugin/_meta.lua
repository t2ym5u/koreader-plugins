local _ = require("gettext")

return {
    fullname    = _("Light Up"),
    description = _("Akari: place light bulbs to illuminate every white cell without conflicts."),
    version     = "1.1.19",
}
