return {
    ["Lit: %1/%2  Bulbs: %3  Tap=cycle  Hold=dot"] = { fr = "Éclairées : %1/%2  Ampoules : %3  App.=cycle  Maintien=point", es = "Iluminadas: %1/%2  Bombillas: %3  Tocar=ciclo  Mantener=punto", de = "Beleuchtet: %1/%2  Glühbirnen: %3  Tippen=Zyklus  Halten=Punkt" },
    ["All cells illuminated! Puzzle solved!"] = { fr = "Toutes les cases illuminées ! Puzzle résolu !", es = "¡Todas las casillas iluminadas! ¡Puzle resuelto!", de = "Alle Felder beleuchtet! Rätsel gelöst!" },
    ["Akari: place light bulbs to illuminate every white cell without conflicts."] = { fr = "Akari : placez des ampoules pour illuminer toutes les cases blanches sans conflit.", es = "Akari: coloca bombillas para iluminar todas las casillas blancas sin conflictos.", de = "Akari: Platziere Glühbirnen, um alle weißen Felder ohne Konflikte zu beleuchten." },
    ["Light Up"] = { fr = "Light Up", es = "Light Up", de = "Light Up" },
}
