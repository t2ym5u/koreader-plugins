local _ = require("gettext")

return {
    fullname    = _("Boggle Party"),
    description = _("Display a Boggle grid for table play — everyone plays on paper, then reveal solutions."),
    version     = "1.1.11",
}
