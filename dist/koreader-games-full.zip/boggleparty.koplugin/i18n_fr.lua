return {
    ["Solutions"]   = { fr = "Solutions", es = "Soluciones", de = "Lösungen" },
    ["Duration"]            = { fr = "Durée", es = "Duración", de = "Dauer" },
    ["Boggle Party"]        = { fr = "Boggle Party", es = "Boggle Party", de = "Boggle Party" },
    ["Display a Boggle grid for table play — everyone plays on paper, then reveal solutions."] = { fr = "Affichez une grille de Boggle pour jouer à table — chacun joue sur papier, puis révélez les solutions.", es = "Muestra una cuadrícula de Boggle para jugar en mesa — todos juegan en papel, luego revela las soluciones.", de = "Zeige ein Boggle-Gitter für das Spiel am Tisch — alle spielen auf Papier, dann die Lösungen aufdecken." },
}
