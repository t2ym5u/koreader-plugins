local _ = require("gettext")
return {
    fullname    = _("Anagram"),
    description = _("Rearrange letters to find words"),
    version     = "1.3.8",
}
