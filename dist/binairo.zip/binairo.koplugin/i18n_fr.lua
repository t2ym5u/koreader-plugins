return {
    ["Binairo"]                              = { fr = "Binairo", es = "Binairo", de = "Binairo" },
    ["Empty: %1"]                            = { fr = "Vides : %1", es = "Vacíos: %1", de = "Leer: %1" },
    ["Solved! Time: %1"]                     = { fr = "Résolu ! Temps : %1", es = "¡Resuelto! Tiempo: %1", de = "Gelöst! Zeit: %1" },
    ["%1 error(s) highlighted."]             = { fr = "%1 erreur(s) mise(s) en évidence.", es = "%1 error(es) resaltado(s).", de = "%1 Fehler hervorgehoben." },
    ["Binary grid puzzle — fill each row and column with equal 0s and 1s, no three in a row."] = { fr = "Puzzle de grille binaire — remplissez chaque ligne et colonne avec un nombre égal de 0 et de 1, sans trois identiques d'affilée.", es = "Puzzle de cuadrícula binaria — rellena cada fila y columna con la misma cantidad de 0 y 1, sin tres iguales seguidos.", de = "Binäres Gitterrätsel — fülle jede Zeile und Spalte mit gleich vielen 0en und 1en, keine drei in Folge." },
}
