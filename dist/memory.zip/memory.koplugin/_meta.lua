local _ = require("gettext")
return {
    fullname    = _("Memory"),
    description = _("Memory game — find matching card pairs."),
    version     = "1.1.13",
}
