return {
    ["%1\xC3\x97%2 \xC2\xB7 %3 \xC2\xB7 Empty: %4%5%6"] = { fr = "%1×%2 · %3 · Vides : %4%5%6", es = "%1×%2 · %3 · Vacías: %4%5%6", de = "%1×%2 · %3 · Leer: %4%5%6" },
    [" \xC2\xB7 Note ON"]              = { fr = " · Notes ON", es = " · Notas ON", de = " · Notizen ON" },
    ["Fill the grid with digits satisfying row, column and cage arithmetic constraints."] = { fr = "Remplissez la grille de chiffres respectant les contraintes arithmétiques de ligne, de colonne et de cage.", es = "Rellena la cuadrícula con cifras que cumplan las restricciones aritméticas de fila, columna y jaula.", de = "Fülle das Raster mit Ziffern, die die arithmetischen Bedingungen von Zeile, Spalte und Käfig erfüllen." },
    ["KenKen"]                         = { fr = "KenKen", es = "KenKen", de = "KenKen" },
}
