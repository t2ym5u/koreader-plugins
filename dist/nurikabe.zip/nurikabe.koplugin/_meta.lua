local _ = require("gettext")
return {
    fullname    = _("Nurikabe"),
    description = _("Paint the river: connect islands of numbered white cells."),
    version     = "1.1.14",
}
