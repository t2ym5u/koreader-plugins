local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"
package.path = _dir .. "?.lua;" .. _dir .. "common/?.lua;" .. package.path

local function lrequire(name)
    local key = _dir .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. name .. ".lua"))()
    end
    return package.loaded[key]
end

-- Shared modules (common/) are cached by name for every plugin at once: the
-- guard makes sure an outdated copy, loaded by an old plugin still installed,
-- is not the one this plugin gets (see common/module_guard.lua). Loaded by
-- path, so no other plugin's copy can stand in for it.
local function noop() end
local guard_chunk = loadfile(_dir .. "common/module_guard.lua")
local guard = guard_chunk and guard_chunk()(_dir .. "common/", "game_common_version.lua")
    or { enter = noop, leave = noop }
guard.enter()

-- The game screen -- and the boards, word lists and puzzle banks it pulls
-- in -- loads the first time the game is opened, not when KOReader starts:
-- KOReader loads every plugin at startup and keeps it all session, so a
-- top-level require here costs memory even if the game is never played.
-- KOReader has put package.path back by then, so our directories are added
-- again while the module loads (common/ stays as a fallback for the shared
-- modules the game requires later on).
local function lazyrequire(name)
    local saved = package.path
    package.path = _dir .. "?.lua;" .. _dir .. "common/?.lua;" .. saved
    guard.enter()
    local ok, mod = pcall(lrequire, name)
    guard.leave()
    package.path = saved
    if not package.path:find(_dir .. "common/?.lua", 1, true) then
        package.path = package.path .. ";" .. _dir .. "common/?.lua"
    end
    if not ok then error(mod, 0) end
    return mod
end

local PluginBase = require("plugin_base")
local _          = require("i18n")

require("i18n").extend(lrequire("i18n_fr"))

local ChessPuzzles = PluginBase:extend{
    name      = "chesspuzzles",
    menu_text = _("Chess Puzzles"),
    menu_hint = "tools",
    party_mode = true,
}

function ChessPuzzles:createScreen()
    return lazyrequire("screen"):new{ plugin = self }
end

-- Another plugin's settings (settings/<id>.lua), or nil when the file does
-- not exist. Only read, never modified: the lessons start where Chess Course,
-- now part of this game, was left.
function ChessPuzzles:readOtherSettings(id)
    local ok, lfs = pcall(require, "libs/libkoreader-lfs")
    if not ok then ok, lfs = pcall(require, "lfs") end
    local ok_ds, DataStorage = pcall(require, "datastorage")
    if not ok or not ok_ds then return nil end
    local path = DataStorage:getSettingsDir() .. "/" .. id .. ".lua"
    if lfs.attributes(path, "mode") ~= "file" then return nil end
    local LuaSettings = require("luasettings")
    local ok2, s = pcall(LuaSettings.open, LuaSettings, path)
    return ok2 and s and s.data or nil
end

guard.leave()

return ChessPuzzles
