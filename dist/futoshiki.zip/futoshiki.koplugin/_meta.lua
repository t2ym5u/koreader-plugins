local _ = require("gettext")
return {
    fullname    = _("Futoshiki"),
    description = _("Fill the grid with digits satisfying row, column and inequality constraints."),
    version     = "1.1.11",
}
