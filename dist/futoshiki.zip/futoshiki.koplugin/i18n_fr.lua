return {
    [" · Note ON"]                     = { fr = " · Notes ON", es = " · Notas ON", de = " · Notizen ON" },
    ["%1×%2 · %3 · Empty: %4%5"]       = { fr = "%1×%2 · %3 · Vides : %4%5", es = "%1×%2 · %3 · Vacías: %4%5", de = "%1×%2 · %3 · Leer: %4%5" },
    ["Fill the grid with digits satisfying row, column and inequality constraints."] = { fr = "Remplissez la grille avec des chiffres respectant les contraintes de ligne, de colonne et d'inégalité.", es = "Rellena la cuadrícula con cifras que cumplan las restricciones de fila, columna y desigualdad.", de = "Fülle das Raster mit Ziffern, die die Zeilen-, Spalten- und Ungleichheitsbedingungen erfüllen." },
    ["Futoshiki"]                      = { fr = "Futoshiki", es = "Futoshiki", de = "Futoshiki" },
}
