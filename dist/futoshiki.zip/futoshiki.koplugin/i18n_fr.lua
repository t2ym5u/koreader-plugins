return {
    [" · Note ON"]                     = { fr = " · Notes ON" },
    ["%1×%2 · %3 · Empty: %4%5"]       = { fr = "%1×%2 · %3 · Vides : %4%5" },
    ["Fill the grid with digits satisfying row, column and inequality constraints."] = { fr = "Remplissez la grille avec des chiffres respectant les contraintes de ligne, de colonne et d'inégalité." },
    ["Futoshiki"]                      = { fr = "Futoshiki" },
}
