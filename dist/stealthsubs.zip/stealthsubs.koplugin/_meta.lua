local _ = require("gettext")
return {
    fullname    = _("Silent Subs"),
    description = _("Two readers, two hidden submarines: announce your moves, track the enemy's, and torpedo it first."),
    version     = "1.0.0",
}
