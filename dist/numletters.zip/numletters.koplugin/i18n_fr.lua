return {
    ["Numbers and Letters"] = { fr = "Chiffres et Lettres" },
}
