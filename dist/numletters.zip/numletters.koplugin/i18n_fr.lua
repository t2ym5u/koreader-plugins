return {
    ["Numbers and Letters"] = { fr = "Chiffres et Lettres", es = "Números y Letras", de = "Zahlen und Buchstaben" },
}
