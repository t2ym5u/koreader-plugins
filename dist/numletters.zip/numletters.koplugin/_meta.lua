local _ = require("gettext")
return {
    fullname    = _("Numbers and Letters"),
    description = _("Draw letters and find the longest word; draw numbers and hit the target."),
    version     = "1.1.13",
}
