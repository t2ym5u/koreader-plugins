local _ = require("gettext")

return {
    version     = "1.5.0",
    fullname    = _("Word Ladder"),
    description = _("Change one word into another, one letter at a time."),
}
