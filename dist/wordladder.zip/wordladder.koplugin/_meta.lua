local _ = require("gettext")

return {
    version     = "1.1.3",
    fullname    = _("Word Ladder"),
    description = _("Change one word into another, one letter at a time."),
}
