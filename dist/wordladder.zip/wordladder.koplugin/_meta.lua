local _ = require("gettext")

return {
    version     = "1.4.1",
    fullname    = _("Word Ladder"),
    description = _("Change one word into another, one letter at a time."),
}
