local _ = require("gettext")
return {
    fullname    = _("The Defuser"),
    description = _("Two readers: the operator has an alarm machine, the expert its manual. Talk it through and stop every module."),
    version     = "1.0.0",
}
