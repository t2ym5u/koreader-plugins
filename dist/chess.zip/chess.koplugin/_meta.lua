local _ = require("gettext")
return {
    version     = "1.4.6",
    fullname    = _("Chess"),
    description = _("Chess game with AI"),
}
