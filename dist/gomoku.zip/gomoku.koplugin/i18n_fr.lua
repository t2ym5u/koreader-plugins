return {
    -- "Gomoku" is a proper noun, identical in French and English, and the
    -- other listed strings ("Annuler", "Match nul !", "Nouveau") are already
    -- French literals used directly as the _() argument, so no entries are
    -- needed here yet.
}
