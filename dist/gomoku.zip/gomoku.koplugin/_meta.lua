return {
    name        = "gomoku",
    version     = "1.1.8",
    fullname    = "Gomoku",
    description = "Gomoku — 5 pions en ligne sur 15\xC3\xB715.",
}
