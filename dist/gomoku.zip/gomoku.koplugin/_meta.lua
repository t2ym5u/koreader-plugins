return {
    version     = "1.1.11",
    fullname    = "Gomoku",
    description = "Gomoku — 5 pions en ligne sur 15×15.",
}
