local _ = require("gettext")
return {
    fullname    = _("Slitherlink"),
    description = _("Draw a single closed loop along grid edges matching the numbered clues."),
    version     = "1.5.1",
}
