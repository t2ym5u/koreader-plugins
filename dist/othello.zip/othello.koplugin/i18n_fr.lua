return {
    ["Othello"] = { fr = "Othello" },
}
