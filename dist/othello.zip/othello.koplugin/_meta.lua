local _ = require("gettext")
return {
    version     = "1.5.2",
    fullname    = _("Othello"),
    description = _("Othello/Reversi 8x8 with AI."),
}
