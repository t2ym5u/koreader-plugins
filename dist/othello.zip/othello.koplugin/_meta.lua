return {
    name        = "othello",
    version     = "1.1.6",
    fullname    = "Othello",
    description = "Othello/Reversi 8x8 avec IA.",
}
