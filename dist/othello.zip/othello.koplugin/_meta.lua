local _ = require("gettext")
return {
    version     = "1.1.13",
    fullname    = _("Othello"),
    description = _("Othello/Reversi 8x8 with AI."),
}
