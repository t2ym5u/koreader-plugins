return {
    version     = "1.1.9",
    fullname    = "Othello",
    description = "Othello/Reversi 8x8 avec IA.",
}
