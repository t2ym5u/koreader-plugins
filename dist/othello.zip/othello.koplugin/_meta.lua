return {
    version     = "1.1.11",
    fullname    = "Othello",
    description = "Othello/Reversi 8x8 avec IA.",
}
