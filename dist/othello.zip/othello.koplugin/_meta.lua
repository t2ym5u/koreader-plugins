return {
    version     = "1.1.10",
    fullname    = "Othello",
    description = "Othello/Reversi 8x8 avec IA.",
}
