local _ = require("gettext")

return {
    version     = "1.1.7",
    fullname    = _("Tsumego"),
    description = _("Go life-and-death problems: kill or live in the corner, with proven answers."),
}
