local _ = require("gettext")

return {
    fullname    = _("Wordle"),
    description = _("Guess the hidden word in 6 tries. Letter hints guide each attempt."),
    version     = "1.4.0",
}
