local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"
local function lrequire(name)
    local key = _dir .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. name .. ".lua"))()
    end
    return package.loaded[key]
end

local Blitbuffer = require("ffi/blitbuffer")
local Device     = require("device")
local Font       = require("ui/font")
local Geom       = require("ui/geometry")
local RenderText = require("ui/rendertext")
local Size       = require("ui/size")

local gwb            = lrequire("common/grid_widget_base")
local GridWidgetBase = gwb.GridWidgetBase
local drawLine       = gwb.drawLine

local StarBattleBoard = lrequire("board")

local Screen = Device.screen

local STAR = "\xE2\x98\x85"   -- U+2605 BLACK STAR

-- ---------------------------------------------------------------------------
-- Colours
-- ---------------------------------------------------------------------------

local C_BG         = Blitbuffer.COLOR_WHITE
local C_LINE       = Blitbuffer.COLOR_BLACK
local C_GRID       = Blitbuffer.COLOR_GRAY_9
local C_SELECTED   = Blitbuffer.COLOR_GRAY_D
local C_CONFLICT   = Blitbuffer.COLOR_GRAY
local C_DOT        = Blitbuffer.COLOR_GRAY_4
local C_STAR       = Blitbuffer.COLOR_BLACK

-- ---------------------------------------------------------------------------
-- StarBattleBoardWidget
-- ---------------------------------------------------------------------------

local StarBattleBoardWidget = GridWidgetBase:extend{
    board    = nil,
    selected = nil,  -- {r, c} or nil
}

function StarBattleBoardWidget:init()
    local n   = self.board and self.board.n or 8
    self.cols = n
    self.rows = n
    GridWidgetBase.init(self)
    self:_initStarFace()
end

-- The star glyph is wider than the "8" GridWidgetBase fits its font to, so
-- size its own face: the largest that fits the cell's inner box.
function StarBattleBoardWidget:_initStarFace()
    local pad   = self.number_padding or 2
    local inner = math.max(1, math.floor(math.min(self.cell_w, self.cell_h) - 2 * pad))
    local lo, hi, best = 6, 200, 6
    while lo <= hi do
        local mid = math.floor((lo + hi) / 2)
        local m   = RenderText:sizeUtf8Text(0, Screen:getWidth(), Font:getFace("cfont", mid), STAR, true, false)
        if m.x <= inner and (m.y_top + m.y_bottom) <= inner then
            best, lo = mid, mid + 1
        else
            hi = mid - 1
        end
    end
    self.star_face = Font:getFace("cfont", best)
end

function StarBattleBoardWidget:onCellTap(row, col)
    if self.onCellAction then
        self.onCellAction(row, col)
    end
end

-- ---------------------------------------------------------------------------
-- paintTo
-- ---------------------------------------------------------------------------

function StarBattleBoardWidget:paintTo(bb, x, y)
    if not self.board then return end
    self.paint_rect = Geom:new{ x = x, y = y, w = self.dimen.w, h = self.dimen.h }

    local board = self.board
    local n     = board.n
    local cell  = self.dimen.w / n

    -- Background
    bb:paintRect(x, y, self.dimen.w, self.dimen.h, C_BG)

    local conflicts = board:getConflicts()

    -- Cell backgrounds
    for r = 1, n do
        for c = 1, n do
            local cx = x + math.floor((c - 1) * cell)
            local cy = y + math.floor((r - 1) * cell)
            local cw = math.ceil(cell)
            local ch = math.ceil(cell)
            local bg
            if self.selected and self.selected[1] == r and self.selected[2] == c then
                bg = C_SELECTED
            elseif conflicts[r][c] then
                bg = C_CONFLICT
            end
            if bg then bb:paintRect(cx, cy, cw, ch, bg) end
        end
    end

    -- Grid lines (thin)
    local thin  = Size.line.thin  or 1
    local thick = math.max(2, math.floor(cell * 0.08))

    for i = 0, n do
        local lw = (i == 0 or i == n) and thick or thin
        -- The closing line sits inside the widget: drawn at i * cell it
        -- would spill lw - 1 pixels past the right and bottom edges.
        local off = (i == n) and (self.dimen.w - lw) or math.floor(i * cell)
        drawLine(bb, x + off, y, lw, self.dimen.h, C_LINE)
        drawLine(bb, x, y + off, self.dimen.w, lw, C_LINE)
    end

    -- Thick region borders
    local reg_thick = math.max(3, math.floor(cell * 0.12))
    for r = 1, n do
        for c = 1, n do
            -- Right border: between (r,c) and (r,c+1)
            if c < n and board.region_id[r][c] ~= board.region_id[r][c + 1] then
                local bx = x + math.floor(c * cell) - math.floor(reg_thick / 2)
                local by = y + math.floor((r - 1) * cell)
                drawLine(bb, bx, by, reg_thick, math.ceil(cell), C_LINE)
            end
            -- Bottom border: between (r,c) and (r+1,c)
            if r < n and board.region_id[r][c] ~= board.region_id[r + 1][c] then
                local bx = x + math.floor((c - 1) * cell)
                local by = y + math.floor(r * cell) - math.floor(reg_thick / 2)
                drawLine(bb, bx, by, math.ceil(cell), reg_thick, C_LINE)
            end
        end
    end

    -- Cell content
    local pad   = self.number_padding or 2
    local inner = math.max(1, math.floor(cell - 2 * pad))
    local star_face = self.star_face

    for r = 1, n do
        for c = 1, n do
            local cx = x + math.floor((c - 1) * cell)
            local cy = y + math.floor((r - 1) * cell)
            local mark = board.marks[r][c]

            if mark == StarBattleBoard.MARK_STAR then
                -- Centre the star's ink on the cell centre. (An "*" used to
                -- stand in for it: a small glyph that sat near the top.)
                local m    = RenderText:sizeUtf8Text(0, Screen:getWidth(), star_face, STAR, true, false)
                local bx   = cx + pad + math.floor((inner - m.x) / 2)
                local by   = cy + pad + math.floor((inner + m.y_top - m.y_bottom) / 2)
                RenderText:renderUtf8Text(bb, bx, by, star_face, STAR, true, false, C_STAR)
            elseif mark == StarBattleBoard.MARK_DOT then
                -- A painted disc: the "." glyph was a few pixels wide.
                bb:paintCircle(cx + math.floor(cell / 2), cy + math.floor(cell / 2),
                    math.max(2, math.floor(cell * 0.09)), C_DOT)
            end
        end
    end
end

return StarBattleBoardWidget
