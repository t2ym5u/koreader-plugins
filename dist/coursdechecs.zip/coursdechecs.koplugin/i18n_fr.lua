return {
    ["Solution"]    = { fr = "Solution" },
}
