local _ = require("gettext")
return {
    fullname    = _("Galaxies"),
    description = _("Divide the grid into rotationally symmetric galaxies"),
    version     = "1.5.0",
}
