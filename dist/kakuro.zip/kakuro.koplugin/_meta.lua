local _ = require("gettext")
return {
    fullname    = _("Kakuro"),
    description = _("Fill white cells with digits 1–9 so each run sums to its clue."),
    version     = "1.1.9",
}
