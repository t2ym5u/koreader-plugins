local _ = require("gettext")
return {
    version     = "1.0.7",
    fullname    = _("Awalé"),
    description = _("Awalé (Oware) — sow and capture seeds, against the AI or a friend."),
}
