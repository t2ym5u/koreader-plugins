local _ = require("gettext")

return {
    fullname    = _("Boggle"),
    description = _("Find words by connecting adjacent letters on the grid."),
    version     = "1.1.17",
}
