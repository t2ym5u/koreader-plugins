return {
    ["Not a word: %1"]                    = { fr = "Pas un mot : %1", es = "No es una palabra: %1", de = "Kein Wort: %1" },
    ["Word too short (min 3 letters)"]    = { fr = "Mot trop court (minimum 3 lettres)", es = "Palabra demasiado corta (mínimo 3 letras)", de = "Wort zu kurz (mind. 3 Buchstaben)" },
    ["Found: %1 (+%2 pts)"]               = { fr = "Trouvé : %1 (+%2 pts)", es = "Encontrado: %1 (+%2 pts)", de = "Gefunden: %1 (+%2 Pkt.)" },
    ["No words found yet."]               = { fr = "Aucun mot trouvé pour l'instant.", es = "Aún no se ha encontrado ninguna palabra.", de = "Noch keine Wörter gefunden." },
    ["Already found: %1"]                 = { fr = "Déjà trouvé : %1", es = "Ya encontrado: %1", de = "Bereits gefunden: %1" },
    ["Missed: %1"]                        = { fr = "Manqué : %1", es = "Fallado: %1", de = "Verpasst: %1" },
    ["Word: %1  Score: %2  Found: %3"]    = { fr = "Mot : %1  Score : %2  Trouvé : %3", es = "Palabra: %1  Puntuación: %2  Encontrado: %3", de = "Wort: %1  Punkte: %2  Gefunden: %3" },
    ["Score: %1  Found: %2/%3"]           = { fr = "Score : %1  Trouvé : %2/%3", es = "Puntuación: %1  Encontrado: %2/%3", de = "Punkte: %1  Gefunden: %2/%3" },
    ["Game over! Score: %1  Words: %2/%3"] = { fr = "Partie terminée ! Score : %1  Mots : %2/%3", es = "¡Fin de la partida! Puntuación: %1  Palabras: %2/%3", de = "Spiel vorbei! Punkte: %1  Wörter: %2/%3" },
    ["Boggle"]                             = { fr = "Boggle", es = "Boggle", de = "Boggle" },
    ["Find words by connecting adjacent letters on the grid."] = { fr = "Trouvez des mots en reliant des lettres adjacentes sur la grille.", es = "Encuentra palabras conectando letras adyacentes en la cuadrícula.", de = "Finde Wörter, indem du benachbarte Buchstaben im Gitter verbindest." },
}
