local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"
local function lrequire(name)
    local key = _dir .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. name .. ".lua"))()
    end
    return package.loaded[key]
end

local FrameContainer  = require("ui/widget/container/framecontainer")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local Size            = require("ui/size")
local UIManager       = require("ui/uimanager")
local VerticalGroup   = require("ui/widget/verticalgroup")
local VerticalSpan    = require("ui/widget/verticalspan")
local _               = require("i18n")
local T               = require("ffi/util").template

local ScreenBase          = require("screen_base")
local MenuHelper          = require("menu_helper")
local MinesweeperBoard    = lrequire("board")
local MinesweeperBoardWidget = lrequire("board_widget")


-- ---------------------------------------------------------------------------
-- MinesweeperScreen
-- ---------------------------------------------------------------------------

local GAME_RULES_EN = _([[
Minesweeper — Rules

Uncover all safe cells without detonating a mine.

Each uncovered cell shows the count of mines among its up-to-8 neighbouring cells.
A cell showing 0 is safe and automatically expands to reveal its neighbours.
Tap a cell to uncover it. Long-press a cell (or tap it with Flag mode on) to flag a suspected mine; do it again to remove the flag.
Tap an uncovered number that has as many flags around it as its value to uncover its other neighbours at once.
The first tap is always safe — mines are placed after it.
No guessing is ever needed: from the first tap, the numbers and the mine counter are always enough to find the next safe cell or mine.

Win by uncovering every non-mine cell.
]])

local GAME_RULES_FR = [[
Démineur — Règles

Découvrez toutes les cases sûres sans faire exploser une mine.

Chaque case découverte affiche le nombre de mines parmi ses 8 cases voisines.
Une case affichant 0 est sûre et révèle automatiquement ses voisines.
Appuyez sur une case pour la découvrir. Appui long sur une case (ou appui en mode Drapeau) pour marquer une mine suspectée ; recommencez pour retirer le drapeau.
Appuyez sur un chiffre découvert entouré d'autant de drapeaux que sa valeur pour découvrir d'un coup ses autres voisines.
Le premier appui est toujours sûr — les mines sont placées après.
Vous n'avez jamais besoin de deviner : dès le premier appui, les chiffres et le compteur de mines suffisent toujours à trouver la prochaine case sûre ou la prochaine mine.

Gagnez en découvrant toutes les cases sans mine.
]]

local MinesweeperScreen = ScreenBase:extend{}

-- ---------------------------------------------------------------------------
-- Lifecycle
-- ---------------------------------------------------------------------------

function MinesweeperScreen:init()
    local state  = self.plugin:loadState()
    self.board   = MinesweeperBoard:new{ preset = self.plugin:getSetting("preset", "beginner") }
    if not self.board:load(state) then
        -- default board already ready from :new
    end
    self.flag_mode = false
    ScreenBase.init(self)
end

function MinesweeperScreen:serializeState()
    return self.board:serialize()
end

-- ---------------------------------------------------------------------------
-- Layout
-- ---------------------------------------------------------------------------

function MinesweeperScreen:buildLayout()
    local is_landscape = self:isLandscape()

    -- Title bar (full width, pinned to top)
    local title_bar = self:buildTitleBar(_("Minesweeper"), function()
        return {
            { text = _("New game"), callback = function() self:onNewGame() end },
            { text = T(_("Difficulty: %1"), self:getPresetLabel()),
              callback = function() self:openPresetMenu() end },
            self:makeRulesButtonConfig(GAME_RULES_EN, GAME_RULES_FR),
        }
    end)

    -- Footer: game-specific actions
    self.status_text:setMaxWidth(self:getControlsWidth())
    local action_bar = self:buildActionBar({
        { id = "flag_button", text = self:getFlagButtonText(),
          callback = function() self:toggleFlagMode() end },
        { text = _("Check"), callback = function() self:onCheck() end },
        { text = _("Hint"), callback = function() self:onHint() end },
    })
    self.flag_button = action_bar:getButtonById("flag_button")
    local controls = VerticalGroup:new{
        align = "center",
        self.status_text,
        VerticalSpan:new{ width = Size.span.vertical_large },
        action_bar,
    }

    -- The widget draws its own thick outer border, so the frame only pads.
    local frame_pad = Size.padding.large
    local budget_w, budget_h = self:getBoardBudget(title_bar, controls)
    self.board_widget = MinesweeperBoardWidget:new{
        board            = self.board,
        max_width        = math.max(budget_w - 2 * frame_pad, 80),
        max_height       = math.max(budget_h - 2 * frame_pad, 80),
        cellTapCallback  = function(r, c) self:onCellTap(r, c) end,
        cellHoldCallback = function(r, c) self:onCellHold(r, c) end,
    }
    local board_frame = FrameContainer:new{
        padding    = frame_pad,
        margin     = 0,
        bordersize = 0,
        self.board_widget,
    }

    if is_landscape then
        local content = HorizontalGroup:new{
            align = "center",
            board_frame,
            HorizontalSpan:new{ width = self:getGutter() },
            controls,
        }
        self:buildLandscapeLayout(title_bar, content)
    else
        self:buildPortraitLayout(title_bar, board_frame,
            VerticalGroup:new{ align = "center", controls, VerticalSpan:new{ width = self:getGutter() } })
    end
    self:updateStatus()
end

-- ---------------------------------------------------------------------------
-- Cell interaction
-- ---------------------------------------------------------------------------

function MinesweeperScreen:onCellTap(r, c)
    if self.flag_mode then
        self:_doFlag(r, c)
    else
        self:_doReveal(r, c)
    end
end

function MinesweeperScreen:onCellHold(r, c)
    self:_doFlag(r, c)
end

function MinesweeperScreen:_doReveal(r, c)
    local st = self.board.state[r][c]
    local res
    if st == MinesweeperBoard.STATE_REVEALED then
        res = self.board:chord(r, c)
    else
        res = self.board:reveal(r, c)
    end
    if res == "mine" then
        self.board:revealAllMines()
        self.board_widget:refresh()
        self:updateStatus(_("BOOM! Game over."))
    elseif res == "win" then
        self.board_widget:refresh()
        self:updateStatus(_("Congratulations! You cleared the board!"))
    else
        self.board_widget:refresh()
        self:updateStatus()
    end
    self:refreshActionBar()
    self.plugin:saveState(self.board:serialize())
end

function MinesweeperScreen:_doFlag(r, c)
    self.board:toggleFlag(r, c)
    self.board_widget:refresh()
    self:updateStatus()
    self.plugin:saveState(self.board:serialize())
end

-- ---------------------------------------------------------------------------
-- Game actions
-- ---------------------------------------------------------------------------

function MinesweeperScreen:onNewGame()
    local preset = self.plugin:getSetting("preset", "beginner")
    self.board   = MinesweeperBoard:new{ preset = preset }
    self.flag_mode = false
    self.plugin:saveState(self.board:serialize())
    self:buildLayout()
    UIManager:setDirty(self, function() return "ui", self.dimen end)
end

function MinesweeperScreen:isRoundOver()
    return (self.board.win or self.board.game_over) and true or false
end

-- A second Hint tap reveals a cell, which can be the last safe one.
function MinesweeperScreen:onHint()
    ScreenBase.onHint(self)
    self:refreshActionBar()
end

function MinesweeperScreen:onCheck()
    if self.board.game_over then
        self:updateStatus(_("Game over."))
    elseif self.board.win then
        self:updateStatus(_("Congratulations! You cleared the board!"))
    else
        local remaining = 0
        local rows, cols = self.board.rows, self.board.cols
        for r = 1, rows do
            for c = 1, cols do
                if not self.board.mines[r][c]
                        and self.board.state[r][c] ~= MinesweeperBoard.STATE_REVEALED then
                    remaining = remaining + 1
                end
            end
        end
        self:updateStatus(T(_("Safe cells remaining: %1"), remaining))
    end
end

function MinesweeperScreen:toggleFlagMode()
    self.flag_mode = not self.flag_mode
    if self.flag_button then
        self.flag_button:setText(self:getFlagButtonText(), self.flag_button.width)
    end
    self:updateStatus()
end

-- ---------------------------------------------------------------------------
-- Preset menu
-- ---------------------------------------------------------------------------

function MinesweeperScreen:openPresetMenu()
    local presets = {}
    for _, id in ipairs(MinesweeperBoard.PRESET_ORDER) do
        local cfg = MinesweeperBoard.PRESETS[id]
        presets[#presets + 1] = {
            id   = id,
            text = string.format("%s (%d\xC3\x97%d, %d)",
                self:getPresetLabel(id), cfg.cols, cfg.rows, cfg.mines),
        }
    end
    MenuHelper.openSizeMenu{
        title     = _("Difficulty"),
        sizes     = presets,
        current   = self.plugin:getSetting("preset", "beginner"),
        parent    = self,
        on_select = function(id)
            self.plugin:saveSetting("preset", id)
            self:onNewGame()
        end,
    }
end

-- ---------------------------------------------------------------------------
-- Status bar
-- ---------------------------------------------------------------------------

function MinesweeperScreen:updateStatus(msg)
    local status
    if msg then
        status = msg
    elseif self.board.game_over then
        status = _("BOOM! Game over.")
    elseif self.board.win then
        status = _("Congratulations! You cleared the board!")
    else
        -- Flag mode is shown on its own button, so it isn't repeated here.
        local b = self.board
        status = self:joinStatus(T("%1\xC3\x97%2", b.cols, b.rows),
            self:getPresetLabel(),
            T(_("Mines: %1"), b:getRemainingMines()),
            T(_("Time: %1"), b.timer:format()))
    end
    ScreenBase.updateStatus(self, status)
end

-- ---------------------------------------------------------------------------
-- Button text helpers
-- ---------------------------------------------------------------------------

local PRESET_LABELS = {
    beginner     = _("Beginner"),
    intermediate = _("Intermediate"),
    expert       = _("Expert"),
}

function MinesweeperScreen:getPresetLabel(preset)
    preset = preset or self.plugin:getSetting("preset", "beginner")
    return PRESET_LABELS[preset] or (preset:sub(1,1):upper() .. preset:sub(2))
end

function MinesweeperScreen:getFlagButtonText()
    return self.flag_mode and _("Flag: ON") or _("Flag: OFF")
end

return MinesweeperScreen
