local _dir = debug.getinfo(1, "S").source:sub(2):match("(.*[/\\])") or "./"
package.path = _dir .. "?.lua;" .. _dir .. "common/?.lua;" .. package.path

local function lrequire(name)
    local key = _dir .. name
    if not package.loaded[key] then
        package.loaded[key] = assert(loadfile(_dir .. name .. ".lua"))()
    end
    return package.loaded[key]
end

local PluginBase = require("plugin_base")
local _          = require("gettext")

require("i18n").extend(lrequire("i18n_fr"))

local TapaScreen = lrequire("screen")

local TapaPlugin = PluginBase:extend{
    name      = "tapa",
    menu_text = _("Tapa"),
    menu_hint = "tools",
}

function TapaPlugin:createScreen()
    return TapaScreen:new{ plugin = self }
end

return TapaPlugin
