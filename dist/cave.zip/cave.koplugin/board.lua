-- Cave puzzle board
-- Rules:
--   1. Shaded cells form a connected group touching the border.
--   2. Unshaded cells (the cave interior) are all orthogonally connected.
--   3. No 2x2 area is fully shaded.
--   4. Clue numbers = how many cells visible from that cell in 4 directions (incl. self).

local grid_utils = require("grid_utils")
local Hint      = require("hint")

local SIZES = { 6, 7, 8 }

local DIRS = { {0,1},{0,-1},{1,0},{-1,0} }

local CaveBoard = {}
CaveBoard.__index = CaveBoard

-- ---------------------------------------------------------------------------
-- Constructor
-- ---------------------------------------------------------------------------

function CaveBoard:new(opts)
    opts = opts or {}
    local n = opts.n or 6
    local obj = {
        n          = n,
        difficulty = opts.difficulty or "medium",
        solution   = {},   -- solution[r][c] = true if shaded
        clues      = {},   -- clues[r][c] = number or nil
        user       = {},   -- user[r][c]: 0=unknown, 1=shaded, 2=unshaded
    }
    for r = 1, n do
        obj.solution[r] = {}
        obj.clues[r]    = {}
        obj.user[r]     = {}
        for c = 1, n do
            obj.solution[r][c] = false
            obj.clues[r][c]    = nil
            obj.user[r][c]     = 0
        end
    end
    setmetatable(obj, self)
    return obj
end

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------

local function isBorder(r, c, n)
    return r == 1 or r == n or c == 1 or c == n
end

local function bfsCount(grid, n, start_r, start_c, value)
    -- Count cells reachable from (start_r, start_c) where grid[r][c] == value
    if grid[start_r][start_c] ~= value then return 0, {} end
    local visited = {}
    local queue   = { {start_r, start_c} }
    local head    = 1
    local count   = 0
    local cells   = {}
    local function key(r, c) return r * 100 + c end
    visited[key(start_r, start_c)] = true
    while head <= #queue do
        local cell = queue[head]; head = head + 1
        local r, c = cell[1], cell[2]
        count = count + 1
        cells[#cells + 1] = {r, c}
        for _, d in ipairs(DIRS) do
            local nr, nc = r + d[1], c + d[2]
            if nr >= 1 and nr <= n and nc >= 1 and nc <= n then
                local k = key(nr, nc)
                if not visited[k] and grid[nr][nc] == value then
                    visited[k] = true
                    queue[#queue + 1] = {nr, nc}
                end
            end
        end
    end
    return count, cells
end

local function totalShaded(shaded, n)
    local cnt = 0
    for r = 1, n do
        for c = 1, n do
            if shaded[r][c] then cnt = cnt + 1 end
        end
    end
    return cnt
end

local function has2x2Shaded(shaded, n)
    for r = 1, n - 1 do
        for c = 1, n - 1 do
            if shaded[r][c] and shaded[r+1][c] and shaded[r][c+1] and shaded[r+1][c+1] then
                return true
            end
        end
    end
    return false
end

local function allShadedConnected(shaded, n)
    -- Find one shaded cell
    local sr, sc
    for r = 1, n do
        for c = 1, n do
            if shaded[r][c] then sr, sc = r, c; break end
        end
        if sr then break end
    end
    if not sr then return true end  -- no shaded cells

    -- Convert to 0/1 grid for bfsCount
    local g = {}
    for r = 1, n do
        g[r] = {}
        for c = 1, n do g[r][c] = shaded[r][c] and 1 or 0 end
    end
    local cnt = bfsCount(g, n, sr, sc, 1)
    return cnt == totalShaded(shaded, n)
end

local function allUnshadedConnected(shaded, n)
    -- Find one unshaded cell
    local sr, sc
    for r = 1, n do
        for c = 1, n do
            if not shaded[r][c] then sr, sc = r, c; break end
        end
        if sr then break end
    end
    if not sr then return true end

    local g = {}
    local total = 0
    for r = 1, n do
        g[r] = {}
        for c = 1, n do
            g[r][c] = shaded[r][c] and 0 or 1
            if not shaded[r][c] then total = total + 1 end
        end
    end
    local cnt = bfsCount(g, n, sr, sc, 1)
    return cnt == total
end

local function allShadedTouchBorder(shaded, n)
    -- All shaded cells must be reachable from the border's shaded cells
    -- Since shaded is connected, just check one border shaded cell exists
    for r = 1, n do
        for c = 1, n do
            if shaded[r][c] and isBorder(r, c, n) then return true end
        end
    end
    return false
end

-- ---------------------------------------------------------------------------
-- Visibility (clue value)
-- ---------------------------------------------------------------------------

function CaveBoard:computeVisibility(r, c)
    local n = self.n
    local count = 1  -- self
    for _, d in ipairs(DIRS) do
        local nr, nc = r + d[1], c + d[2]
        while nr >= 1 and nr <= n and nc >= 1 and nc <= n and not self.solution[nr][nc] do
            count = count + 1
            nr = nr + d[1]
            nc = nc + d[2]
        end
    end
    return count
end

-- ---------------------------------------------------------------------------
-- Uniqueness counter. checkWin() is a literal full-grid comparison to
-- self.solution -- uniqueness means: given only the revealed visibility
-- clues (all on cells known to be unshaded), is there only one shaded/
-- unshaded assignment satisfying every rule (shaded connected + touches
-- border, unshaded connected, no 2x2 shaded, every clue's visibility
-- count matches)?
--
-- Backtracking with propagation to a fixpoint at every node (each rule
-- below only ever forces what every solution extending the current
-- partial grid must contain, so solutions are counted exactly):
--   - per-clue ray bounds: a ray's length lies between its run of known-
--     clear cells and the next known-shaded cell (or the edge). Against
--     the clue's target, the other three rays' bounds give each ray a
--     tighter [lo, hi]: its first lo cells must be clear, and once lo ==
--     hi the cell right after must be shaded.
--   - 2x2: a block with three shaded cells has its fourth clear.
--   - connectivity, for both colours: cells that can no longer reach the
--     colour's decided cells through (that colour or undecided) cells
--     take the other colour; a decided cell cut off is a contradiction.
-- The search branches on the cell right past a clue's known-clear run
-- (the most constrained choice), else the first undecided cell. Cell
-- state: 0 undecided, 1 shaded, 2 clear. node_budget counts search
-- nodes, so a seed gives the same verdict on every device.
-- 1.5.0: replaces a plain cell-by-cell backtracker that only checked the
-- bounds (seconds at 8x8, minutes on an e-reader).
-- ---------------------------------------------------------------------------

local function countSolutions(clues, n, limit, node_budget)
    local N = n * n
    local state = {}
    for i = 1, N do state[i] = 0 end

    -- Precomputed geometry: neighbours, 2x2 blocks, each clue's four rays.
    local nbrs = {}
    for r = 1, n do for c = 1, n do
        local l = {}
        for _, d in ipairs(DIRS) do
            local nr, nc = r + d[1], c + d[2]
            if nr >= 1 and nr <= n and nc >= 1 and nc <= n then l[#l + 1] = (nr - 1) * n + nc end
        end
        nbrs[(r - 1) * n + c] = l
    end end
    local blocks = {}
    for r = 1, n - 1 do for c = 1, n - 1 do
        local i = (r - 1) * n + c
        blocks[#blocks + 1] = { i, i + 1, i + n, i + n + 1 }
    end end
    local clue_list = {}
    for r = 1, n do for c = 1, n do
        if clues[r][c] then
            local rays = {}
            for k, d in ipairs(DIRS) do
                local ray = {}
                local nr, nc = r + d[1], c + d[2]
                while nr >= 1 and nr <= n and nc >= 1 and nc <= n do
                    ray[#ray + 1] = (nr - 1) * n + nc
                    nr, nc = nr + d[1], nc + d[2]
                end
                rays[k] = ray
            end
            clue_list[#clue_list + 1] = { target = clues[r][c] - 1, rays = rays }
            state[(r - 1) * n + c] = 2
        end
    end end

    local trail, tn = {}, 0
    local changed = false
    -- Returns false on a contradiction.
    local function set(i, v)
        local s = state[i]
        if s == v then return true end
        if s ~= 0 then return false end
        state[i] = v
        tn = tn + 1; trail[tn] = i
        changed = true
        return true
    end
    local function undo(mark)
        while tn > mark do state[trail[tn]] = 0; trail[tn] = nil; tn = tn - 1 end
    end

    local conf, mx = { 0, 0, 0, 0 }, { 0, 0, 0, 0 }
    local function cluesProp()
        for _, cl in ipairs(clue_list) do
            local rays, target = cl.rays, cl.target
            local sum_min, sum_max = 0, 0
            for k = 1, 4 do
                local ray = rays[k]
                local len, j = #ray, 1
                while j <= len and state[ray[j]] == 2 do j = j + 1 end
                local cf = j - 1
                while j <= len and state[ray[j]] ~= 1 do j = j + 1 end
                conf[k], mx[k] = cf, j - 1
                sum_min, sum_max = sum_min + cf, sum_max + j - 1
            end
            if target < sum_min or target > sum_max then return false end
            for k = 1, 4 do
                local lo = target - (sum_max - mx[k])
                local hi = target - (sum_min - conf[k])
                if lo < conf[k] then lo = conf[k] end
                if hi > mx[k] then hi = mx[k] end
                if lo > hi then return false end
                local ray = rays[k]
                for j = conf[k] + 1, lo do
                    if not set(ray[j], 2) then return false end
                end
                if lo == hi and ray[hi + 1] then
                    if not set(ray[hi + 1], 1) then return false end
                end
            end
        end
        return true
    end

    local function blocksProp()
        for _, b in ipairs(blocks) do
            local shaded, free = 0, nil
            for k = 1, 4 do
                local s = state[b[k]]
                if s == 1 then shaded = shaded + 1 elseif s == 0 then free = b[k] end
            end
            if shaded == 4 then return false end
            if shaded == 3 and free then
                if not set(free, 2) then return false end
            end
        end
        return true
    end

    local seen, stamp, queue = {}, 0, {}
    for i = 1, N do seen[i] = 0 end
    local function regionProp(want)
        local start, decided = nil, 0
        for i = 1, N do
            if state[i] == want then
                decided = decided + 1
                if not start then start = i end
            end
        end
        if decided == 0 then return true end
        stamp = stamp + 1
        local qh, qt = 1, 1
        queue[1] = start
        seen[start] = stamp
        local found = 1
        while qh <= qt do
            local i = queue[qh]; qh = qh + 1
            for _, j in ipairs(nbrs[i]) do
                if seen[j] ~= stamp then
                    local v = state[j]
                    if v == want or v == 0 then
                        seen[j] = stamp
                        qt = qt + 1; queue[qt] = j
                        if v == want then found = found + 1 end
                    end
                end
            end
        end
        if found ~= decided then return false end
        local other = 3 - want
        for i = 1, N do
            if state[i] == 0 and seen[i] ~= stamp then
                if not set(i, other) then return false end
            end
        end
        return true
    end

    local function propagate()
        repeat
            changed = false
            if not cluesProp() or not blocksProp()
                or not regionProp(1) or not regionProp(2) then
                return false
            end
        until not changed
        return true
    end

    local function pickCell()
        for _, cl in ipairs(clue_list) do
            for k = 1, 4 do
                local ray = cl.rays[k]
                local j = 1
                while ray[j] and state[ray[j]] == 2 do j = j + 1 end
                if ray[j] and state[ray[j]] == 0 then return ray[j] end
            end
        end
        for i = 1, N do if state[i] == 0 then return i end end
        return nil
    end

    -- A full grid that passed propagate() is connected in both colours,
    -- has no shaded 2x2 and matches every clue; what is left to check is
    -- that some cell is shaded and the shading touches the border.
    local function finalOK()
        for r = 1, n do for c = 1, n do
            if (r == 1 or r == n or c == 1 or c == n) and state[(r - 1) * n + c] == 1 then
                return true
            end
        end end
        return false
    end

    local solutions, nodes, exhausted = 0, 0, false
    local function search()
        nodes = nodes + 1
        if nodes > node_budget then exhausted = true; return end
        if not propagate() then return end
        local i = pickCell()
        if not i then
            if finalOK() then solutions = solutions + 1 end
            return
        end
        for v = 2, 1, -1 do
            local mark = tn
            set(i, v)
            search()
            undo(mark)
            if solutions >= limit or exhausted then return end
        end
    end
    search()
    return solutions, exhausted, nodes
end

local REVEAL_LEVELS = { 1.0, 1.3, 1.6, 100.0 } -- multipliers on the nominal keep_clues ratio (last reveals every unshaded cell)

-- Search nodes allowed per uniqueness check; running out counts as "not
-- unique" and the generator moves on. With propagation a unique clue set
-- is proved in under 200 nodes at every size (measured on 900 puzzles),
-- while a non-unique one can wander for tens of thousands before its
-- second solution turns up, so a small budget only cuts those short.
local NODE_BUDGET = 500

-- ---------------------------------------------------------------------------
-- Generate
-- ---------------------------------------------------------------------------

-- on_progress(fraction), optional: called after every uniqueness check
-- (screen.lua wires it to the shared "Generating puzzle…" bar).
function CaveBoard:generate(difficulty, on_progress)
    self.difficulty = difficulty or self.difficulty
    local checks = 0
    local n = self.n

    local keep_clues
    if self.difficulty == "easy" then
        keep_clues = 0.6
    elseif self.difficulty == "hard" then
        keep_clues = 0.2
    else
        keep_clues = 0.4
    end

    local max_attempts = 50
    local ok = false
    local node_budget = NODE_BUDGET

    local best_solution, best_clues

    for _attempt = 1, max_attempts do
        -- Start with all cells shaded
        local shaded = {}
        for r = 1, n do
            shaded[r] = {}
            for c = 1, n do shaded[r][c] = true end
        end

        -- Excavate interior cells starting from center
        local cr = math.floor(n / 2) + 1
        local cc = math.floor(n / 2) + 1

        -- Decide how many interior cells to unshade
        local interior_n = (n - 2) * (n - 2)
        local target_unshaded = math.floor(interior_n * (0.35 + math.random() * 0.25))
        target_unshaded = math.max(target_unshaded, 2)

        -- BFS excavation from center
        shaded[cr][cc] = false
        local frontier = { {cr, cc} }
        local unshaded_count = 1
        local visited = {}
        local function vkey(r, c) return r * 100 + c end
        visited[vkey(cr, cc)] = true

        local iter_limit = target_unshaded * 10
        local iters = 0
        while unshaded_count < target_unshaded and #frontier > 0 do
            iters = iters + 1
            if iters > iter_limit then break end

            local idx = math.random(#frontier)
            local cell = frontier[idx]
            local r, c = cell[1], cell[2]

            -- Try expanding to a neighbor
            local neighbors = {}
            for _, d in ipairs(DIRS) do
                local nr, nc = r + d[1], c + d[2]
                if nr >= 2 and nr <= n-1 and nc >= 2 and nc <= n-1 then
                    local k = vkey(nr, nc)
                    if not visited[k] and shaded[nr][nc] then
                        neighbors[#neighbors + 1] = {nr, nc}
                    end
                end
            end

            if #neighbors == 0 then
                -- Remove from frontier
                table.remove(frontier, idx)
            else
                local nb = neighbors[math.random(#neighbors)]
                local nr, nc = nb[1], nb[2]
                -- Un-shading a cell can only clear 2x2-shaded violations, never
                -- create one, so no per-step check is needed here — the final
                -- has2x2Shaded(shaded, n) check below (after excavation stops)
                -- is what actually gates acceptance of the whole attempt.
                shaded[nr][nc] = false
                local k = vkey(nr, nc)
                visited[k] = true
                frontier[#frontier + 1] = {nr, nc}
                unshaded_count = unshaded_count + 1
            end
        end

        -- Repair pass: the random-walk excavation above rarely reaches every
        -- interior cell (especially ones near a corner/edge, far from the
        -- center start point), so 2x2-shaded violations against the border
        -- ring are common at this point. Every such violation must include
        -- at least one interior cell (the border ring is only 1 cell thick),
        -- so unshading one interior cell per violating block always resolves
        -- it; a single raster-order pass fixes all of them since unshading
        -- only ever removes violations, never creates new ones.
        for r = 1, n - 1 do
            for c = 1, n - 1 do
                if shaded[r][c] and shaded[r+1][c] and shaded[r][c+1] and shaded[r+1][c+1] then
                    for _, pos in ipairs({{r,c},{r+1,c},{r,c+1},{r+1,c+1}}) do
                        local pr, pc = pos[1], pos[2]
                        if pr >= 2 and pr <= n-1 and pc >= 2 and pc <= n-1 then
                            shaded[pr][pc] = false
                            unshaded_count = unshaded_count + 1
                            break
                        end
                    end
                end
            end
        end

        -- Validate constraints
        if not has2x2Shaded(shaded, n)
            and allUnshadedConnected(shaded, n)
            and allShadedConnected(shaded, n)
            and allShadedTouchBorder(shaded, n)
            and unshaded_count >= 2
        then
            -- Temporarily apply this shape so computeVisibility (which
            -- reads self.solution) reflects it while building candidate
            -- clue sets below.
            for r = 1, n do
                for c = 1, n do
                    self.solution[r][c] = shaded[r][c]
                end
            end

            local clue_candidates = {}
            for r = 1, n do
                for c = 1, n do
                    if not shaded[r][c] then
                        clue_candidates[#clue_candidates + 1] = {r, c}
                    end
                end
            end

            for _, mult in ipairs(REVEAL_LEVELS) do
                if ok then break end
                local keep = math.min(#clue_candidates, math.max(2, math.floor(#clue_candidates * keep_clues * mult)))
                local sub_attempts = keep >= #clue_candidates and 1 or 2
                for _ = 1, sub_attempts do
                    if ok then break end
                    grid_utils.shuffle(clue_candidates)
                    local candidate_clues = {}
                    for r = 1, n do candidate_clues[r] = {} end
                    for i = 1, keep do
                        local r, c = clue_candidates[i][1], clue_candidates[i][2]
                        candidate_clues[r][c] = self:computeVisibility(r, c)
                    end

                    if not best_clues then
                        best_solution, best_clues = shaded, candidate_clues
                    end

                    local solutions, exhausted = countSolutions(candidate_clues, n, 2, node_budget)
                    checks = checks + 1
                    if on_progress then on_progress(checks / (checks + 3)) end
                    if solutions == 1 and not exhausted then
                        for r = 1, n do
                            for c = 1, n do self.clues[r][c] = candidate_clues[r][c] end
                        end
                        ok = true
                    end
                end
            end

            if ok then
                -- Reset user grid
                for r = 1, n do
                    for c = 1, n do self.user[r][c] = 0 end
                end
                break
            end
        end
    end

    if not ok and best_clues then
        for r = 1, n do
            for c = 1, n do
                self.solution[r][c] = best_solution[r][c]
                self.clues[r][c]    = best_clues[r][c]
                self.user[r][c]     = 0
            end
        end
        ok = true
    end

    if not ok then
        -- Fallback: simple ring pattern
        for r = 1, n do
            for c = 1, n do
                self.solution[r][c] = isBorder(r, c, n)
                self.clues[r][c]    = nil
                self.user[r][c]     = 0
            end
        end
        -- Add one clue in the center
        local cr2 = math.ceil(n / 2)
        local cc2 = math.ceil(n / 2)
        self.clues[cr2][cc2] = self:computeVisibility(cr2, cc2)
    end
end

-- ---------------------------------------------------------------------------
-- User interaction
-- ---------------------------------------------------------------------------

function CaveBoard:cycleCell(r, c)
    -- Cannot shade clue cells
    if self.clues[r][c] then return end
    local cur = self.user[r][c]
    if cur == 0 then
        self.user[r][c] = 1
    elseif cur == 1 then
        self.user[r][c] = 2
    else
        self.user[r][c] = 0
    end
end

-- Like cycleCell(), but goes straight to a state. Used by the Hint button.
function CaveBoard:setCellState(r, c, v)
    if self.clues[r][c] then return false end
    self.user[r][c] = v
    return true
end

function CaveBoard:clearUser()
    local n = self.n
    for r = 1, n do
        for c = 1, n do self.user[r][c] = 0 end
    end
end

-- ---------------------------------------------------------------------------
-- Win check
-- ---------------------------------------------------------------------------

function CaveBoard:checkWin()
    local n = self.n
    for r = 1, n do
        for c = 1, n do
            local sol_shaded  = self.solution[r][c]
            local user_shaded = (self.user[r][c] == 1)
            local user_clear  = (self.user[r][c] == 2)
            -- Clue cells are always unshaded
            if self.clues[r][c] then
                if user_shaded then return false end
            else
                if sol_shaded  and not user_shaded then return false end
                if not sol_shaded and user_shaded  then return false end
            end
        end
    end
    return true
end

function CaveBoard:countShaded()
    local n, cnt = self.n, 0
    for r = 1, n do
        for c = 1, n do
            if self.user[r][c] == 1 then cnt = cnt + 1 end
        end
    end
    return cnt
end

-- ---------------------------------------------------------------------------
-- Serialize / load
-- ---------------------------------------------------------------------------

-- Marking a cell "definitely clear" is optional (checkWin only looks at
-- shading), so the solution reports non-shaded cells as empty and equals()
-- compares shaded-ness.
Hint.install(CaveBoard, {
    getUser     = function(b, r, c) return b.user[r][c] end,
    getSolution = function(b, r, c) return b.solution[r][c] and 1 or 0 end,
    isEmpty     = function(v) return v == 0 end,
    equals      = function(u, s) return (u == 1) == (s == 1) end,
    isGiven     = function(b, r, c) return b.clues[r][c] == true end,
    setCell     = function(b, r, c, v) return b:setCellState(r, c, v) end,
    blank       = 0,
})

function CaveBoard:serialize()
    local n = self.n
    local sol, usr, clues = {}, {}, {}
    for r = 1, n do
        sol[r]   = {}
        usr[r]   = {}
        clues[r] = {}
        for c = 1, n do
            sol[r][c]   = self.solution[r][c]
            usr[r][c]   = self.user[r][c]
            clues[r][c] = self.clues[r][c]
        end
    end
    return { n = n, difficulty = self.difficulty, solution = sol, user = usr, clues = clues }
end

function CaveBoard:load(data)
    if not data or not data.solution or not data.user or not data.n then return false end
    local n = data.n
    if n ~= 6 and n ~= 7 and n ~= 8 then return false end
    self.n          = n
    self.difficulty = data.difficulty or "medium"
    self.solution   = {}
    self.user       = {}
    self.clues      = {}
    for r = 1, n do
        self.solution[r] = {}
        self.user[r]     = {}
        self.clues[r]    = {}
        for c = 1, n do
            self.solution[r][c] = data.solution[r] and data.solution[r][c] or false
            self.user[r][c]     = data.user[r] and data.user[r][c] or 0
            self.clues[r][c]    = data.clues and data.clues[r] and data.clues[r][c] or nil
        end
    end
    return true
end

return {
    CaveBoard      = CaveBoard,
    SIZES          = SIZES,
    countSolutions = countSolutions, -- exposed for the specs
}
