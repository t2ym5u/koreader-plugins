local _ = require("gettext")
return {
    fullname    = _("Quiz"),
    description = _("General knowledge quiz — everyone writes their answer, then reveal."),
    version     = "1.6.4",
}
