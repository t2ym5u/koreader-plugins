local _ = require("gettext")
return {
    fullname    = _("Tatami"),
    description = _("Fill the grid with 1x2 dominoes"),
    version     = "1.1.13",
}
