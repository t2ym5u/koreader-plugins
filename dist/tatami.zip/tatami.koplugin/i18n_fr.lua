return {
    ["Selected (%1,%2) — tap adjacent cell to connect."] = { fr = "Sélectionné (%1,%2) — appuyez sur une case adjacente pour connecter.", es = "Seleccionado (%1,%2) — toca una casilla adyacente para conectar.", de = "Ausgewählt (%1,%2) — tippe auf eine angrenzende Zelle, um zu verbinden." },
    ["%1\xC3\x97%2 \xC2\xB7 %3 \xC2\xB7 Dominoes: %4/%5"] = { fr = "%1×%2 · %3 · Dominos : %4/%5", es = "%1×%2 · %3 · Dominós: %4/%5", de = "%1×%2 · %3 · Dominosteine: %4/%5" },
    ["Fill the grid with 1x2 dominoes"] = { fr = "Remplissez la grille avec des dominos 1x2", es = "Rellena la cuadrícula con dominós 1x2", de = "Fülle das Raster mit 1x2-Dominosteinen" },
    ["Tatami"] = { fr = "Tatami", es = "Tatami", de = "Tatami" },
}
